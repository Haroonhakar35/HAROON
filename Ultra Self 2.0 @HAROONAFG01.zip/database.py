#======================================== In The Name Of God ========================================#

# Source Name: Ultra Self
# Source Version: 2.0
# Developer: @IVGalaxy
# © 2025 Ultra Self LLC. All rights reserved.

#====================================================================================================#

from colorama import Fore
import configparser
import aiomysql
import asyncio
import os

#====================================================================================================#

config = configparser.ConfigParser()
config.read("config.ini")

owner_id = config["settings"]["Owner_ID"]
db_name = config["settings"]["DBName"]
db_user = config["settings"]["DBUser"]
db_pass = config["settings"]["DBPass"]
helper_db_name = config["settings"]["HelperDBName"]
helper_db_user = config["settings"]["HelperDBUser"]
helper_db_pass = config["settings"]["HelperDBPass"]

async def get_data(query):
    async with aiomysql.connect(host="localhost", db=db_name, user=db_user, password=db_pass) as connect:
        async with connect.cursor() as db:
            await db.execute(query)
            result = await db.fetchone()
            return result

async def update_data(query):
    async with aiomysql.connect(host="localhost", db=db_name, user=db_user, password=db_pass) as connect:
        async with connect.cursor() as db:
            await db.execute(query)
            await connect.commit()

async def helper_getdata(query):
    async with aiomysql.connect(host="localhost", db=helper_db_name, user=helper_db_user, password=helper_db_pass) as connect:
        async with connect.cursor() as db:
            await db.execute(query)
            result = await db.fetchone()
            return result

async def helper_updata(query):
    async with aiomysql.connect(host="localhost", db=helper_db_name, user=helper_db_user, password=helper_db_pass) as connect:
        async with connect.cursor() as db:
            await db.execute(query)
            await connect.commit()

print(Fore.YELLOW+"Database setup...")

async def tables():
    await update_data("""
CREATE TABLE IF NOT EXISTS bot(
status ENUM('ON', 'OFF') DEFAULT 'ON'
) default charset=utf8mb4;
""")
    await update_data("""
CREATE TABLE IF NOT EXISTS user(
id bigint PRIMARY KEY,
step varchar(150) DEFAULT 'none',
phone varchar(200) DEFAULT NULL,
amount bigint DEFAULT 0,
referral bigint DEFAULT 0,
expir bigint DEFAULT 0,
trial_status ENUM('used', 'unused') DEFAULT 'unused',
account ENUM('verified', 'unverified') DEFAULT 'unverified',
self ENUM('active', 'inactive') DEFAULT 'inactive',
join_at bigint NOT NULL,
last_update bigint DEFAULT NULL
) default charset=utf8mb4;
""")
    await update_data("""
CREATE TABLE IF NOT EXISTS block(
id bigint PRIMARY KEY
) default charset=utf8mb4;
""")
    await update_data("""
CREATE TABLE IF NOT EXISTS transactions(
tracking_code bigint PRIMARY KEY,
user_id bigint NOT NULL,
payment_method ENUM('card', 'tron') NOT NULL,
wallet_address varchar(100) DEFAULT NULL,
amount DECIMAL(30, 6) NOT NULL,
status ENUM('confirmed', 'canceled', 'pending') NOT NULL,
created_at bigint NOT NULL,
confirmed_at bigint DEFAULT NULL
) default charset=utf8mb4;
""")
    await update_data("""
CREATE TABLE IF NOT EXISTS temp_wallets(
wallet_address varchar(100) PRIMARY KEY,
private_key varchar(200) NOT NULL,
created_at bigint NOT NULL
) default charset=utf8mb4;
""")
    await update_data("""
CREATE TABLE IF NOT EXISTS channels(
id varchar(50) NOT NULL UNIQUE,
channel_link varchar(50) NOT NULL UNIQUE
) default charset=utf8mb4;
""")
    await update_data("""
CREATE TABLE IF NOT EXISTS codes(
code varchar(50) NOT NULL UNIQUE,
capacity varchar(20) DEFAULT NULL,
expir varchar(20) DEFAULT NULL,
value bigint DEFAULT 0
) default charset=utf8mb4;
""")
    await update_data("""
CREATE TABLE IF NOT EXISTS used_codes(
id bigint NOT NULL,
code varchar(50) NOT NULL,
PRIMARY KEY(id, code)
) default charset=utf8mb4;
""")
    await update_data("""
CREATE TABLE IF NOT EXISTS settings(
anti_spam ENUM('ON', 'OFF') DEFAULT 'ON',
test_sub ENUM('ON', 'OFF') DEFAULT 'ON',
referral ENUM('ON', 'OFF') DEFAULT 'ON',
reports ENUM('ON', 'OFF') DEFAULT 'ON',
giftcode ENUM('ON', 'OFF') DEFAULT 'ON',
ctcgate ENUM('ON', 'OFF') DEFAULT 'ON',
trxgate ENUM('ON', 'OFF') DEFAULT 'ON'
) default charset=utf8mb4;
""")
    await update_data("""
CREATE TABLE IF NOT EXISTS dynamic_config(
start_text varchar(2000) DEFAULT 'سلام کاربر FIRST_NAME به سلف ساز Ultra Self خوش آمدید!',
support_text varchar(2000) DEFAULT 'پیام خود را ارسال کنید:',
whattb_text varchar(5000) DEFAULT 'متنی تنظیم نشده است!',
myaccount_text varchar(2000) DEFAULT 'اطلاعات حساب کاربری شما در Ultra Self به شرح زیر می باشد:',
referral_value varchar(20) DEFAULT '2000',
sub_1m_price varchar(20) DEFAULT '20000',
sub_2m_price varchar(20) DEFAULT '40000',
sub_3m_price varchar(20) DEFAULT '60000',
sub_4m_price varchar(20) DEFAULT '80000',
sub_5m_price varchar(20) DEFAULT '100000',
sub_6m_price varchar(20) DEFAULT '120000'
) default charset=utf8mb4;
""")
    await update_data("""
CREATE TABLE IF NOT EXISTS anti_spam(
id bigint PRIMARY KEY,
time bigint DEFAULT 0,
count bigint DEFAULT 0,
until bigint DEFAULT 0,
timer bigint DEFAULT 0
) default charset=utf8mb4;
""")
    await helper_updata("""
CREATE TABLE IF NOT EXISTS user(
id bigint PRIMARY KEY,
step varchar(150) DEFAULT 'none'
) default charset=utf8mb4;
""")
    await helper_updata("""
CREATE TABLE IF NOT EXISTS ownerlist(
id bigint PRIMARY KEY
) default charset=utf8mb4;
""")
    await helper_updata("""
CREATE TABLE IF NOT EXISTS adminlist(
id bigint PRIMARY KEY
) default charset=utf8mb4;
""")
    bot = await get_data("SELECT * FROM bot")
    settings = await get_data("SELECT * FROM settings")
    dynamic_config = await get_data("SELECT * FROM dynamic_config")
    if bot is None:
        await update_data("INSERT INTO bot() VALUES()")
    if settings is None:
        await update_data("INSERT INTO settings() VALUES()")
    if dynamic_config is None:
        await update_data("INSERT INTO dynamic_config() VALUES()")

    OwnerUser = await helper_getdata(f"SELECT * FROM ownerlist WHERE id = '{owner_id}' LIMIT 1")
    if OwnerUser is None:
        await helper_updata(f"INSERT INTO ownerlist(id) VALUES({owner_id})")

    AdminUser = await helper_getdata(f"SELECT * FROM adminlist WHERE id = '{owner_id}' LIMIT 1")
    if AdminUser is None:
        await helper_updata(f"INSERT INTO adminlist(id) VALUES({owner_id})")
    
asyncio.run(tables())
os.system("clear")
print(Fore.YELLOW+"Database installed")

#====================================================================================================#