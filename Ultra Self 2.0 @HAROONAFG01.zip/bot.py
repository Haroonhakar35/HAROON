#======================================== In The Name Of God ========================================#

# Source Name: Ultra Self
# Source Version: 2.0
# Developer: @IVGalaxy
# © 2025 Ultra Self LLC. All rights reserved.

#====================================================================================================#

from colorama import Fore
from pyrogram import Client, filters, errors
from pyrogram.types import *
from functools import wraps
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.jobstores.sqlalchemy import SQLAlchemyJobStore
from sqlalchemy import create_engine
from tronpy import AsyncTron
from tronpy.keys import PrivateKey
from tronpy.exceptions import AddressNotFound, ApiError, TransactionNotFound
from PIL import Image, ImageDraw
from io import BytesIO
from decimal import Decimal, ROUND_DOWN
from datetime import datetime
from zoneinfo import ZoneInfo
import matplotlib.pyplot as plt
import numpy as np
import configparser
import asyncio
import subprocess
import html
import zipfile
import aiomysql
import aiofiles
import aiohttp
import shutil
import random
import string
import qrcode
import math
import re
import os

#====================================================================================================#

config = configparser.ConfigParser()
config.read("config.ini")

owner_id = int(config["settings"]["Owner_ID"])
bot_token = config["settings"]["Main_Token"]
api_id = config["settings"]["API_ID"]
api_hash = config["settings"]["API_HASH"]
helper_username = config["settings"]["Helper_Username"]
faq_channel = config["settings"]["Faq_Channel"]
reports_channel = config["settings"]["Reports_Channel"]
db_name = config["settings"]["DBName"]
db_user = config["settings"]["DBUser"]
db_pass = config["settings"]["DBPass"]
helper_db_name = config["settings"]["HelperDBName"]
helper_db_user = config["settings"]["HelperDBUser"]
helper_db_pass = config["settings"]["HelperDBPass"]
site_services = config["settings"]["SiteServices"]
main_wallet = config["settings"]["Wallet_Address"]
card_number = config["settings"]["CardNumber"]
card_name = config["settings"]["CardName"]

#====================================================================================================#

if not os.path.isdir("sessions"):
    os.mkdir("sessions")
if not os.path.isdir("selfs"):
    os.mkdir("selfs")
if not os.path.isdir("temp_files"):
    os.mkdir("temp_files")

#====================================================================================================#

app = Client("Bot", api_id=api_id, api_hash=api_hash, bot_token=bot_token)

temp_Client = {}
lock = asyncio.Lock()

scheduler = AsyncIOScheduler(jobstores={"default": SQLAlchemyJobStore(engine=create_engine(f"mysql+pymysql://{db_user}:{db_pass}@localhost:3306/{db_name}", pool_recycle=280, pool_pre_ping=True))})

async def start_scheduler():
    scheduler.start()

async def get_data(query):
    async with aiomysql.connect(host="localhost", db=db_name, user=db_user, password=db_pass, cursorclass=aiomysql.DictCursor) as connect:
        async with connect.cursor() as db:
            await db.execute(query)
            result = await db.fetchone()
            return result

async def get_datas(query):
    async with aiomysql.connect(host="localhost", db=db_name, user=db_user, password=db_pass) as connect:
        async with connect.cursor() as db:
            await db.execute(query)
            result = await db.fetchall()
            return result

async def update_data(query):
    async with aiomysql.connect(host="localhost", db=db_name, user=db_user, password=db_pass) as connect:
        async with connect.cursor() as db:
            await db.execute(query)
            await connect.commit()

async def helper_getdata(query):
    async with aiomysql.connect(host="localhost", db=helper_db_name, user=helper_db_user, password=helper_db_pass) as connect:
        async with connect.cursor() as db:
            await db.execute(query)
            result = await db.fetchone()
            return result

async def helper_updata(query):
    async with aiomysql.connect(host="localhost", db=helper_db_name, user=helper_db_user, password=helper_db_pass) as connect:
        async with connect.cursor() as db:
            await db.execute(query)
            await connect.commit()

async def add_admin(user_id):
    user = await helper_getdata(f"SELECT * FROM adminlist WHERE id = '{user_id}' LIMIT 1")
    if user is None:
        await helper_updata(f"INSERT INTO adminlist(id) VALUES('{user_id}')")

async def delete_admin(user_id):
    user = await helper_getdata(f"SELECT * FROM adminlist WHERE id = '{user_id}' LIMIT 1")
    if user is not None:
        await helper_updata(f"DELETE FROM adminlist WHERE id = '{user_id}' LIMIT 1")

async def get_profile(user_id):
    async for photo in app.get_chat_photos(user_id, limit=1):
        return photo
    return None

async def block_timer(user_id):
    spam = await get_data(f"SELECT * FROM anti_spam WHERE id = '{user_id}' LIMIT 1")
    timer = spam["timer"]
    if timer > 0:
        timer -= 1
        await update_data(f"UPDATE anti_spam SET timer = '{timer}' WHERE id = '{user_id}' LIMIT 1")
    else:
        job = scheduler.get_job(f"mute-{user_id}")
        if job:
            scheduler.remove_job(f"mute-{user_id}")
        await update_data(f"UPDATE anti_spam SET count = '0' WHERE id = '{user_id}' LIMIT 1")
        await update_data(f"DELETE FROM block WHERE id = '{user_id}' LIMIT 1")
        await app.send_message(user_id, "شما از حالت سکوت خارج شدید. لطفا از اسپم مجدد خودداری نمایید")

async def giftcode_timer(code):
    gift_code = await get_data(f"SELECT * FROM codes WHERE code = '{code}' LIMIT 1")
    expir = gift_code["expir"]
    if expir.isdigit() and int(expir) > 0:
        expir = int(expir)
        expir -= 1
        await update_data(f"UPDATE codes SET expir = '{expir}' WHERE code = '{code}' LIMIT 1")
    else:
        job = scheduler.get_job(f"giftcode-{code}")
        if job:
            scheduler.remove_job(f"giftcode-{code}")
        await update_data(f"DELETE FROM codes WHERE code = '{code}' LIMIT 1")

async def generate_giftcode():
    characters = string.ascii_uppercase + string.digits
    while True:
        new_code = ''.join(random.choices(characters, k=10))
        code = await get_data(f"SELECT * from codes WHERE code = '{new_code}' LIMIT 1")
        if code is None:
            return new_code
        await asyncio.sleep(0.1)

async def generate_tracking_code():
    while True:
        new_tracking_code = random.randint(10**11, 10**12 - 1)
        tracking_code = await get_data(f"SELECT * from transactions WHERE tracking_code = '{new_tracking_code}' LIMIT 1")
        if tracking_code is None:
            return new_tracking_code
        await asyncio.sleep(0.1)

async def create_wallet():
    async with AsyncTron() as client:
        wallet = client.generate_address()
        return wallet["base58check_address"], wallet["private_key"]

async def get_balance(address):
    async with AsyncTron() as client:
        try:
            balance = await client.get_account_balance(address)
            return Decimal(str(balance))
        except AddressNotFound:
            return "ercode-404"
        except TransactionNotFound:
            return "ercode-410"
        except ApiError:
            return "ercode-500"
        except Exception as e:
            return f"ercode-unknown: {str(e)}"

async def transfer_trx(sender, private_key, recipient, amount):
    async with AsyncTron() as client:
        try:
            amount_sun = int(Decimal(str(amount)) * Decimal(1000000))
            txb = client.trx.transfer(sender, recipient, amount_sun)
            txn = await txb.build()
            txn_ret = await txn.sign(PrivateKey(bytes.fromhex(private_key))).broadcast()
            return txn_ret
        except AddressNotFound:
            return "ercode-404"
        except TransactionNotFound:
            return "ercode-410"
        except ApiError:
            return "ercode-500"
        except Exception as e:
            return f"ercode-unknown: {str(e)}"

async def get_trx_price_rial():
    url = "https://apiv2.nobitex.ir/market/stats?srcCurrency=trx&dstCurrency=rls"
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as res:
            data = await res.json()
            return Decimal(str(data["stats"]["trx-rls"]["latest"]))

def generate_qrcode(data):
    qr = qrcode.QRCode(version=1, box_size=20, border=4, error_correction=qrcode.constants.ERROR_CORRECT_H)
    qr.add_data(data)
    qr.make(fit=True)
    qr_img = qr.make_image(fill_color="black", back_color="white").convert("RGBA")
    width, height = qr_img.size
    gradient = Image.new("RGBA", (width, height))
    draw = ImageDraw.Draw(gradient)
    for y in range(height):
        if y < height // 2:
            t = y / (height / 2)
            r = int(255 - t * (255 - 166))
            g = int(156 - t * (156 - 77))
            b = int(230 + t * (255 - 230))
        else:
            t = (y - height / 2) / (height / 2)
            r = int(166 - t * (166 - 51))
            g = int(77 + t * (153 - 77))
            b = 255
        draw.line([(0, y), (width, y)], fill=(r, g, b, 200))
    mask = qr_img.split()[0].point(lambda p: 255 if p < 128 else 0)
    final_img = Image.new("RGBA", (width, height), "white")
    final_img.paste(gradient, (0, 0), mask)
    image_io = BytesIO()
    final_img.save(image_io, format="PNG")
    image_io.seek(0)
    return image_io

def generate_stats_chart(values, bot_data, date, time):
    labels = ["Online", "Past Hour", "Past 6 Hours", "Past 12 Hours", "Yesterday", "Past Week", "Past Month", "Past 6 Months"]
    plt.style.use("dark_background")
    fig, ax = plt.subplots(figsize=(12, 6))
    fig.patch.set_facecolor("#121212")
    ax.set_facecolor("#121212")
    bar_color = "#1de9b6"
    bars = ax.bar(labels, values, color=bar_color, width=0.5) 
    for bar in bars:  
        height = bar.get_height()  
        ax.annotate(f"{height}",  
        xy=(bar.get_x() + bar.get_width() / 2, height),
        xytext=(0, 6),
        textcoords="offset points",
        ha="center", va="bottom",
        fontsize=10, color="white")
    max_value = max(values)
    if max_value < 10:
        y_limit = 10
    else:
        magnitude = 10 ** (len(str(int(max_value))) - 1)
        y_limit = math.ceil(max_value / magnitude) * magnitude
    ax.set_ylim(0, y_limit)
    for label in ax.get_xticklabels():
        label.set_fontsize(11)
        label.set_color("white")
    for label in ax.get_yticklabels():
        label.set_fontsize(10)
        label.set_color("gray")
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    plt.figtext(0.01, 0.98, f"@{bot_data.username}", ha="left", va="top", fontsize=10, color="gray")
    plt.figtext(0.99, 0.98, f"{date} - {time}", ha="right", va="top", fontsize=10, color="gray")
    plt.title("User Statistics", fontsize=15, color="white", pad=20)
    fig.tight_layout()
    buf = BytesIO()
    plt.savefig(buf, format="png", dpi=300, facecolor=fig.get_facecolor())
    buf.seek(0)
    return buf

def censor_numeric(s):
    _count_ = 1
    length = len(s)
    if length <= 2:
        return "*" * length
    elif length <= 4:
        return s[0] + "*" * (length - 2) + s[-1]
    elif length <= 6:
        return s[:2] + "*" * (length - 4) + s[-2:]
    elif length <= 10:
        return s[:3] + "*" * (length - 6) + s[-3:]
    else:
        return s[:4] + "*" * (length - 8) + s[-4:]

def get_time(mode):
    now = datetime.now(ZoneInfo("Asia/Tehran"))
    if mode == "timestamp":
        return int(now.timestamp())
    elif mode == "date":
        return now.strftime("%Y/%m/%d")
    elif mode == "time":
        return now.strftime("%H:%M")

def time_convert(time_stamp, mode):
    if time_stamp:
        time = datetime.fromtimestamp(time_stamp, ZoneInfo("Asia/Tehran"))
        if mode == "date":
            return time.strftime("%Y/%m/%d")
        elif mode == "time":
            return time.strftime("%H:%M")
    else:
        return None

def checker(func):
    @wraps(func)
    async def wrapper(c, m, *args, **kwargs):
        chat_id = m.chat.id if hasattr(m, "chat") else m.from_user.id
        bot = await get_data("SELECT * FROM bot")
        block = await get_data(f"SELECT * FROM block WHERE id = '{chat_id}' LIMIT 1")
        channels = await get_datas("SELECT * FROM channels")
        settings = await get_data("SELECT * FROM settings")
        spam = await get_data(f"SELECT * FROM anti_spam WHERE id = '{chat_id}' LIMIT 1")
        count = spam["count"]
        until = spam["until"]

        if block is not None and chat_id != owner_id:
            return
        
        if settings["anti_spam"] == "ON":
            if block is None and chat_id != owner_id:
                if get_time("timestamp") - spam["time"] <= 3:
                    count += 1
                else:
                    count = 1
                    await update_data(f"UPDATE anti_spam SET time = '{get_time('timestamp')}' WHERE id = '{chat_id}' LIMIT 1")
                await update_data(f"UPDATE anti_spam SET count = '{count}' WHERE id = '{chat_id}' LIMIT 1")
        
                if count >= 5:
                    until += 60
                    await update_data(f"UPDATE anti_spam SET until = '{until}' WHERE id = '{chat_id}' LIMIT 1")
                    await update_data(f"UPDATE anti_spam SET timer = '{until}' WHERE id = '{chat_id}' LIMIT 1")
                    await update_data(f"INSERT INTO block(id) VALUES('{chat_id}')")
                    scheduler.add_job(block_timer, "interval", seconds=1, args=[chat_id], id=f"mute-{chat_id}")
                    await app.send_message(chat_id, f"شما به دلیل اسپم به مدت {until} ثانیه سکوت شدید")
                    return
        
        buttons = []
        for channel in channels:
            chat = await app.get_chat(channel[0])
            try:
                await app.get_chat_member(channel[0], chat_id)
            except errors.UserNotParticipant:
                buttons.append([InlineKeyboardButton(text=chat.title, url=channel[1])])
        if buttons:
            _count_ = 1
            buttons.append([InlineKeyboardButton(text="بررسی عضویت", callback_data="Back")])
            channel_word = "کانال" if len(buttons) - 1 == 1 else "کانال های"
            await app.send_message(chat_id, f"لطفا برای استفاده از ربات ابتدا در {channel_word} زیر عضو شوید:", reply_markup=InlineKeyboardMarkup(buttons))
            return

        if bot["status"] == "OFF" and chat_id != owner_id:
            await app.send_message(chat_id, "ربات در حال حاضر خاموش است!")
            return
        
        return await func(c, m, *args, **kwargs)
    return wrapper

async def expirdec(user_id):
    user = await get_data(f"SELECT * FROM user WHERE id = '{user_id}' LIMIT 1")
    user_expir = user["expir"]
    if user_expir == 3:
        await app.send_message(user_id, "مشترک گرامی تنها 3 روز از اشتراک شما باقی مانده است!", reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text="خرید انقضا", callback_data="BuyExpir")
                ]
            ]
        ))
    if user_expir > 0:
        user_upexpir = user_expir - 1
        await update_data(f"UPDATE user SET expir = '{user_upexpir}' WHERE id = '{user_id}' LIMIT 1")
    else:
        job = scheduler.get_job(str(user_id))
        if job:
            scheduler.remove_job(str(user_id))
        if user_id != owner_id:
            delete_admin(user_id)
        if os.path.isdir(f"selfs/self-{user_id}"):
            subprocess.Popen(["pkill", "-f", f"{user_id}.py"], cwd=f"selfs/self-{user_id}")
            await asyncio.sleep(1)
            shutil.rmtree(f"selfs/self-{user_id}")
        if os.path.isfile(f"sessions/{user_id}.session"):
            async with Client(f"sessions/{user_id}") as user_client:
                await user_client.log_out()
            if os.path.isfile(f"sessions/{user_id}.session"):
                os.remove(f"sessions/{user_id}.session")
        if os.path.isfile(f"sessions/{user_id}.session-journal"):
            os.remove(f"sessions/{user_id}.session-journal")
        await app.send_message(user_id, "کاربر گرامی اشتراک سلف شما به پایان رسید. برای خرید مجدد اشتراک به قسمت خرید اشتراک مراجعه کنید")
        await update_data(f"UPDATE user SET self = 'inactive' WHERE id = '{user_id}' LIMIT 1")

async def setscheduler(user_id):
    job = scheduler.get_job(str(user_id))
    if not job:
        scheduler.add_job(expirdec, "interval", hours=24, args=[user_id], id=str(user_id))

Main = InlineKeyboardMarkup(
    [
        [
            InlineKeyboardButton(text="سلف چیست؟", callback_data="WhatSelf")
        ],
        [
            InlineKeyboardButton(text="خرید اشتراک", callback_data="BuySub"),
            InlineKeyboardButton(text="اطلاعات اشتراک", callback_data="Subinfo")
        ],
        [
            InlineKeyboardButton(text="بها", callback_data="Price"),
            InlineKeyboardButton(text="کیف پول", callback_data="Wallet")
        ],
        [
            InlineKeyboardButton(text="حساب من", callback_data="MyAccount")
        ],
        [
            InlineKeyboardButton(text="احراز هویت", callback_data="AccVerify"),
            InlineKeyboardButton(text="لینک دعوت شما", callback_data="Referral")
        ],
        [
            InlineKeyboardButton(text="پشتیبانی", callback_data="Support")
        ],
        [
            InlineKeyboardButton(text="سوالات متداول", url=f"https://t.me/{faq_channel}"),
            InlineKeyboardButton(text="سایت خدمات", web_app=WebAppInfo(url=f"{site_services}"))
        ],
        [
            InlineKeyboardButton(text="درخواست نمایندگی", callback_data="Representation")
        ]
    ]
)

@app.on_message(filters.private, group=-1)
async def update(c, m):
    user = await get_data(f"SELECT * FROM user WHERE id = '{m.chat.id}' LIMIT 1")
    spam = await get_data(f"SELECT * FROM anti_spam WHERE id = '{m.chat.id}' LIMIT 1")
    block = await get_data(f"SELECT * FROM block WHERE id = '{m.chat.id}' LIMIT 1")
    if user is None:
        await update_data(f"INSERT INTO user(id, join_at) VALUES('{m.chat.id}', '{get_time('timestamp')}')")
    if spam is None:
        await update_data(f"INSERT INTO anti_spam(id) VALUES('{m.chat.id}')")
    if block is None:
        await update_data(f"UPDATE user SET last_update = '{get_time('timestamp')}' WHERE id = '{m.chat.id}' LIMIT 1")

@app.on_callback_query(group=-1)
async def update(c, call):
    user = await get_data(f"SELECT * FROM user WHERE id = '{call.from_user.id}' LIMIT 1")
    spam = await get_data(f"SELECT * FROM anti_spam WHERE id = '{call.from_user.id}' LIMIT 1")
    block = await get_data(f"SELECT * FROM block WHERE id = '{call.from_user.id}' LIMIT 1")
    if user is None:
        await update_data(f"INSERT INTO user(id, join_at) VALUES('{call.from_user.id}', '{get_time('timestamp')}')")
    if spam is None:
        await update_data(f"INSERT INTO anti_spam(id) VALUES('{call.from_user.id}')")
    if block is None:
        await update_data(f"UPDATE user SET last_update = '{get_time('timestamp')}' WHERE id = '{call.from_user.id}' LIMIT 1")

@app.on_message(filters.private&filters.text&filters.regex(r"^\/start \d+$"), group=-2)
async def update(c, m):
    bot = await get_data("SELECT * FROM bot")
    user = await get_data(f"SELECT * FROM user WHERE id = '{m.chat.id}' LIMIT 1")
    block = await get_data(f"SELECT * FROM block WHERE id = '{m.chat.id}' LIMIT 1")
    channels = await get_datas("SELECT * FROM channels")
    settings = await get_data("SELECT * FROM settings")

    if block is not None and m.chat.id != owner_id:
        return
    
    for channel in channels:
        _count_ = 1
        try:
            await app.get_chat_member(channel[0], m.chat.id)
        except errors.UserNotParticipant:
            user_join = False
            break
    else:
        user_join = True
    
    if bot["status"] == "ON" and user_join:
        dyconfig = await get_data("SELECT * FROM dynamic_config")
        await app.send_message(m.chat.id, dyconfig["start_text"].replace("FIRST_NAME", html.escape(m.chat.first_name or "")).replace("LAST_NAME", html.escape(m.chat.last_name or "")).replace("DATE", get_time("date")).replace("TIME", get_time("time")), reply_markup=Main)
        if user:
            await update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")
        else:
            if settings["referral"] == "ON":
                ref_id = int(m.text.split(maxsplit=1)[1].strip())
                get_ref = await get_data(f"SELECT * FROM user WHERE id = '{ref_id}' LIMIT 1")
                if get_ref:
                    user_upamount = int(get_ref["amount"]) + int(dyconfig["referral_value"])
                    user_upref = int(get_ref["referral"]) + 1
                    await update_data(f"UPDATE user SET amount = '{user_upamount}' WHERE id = '{ref_id}' LIMIT 1")
                    await update_data(f"UPDATE user SET referral = '{user_upref}' WHERE id = '{ref_id}' LIMIT 1")
                    await app.send_message(ref_id, f"کاربر [{html.escape(m.chat.first_name)}](tg://user?id={m.chat.id}) با لینک دعوت شما وارد ربات شد و مبلغ {int(dyconfig['referral_value']):,} تومان به حساب شما افزوده شد")

@app.on_message(filters.private&filters.text, group=0)
@checker
async def update(c, m):
    if m.text.strip() == "/start":
        dyconfig = await get_data("SELECT * FROM dynamic_config")
        await app.send_message(m.chat.id, dyconfig["start_text"].replace("FIRST_NAME", html.escape(m.chat.first_name or "")).replace("LAST_NAME", html.escape(m.chat.last_name or "")).replace("DATE", get_time("date")).replace("TIME", get_time("time")), reply_markup=Main)
        await update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")
        async with lock:
            if m.chat.id in temp_Client:
                del temp_Client[m.chat.id]

@app.on_callback_query(group=0)
@checker
async def call(c, call):
    global temp_Client
    user = await get_data(f"SELECT * FROM user WHERE id = '{call.from_user.id}' LIMIT 1")
    phone_number = user["phone"]
    account_status = "تایید شده" if user["account"] == "verified" else "تایید نشده"
    expir = user["expir"]
    amount = user["amount"]
    referral = user["referral"]
    chat_id = call.from_user.id
    m_id = call.message.id
    data = call.data
    username = f"@{call.from_user.username}" if call.from_user.username else "وجود ندارد"

    if data == "MyAccount":
        dyconfig = await get_data("SELECT * FROM dynamic_config")
        profile = await get_profile(chat_id)
        if profile:
            await app.edit_message_media(chat_id, m_id, media=InputMediaPhoto(media=profile.file_id, caption=dyconfig["myaccount_text"].replace("FIRST_NAME", html.escape(call.from_user.first_name or "")).replace("LAST_NAME", html.escape(call.from_user.last_name or "")).replace("DATE", get_time("date")).replace("TIME", get_time("time"))), reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="نام شما", callback_data="text"),
                        InlineKeyboardButton(text=f"{call.from_user.first_name}", callback_data="text")
                    ],
                    [
                        InlineKeyboardButton(text="آیدی شما", callback_data="text"),
                        InlineKeyboardButton(text=f"{call.from_user.id}", copy_text=f"{call.from_user.id}")
                    ],
                    [
                        InlineKeyboardButton(text="یوزرنیم شما", callback_data="text"),
                        InlineKeyboardButton(text=f"{username}", callback_data="text")
                    ],
                    [
                        InlineKeyboardButton(text="موجودی شما", callback_data="text"),
                        InlineKeyboardButton(text=f"{int(amount):,} تومان", callback_data="text")
                    ],
                    [
                        InlineKeyboardButton(text="دعوت شده ها", callback_data="text"),
                        InlineKeyboardButton(text=f"{referral} نفر", callback_data="text")
                    ],
                    [
                        InlineKeyboardButton(text="وضعیت حساب شما", callback_data="text"),
                        InlineKeyboardButton(text=f"{account_status}", callback_data="text")
                    ],
                    [
                        InlineKeyboardButton(text="زمان عضویت شما", callback_data="text"),
                        InlineKeyboardButton(text=f"{time_convert(user['join_at'], 'date')} - {time_convert(user['join_at'], 'time')}", callback_data="text")
                    ],
                    [
                        InlineKeyboardButton(text="----------------", callback_data="text")
                    ],
                    [
                        InlineKeyboardButton(text=f"انقضای شما ({expir}) روز", callback_data="text")
                    ],
                    [
                        InlineKeyboardButton(text="----------------", callback_data="text")
                    ],
                    [
                        InlineKeyboardButton(text="ساعت", callback_data="text"),
                        InlineKeyboardButton(text=f"{get_time('time')}", callback_data="text")
                    ],
                    [
                        InlineKeyboardButton(text="تاریخ", callback_data="text"),
                        InlineKeyboardButton(text=f"{get_time('date')}", callback_data="text")
                    ],
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="Home")
                    ]
                ]
            ))
        else:
            await app.edit_message_text(chat_id, m_id, dyconfig["myaccount_text"].replace("FIRST_NAME", html.escape(call.from_user.first_name or "")).replace("LAST_NAME", html.escape(call.from_user.last_name or "")).replace("DATE", get_time("date")).replace("TIME", get_time("time")), reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="نام شما", callback_data="text"),
                        InlineKeyboardButton(text=f"{call.from_user.first_name}", callback_data="text")
                    ],
                    [
                        InlineKeyboardButton(text="آیدی شما", callback_data="text"),
                        InlineKeyboardButton(text=f"{call.from_user.id}", copy_text=f"{call.from_user.id}")
                    ],
                    [
                        InlineKeyboardButton(text="یوزرنیم شما", callback_data="text"),
                        InlineKeyboardButton(text=f"{username}", callback_data="text")
                    ],
                    [
                        InlineKeyboardButton(text="موجودی شما", callback_data="text"),
                        InlineKeyboardButton(text=f"{int(amount):,} تومان", callback_data="text")
                    ],
                    [
                        InlineKeyboardButton(text="دعوت شده ها", callback_data="text"),
                        InlineKeyboardButton(text=f"{referral} نفر", callback_data="text")
                    ],
                    [
                        InlineKeyboardButton(text="وضعیت حساب شما", callback_data="text"),
                        InlineKeyboardButton(text=f"{account_status}", callback_data="text")
                    ],
                    [
                        InlineKeyboardButton(text="زمان عضویت شما", callback_data="text"),
                        InlineKeyboardButton(text=f"{time_convert(user['join_at'], 'date')} - {time_convert(user['join_at'], 'time')}", callback_data="text")

                    ],
                    [
                        InlineKeyboardButton(text="----------------", callback_data="text")
                    ],
                    [
                        InlineKeyboardButton(text=f"انقضای شما ({expir}) روز", callback_data="text")
                    ],
                    [
                        InlineKeyboardButton(text="----------------", callback_data="text")
                    ],
                    [
                        InlineKeyboardButton(text="ساعت", callback_data="text"),
                        InlineKeyboardButton(text=f"{get_time('time')}", callback_data="text")
                    ],
                    [
                        InlineKeyboardButton(text="تاریخ", callback_data="text"),
                        InlineKeyboardButton(text=f"{get_time('date')}", callback_data="text")
                    ],
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="Back")
                    ]
                ]
            ))
        await update_data(f"UPDATE user SET step = 'none' WHERE id = '{call.from_user.id}' LIMIT 1")

    elif data == "BuySub":
        if user["phone"] is None:
            await app.delete_messages(chat_id, m_id)
            await app.send_message(chat_id, "لطفا با استفاده از دکمه زیر شماره خود را به اشتراک بگذارید", reply_markup=ReplyKeyboardMarkup(
                [
                    [
                        KeyboardButton(text="اشتراک گذاری شماره", request_contact=True)
                    ]
                ],resize_keyboard=True
            ))
            await update_data(f"UPDATE user SET step = 'contact' WHERE id = '{call.from_user.id}' LIMIT 1")
        else:
            if user["account"] == "verified":
                if not os.path.isfile(f"sessions/{chat_id}.session"):
                    settings = await get_data("SELECT * FROM settings")
                    dyconfig = await get_data("SELECT * FROM dynamic_config")
                    sub_list = [
                        [
                            InlineKeyboardButton(text=f"1 ماهه معادل {int(dyconfig['sub_1m_price']):,} تومان", callback_data=f"Login-30-{dyconfig['sub_1m_price']}")
                        ],
                        [
                            InlineKeyboardButton(text=f"2 ماهه معادل {int(dyconfig['sub_2m_price']):,} تومان", callback_data=f"Login-60-{dyconfig['sub_2m_price']}")
                        ],
                        [
                            InlineKeyboardButton(text=f"3 ماهه معادل {int(dyconfig['sub_3m_price']):,} تومان", callback_data=f"Login-90-{dyconfig['sub_3m_price']}")
                        ],
                        [
                            InlineKeyboardButton(text=f"4 ماهه معادل {int(dyconfig['sub_4m_price']):,} تومان", callback_data=f"Login-120-{dyconfig['sub_4m_price']}")
                        ],
                        [
                            InlineKeyboardButton(text=f"5 ماهه معادل {int(dyconfig['sub_5m_price']):,} تومان", callback_data=f"Login-150-{dyconfig['sub_5m_price']}")
                        ],
                        [
                            InlineKeyboardButton(text=f"6 ماهه معادل {int(dyconfig['sub_6m_price']):,} تومان", callback_data=f"Login-180-{dyconfig['sub_6m_price']}")
                        ],
                        [
                            InlineKeyboardButton(text="برگشت", callback_data="Back")
                        ]
                    ]

                    if settings["test_sub"] == "ON" and user["trial_status"] == "unused":
                        sub_list.insert(0, [InlineKeyboardButton(text="اشتراک تست", callback_data="Login-1-0")])

                    await app.edit_message_text(chat_id, m_id, "پلن مورد نظر خود را انتخاب کنید:", reply_markup=InlineKeyboardMarkup(sub_list))
                    await update_data(f"UPDATE user SET step = 'none' WHERE id = '{call.from_user.id}' LIMIT 1")
                    async with lock:
                        if chat_id in temp_Client:
                            del temp_Client[chat_id]
                else:
                    await app.answer_callback_query(call.id, text="اشتراک سلف برای شما فعال است!", show_alert=True)
            else:
                await app.edit_message_text(chat_id, m_id, "برای خرید اشتراک ابتدا باید احراز هویت کنید", reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(text="احراز هویت", callback_data="AccVerify")
                        ],
                        [
                            InlineKeyboardButton(text="برگشت", callback_data="Back")
                        ]
                    ]
                ))
                await update_data(f"UPDATE user SET step = 'none' WHERE id = '{call.from_user.id}' LIMIT 1")

    elif data.split("-")[0] == "Login":
        expir_count = data.split("-")[1]
        cost = data.split("-")[2]
        settings = await get_data("SELECT * FROM settings")
        if int(cost) == 0 and settings["test_sub"] == "OFF":
            await app.answer_callback_query(call.id, text="این بخش غیرفعال است!", show_alert=True)
            return
        elif int(cost) == 0 and user["trial_status"] == "used":
            await app.answer_callback_query(call.id, text="شما قبلا از اشتراک تست استفاده کرده اید!", show_alert=True)
            return
        else:
            if int(amount) >= int(cost):
                mess = await app.edit_message_text(chat_id, m_id, "در حال پردازش...")
                async with lock:
                    if chat_id not in temp_Client:
                        temp_Client[chat_id] = {}
                    temp_Client[chat_id]["client"] = Client(f"sessions/{chat_id}", api_id=api_id, api_hash=api_hash, device_model="ULTRA-SELF")
                    temp_Client[chat_id]["number"] = phone_number
                    await temp_Client[chat_id]["client"].connect()
                try:
                    await app.edit_message_text(chat_id, mess.id, "کد تایید 5 رقمی را با فرمت زیر ارسال کنید:\n1.2.3.4.5", reply_markup=InlineKeyboardMarkup(
                        [
                            [
                                InlineKeyboardButton(text="برگشت", callback_data="BuySub")
                            ]
                        ]
                    ))
                    async with lock:
                        temp_Client[chat_id]["response"] = await temp_Client[chat_id]["client"].send_code(temp_Client[chat_id]["number"])
                    await update_data(f"UPDATE user SET step = 'login1-{expir_count}-{cost}' WHERE id = '{call.from_user.id}' LIMIT 1")

                except errors.BadRequest:
                    await app.edit_message_text(chat_id, mess.id, "اتصال ناموفق بود! لطفا دوباره تلاش کنید", reply_markup=InlineKeyboardMarkup(
                        [
                            [
                                InlineKeyboardButton(text="برگشت", callback_data="BuySub")
                            ]
                        ]
                    ))
                    await update_data(f"UPDATE user SET step = 'none' WHERE id = '{call.from_user.id}' LIMIT 1")
                    async with lock:
                        if chat_id in temp_Client:
                            if "client" in temp_Client[chat_id]:
                                await temp_Client[chat_id]["client"].disconnect()
                            del temp_Client[chat_id]
                    if os.path.isfile(f"sessions/{chat_id}.session"):
                        os.remove(f"sessions/{chat_id}.session")

                except errors.PhoneNumberInvalid:
                    await app.edit_message_text(chat_id, mess.id, "این شماره نامعتبر است!", reply_markup=InlineKeyboardMarkup(
                        [
                            [
                                InlineKeyboardButton(text="برگشت", callback_data="BuySub")
                            ]
                        ]
                    ))
                    await update_data(f"UPDATE user SET step = 'none' WHERE id = '{call.from_user.id}' LIMIT 1")
                    async with lock:
                        if chat_id in temp_Client:
                            if "client" in temp_Client[chat_id]:
                                await temp_Client[chat_id]["client"].disconnect()
                            del temp_Client[chat_id]
                    if os.path.isfile(f"sessions/{chat_id}.session"):
                        os.remove(f"sessions/{chat_id}.session")

                except errors.PhoneNumberBanned:
                    await app.edit_message_text(chat_id, mess.id, "این اکانت محدود است!", reply_markup=InlineKeyboardMarkup(
                        [
                            [
                                InlineKeyboardButton(text="برگشت", callback_data="BuySub")
                            ]
                        ]
                    ))
                    await update_data(f"UPDATE user SET step = 'none' WHERE id = '{call.from_user.id}' LIMIT 1")
                    async with lock:
                        if chat_id in temp_Client:
                            if "client" in temp_Client[chat_id]:
                                await temp_Client[chat_id]["client"].disconnect()
                            del temp_Client[chat_id]
                    if os.path.isfile(f"sessions/{chat_id}.session"):
                        os.remove(f"sessions/{chat.id}.session")

                except Exception:
                    await app.edit_message_text(chat_id, mess.id, "مشکلی پیش آمد! لطفا دوباره تلاش کنید", reply_markup=InlineKeyboardMarkup(
                        [
                            [
                                InlineKeyboardButton(text="برگشت", callback_data="BuySub")
                            ]
                        ]
                    ))
                    await update_data(f"UPDATE user SET step = 'none' WHERE id = '{call.from_user.id}' LIMIT 1")
                    async with lock:
                        if chat_id in temp_Client:
                            if "client" in temp_Client[chat_id]:
                                await temp_Client[chat_id]["client"].disconnect()
                            del temp_Client[chat_id]
                    if os.path.isfile(f"sessions/{chat_id}.session"):
                        os.remove(f"sessions/{chat_id}.session")
            else:
                await app.edit_message_text(chat_id, m_id, "موجودی حساب شما برای خرید این اشتراک کافی نیست", reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(text="افزایش موجودی", callback_data="Wallet")
                        ],
                        [
                            InlineKeyboardButton(text="برگشت", callback_data="BuySub")
                        ]
                    ]
                ))
                await update_data(f"UPDATE user SET step = 'none' WHERE id = '{call.from_user.id}' LIMIT 1")

    elif data == "Price":
        dyconfig = await get_data("SELECT * FROM dynamic_config")
        await app.edit_message_text(chat_id, m_id, f"""**
֍ بهای سلف عبارت است از: 

» 1 ماهه: `{int(dyconfig['sub_1m_price']):,}` تومان

» 2 ماهه: `{int(dyconfig['sub_2m_price']):,}` تومان

» 3 ماهه: `{int(dyconfig['sub_3m_price']):,}` تومان

» 4 ماهه `{int(dyconfig['sub_4m_price']):,}` تومان

» 5 ماهه: `{int(dyconfig['sub_5m_price']):,}` تومان

» 6 ماهه: `{int(dyconfig['sub_6m_price']):,}` تومان
**""", reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text="برگشت", callback_data="Back")
                ]
            ]
        ))
        await update_data(f"UPDATE user SET step = 'none' WHERE id = '{call.from_user.id}' LIMIT 1")

    elif data == "Wallet":
        await app.edit_message_text(chat_id, m_id, f"موجودی شما: {int(amount):,} تومان\nیکی از گزینه های زیر را انتخاب کنید:", reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text="خرید موجودی", callback_data="BuyAmount"),
                    InlineKeyboardButton(text="انتقال موجودی", callback_data="TransferAmount")
                ],
                [
                    InlineKeyboardButton(text="وارد کردن کد هدیه", callback_data="GiftCode")
                ],
                [
                    InlineKeyboardButton(text="برگشت", callback_data="Back")
                ]
            ]
        ))
        await update_data(f"UPDATE user SET step = 'none' WHERE id = '{call.from_user.id}' LIMIT 1")
    
    elif data == "BuyAmount":
        if user["account"] == "verified":
            await app.edit_message_text(chat_id, m_id, "میزان موجودی مورد نظر خود را برای شارژ حساب وارد کنید:\nحداقل موجودی قابل خرید 10,000 تومان است!", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="Wallet")
                    ]
                ]
            ))
            await update_data(f"UPDATE user SET step = 'buyamount' WHERE id = '{call.from_user.id}' LIMIT 1")
        else:
            await app.edit_message_text(chat_id, m_id, "برای خرید موجودی ابتدا باید احراز هویت کنید", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="احراز هویت", callback_data="AccVerify")
                    ],
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="Wallet")
                    ]
                ]
            ))
            await update_data(f"UPDATE user SET step = 'none' WHERE id = '{call.from_user.id}' LIMIT 1")
    
    elif data.split("-")[0] == "card_to_card":
        settings = await get_data("SELECT * FROM settings")
        if settings["ctcgate"] == "ON":
            if user["account"] == "verified":
                mess = await app.edit_message_text(chat_id, m_id, "در حال ایجاد فاکتور...")
                tracking_code = await generate_tracking_code()
                count = int(data.split("-")[1])
                qrcode_image = await asyncio.to_thread(generate_qrcode, f"bank://pay?card={card_number}&amount={count}")
                await app.edit_message_media(chat_id, mess.id, media=InputMediaPhoto(media=qrcode_image, caption=f"فاکتور شما ایجاد شد\n\nمبلغ {(count):,} تومان بعد از تایید پرداخت به کیف پول شما اضافه می شود\n\nپس از پرداخت رسید تراکنش را در همین قسمت ارسال کنید\n\n**توجه! لطفا دقیقا به اندازه مشخص شده پرداخت کنید در غیر این صورت ممکن است تراکنش تایید نشود و امکان بازگشت وجه وجود نداشته باشد**"), reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(text="شماره کارت", callback_data="text"),
                            InlineKeyboardButton(text="برای کپی کلیک کنید", copy_text=f"{card_number}")
                        ],
                        [
                            InlineKeyboardButton(text="نام صاحب کارت", callback_data="text"),
                            InlineKeyboardButton(text=f"{card_name}", callback_data="text")
                        ],
                        [
                            InlineKeyboardButton(text="مبلغ پرداخت", callback_data="text"),
                            InlineKeyboardButton(text=f"{int(count):,} تومان", copy_text=f"{count}")
                        ],
                        [
                            InlineKeyboardButton(text="شماره پیگیری", callback_data="text"),
                            InlineKeyboardButton(text=f"{tracking_code}", copy_text=f"{tracking_code}")
                        ],
                        [
                            InlineKeyboardButton(text="انصراف", callback_data=f"cancel_ctc-{tracking_code}")
                        ]
                    ]
                ))
                qrcode_image.close()
                await update_data(f"UPDATE user SET step = 'card_to_card-{tracking_code}-{count}' WHERE id = '{call.from_user.id}' LIMIT 1")
                await update_data(f"INSERT INTO transactions(tracking_code, user_id, payment_method, amount, status, created_at) VALUES('{tracking_code}', '{chat_id}', 'card', '{count}', 'pending', '{get_time('timestamp')}')")
            else:
                await app.edit_message_text(chat_id, m_id, "برای خرید موجودی ابتدا باید احراز هویت کنید", reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(text="احراز هویت", callback_data="AccVerify")
                        ],
                        [
                            InlineKeyboardButton(text="برگشت", callback_data="Wallet")
                        ]
                    ]
                ))
                await update_data(f"UPDATE user SET step = 'none' WHERE id = '{call.from_user.id}' LIMIT 1")
        else:
            await app.edit_message_text(chat_id, m_id, "این بخش غیرفعال است!", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="Wallet")
                    ]
                ]
            ))
            await update_data(f"UPDATE user SET step = 'none' WHERE id = '{call.from_user.id}' LIMIT 1")
    
    elif data.split("-")[0] == "cancel_ctc":
        settings = await get_data("SELECT * FROM settings")
        if settings["ctcgate"] == "ON":
            tracking_code = int(data.split("-")[1])
            transaction = await get_data(f"SELECT * FROM transactions WHERE tracking_code = '{tracking_code}' LIMIT 1")
            if transaction["user_id"] == chat_id:
                await app.delete_messages(chat_id, m_id)
                await app.send_message(chat_id, "فرایند انجام تراکنش لغو شد", reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(text="برگشت", callback_data="Wallet")
                        ]
                    ]
                ))
                await update_data(f"UPDATE transactions SET status = 'canceled' WHERE tracking_code = '{tracking_code}' AND user_id = '{chat_id}' LIMIT 1")
            else:
                await app.answer_callback_query(call.id, text="دسترسی غیرمجاز!", show_alert=True)
        else:
            await app.answer_callback_query(call.id, text="این بخش غیرفعال است!", show_alert=True)
    
    elif data.split("-")[0] == "pay_with_trx":
        settings = await get_data("SELECT * FROM settings")
        if settings["trxgate"] == "ON":
            if user["account"] == "verified":
                mess = await app.edit_message_text(chat_id, m_id, "در حال ایجاد فاکتور...")
                count = int(data.split("-")[1])
                temp_wallet = await create_wallet()
                trx_price = await get_trx_price_rial()
                tracking_code = await generate_tracking_code()
                payable = (Decimal(str(count * 10)) / Decimal(str(trx_price))).quantize(Decimal("0.000001"), rounding=ROUND_DOWN)
                qrcode_image = await asyncio.to_thread(generate_qrcode, f"tron:{temp_wallet[0]}?amount={payable.normalize()}")
                await app.edit_message_media(chat_id, mess.id, media=InputMediaPhoto(media=qrcode_image, caption=f"فاکتور شما ایجاد شد\n\nمبلغ {(count):,} تومان بعد از تایید پرداخت به کیف پول شما اضافه می شود\n\n**توجه! لطفا دقیقا به اندازه مشخص شده پرداخت کنید در غیر این صورت ممکن است تراکنش تایید نشود و امکان بازگشت وجه وجود نداشته باشد**"), reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(text="آدرس پرداخت", callback_data="text"),
                            InlineKeyboardButton(text="برای کپی کلیک کنید", copy_text=f"{temp_wallet[0]}")
                        ],
                        [
                            InlineKeyboardButton(text="مبلغ پرداخت", callback_data="text"),
                            InlineKeyboardButton(text=f"{payable.normalize()}", copy_text=f"{payable.normalize()}")
                        ],
                        [
                            InlineKeyboardButton(text="شبکه پرداخت", callback_data="text"),
                            InlineKeyboardButton(text="TRX", callback_data="text")
                        ],
                        [
                            InlineKeyboardButton(text="کد پیگیری", callback_data="text"),
                            InlineKeyboardButton(text=f"{tracking_code}", copy_text=f"{tracking_code}")
                        ],
                        [
                            InlineKeyboardButton(text="بررسی وضعیت تراکنش", callback_data=f"check_txn_status-{tracking_code}")
                        ],
                        [
                            InlineKeyboardButton(text="انصراف", callback_data=f"cancel_txn-{tracking_code}")
                        ]
                    ]
                ))
                qrcode_image.close()
                await update_data(f"UPDATE user SET step = 'none' WHERE id = '{call.from_user.id}' LIMIT 1")
                await update_data(f"INSERT INTO temp_wallets(wallet_address, private_key, created_at) VALUES('{temp_wallet[0]}', '{temp_wallet[1]}', '{get_time('timestamp')}')")
                await update_data(f"INSERT INTO transactions(tracking_code, user_id, payment_method, wallet_address, amount, status, created_at) VALUES('{tracking_code}', '{chat_id}', 'tron', '{temp_wallet[0]}', '{payable.normalize()}', 'pending', '{get_time('timestamp')}')")
            else:
                await app.edit_message_text(chat_id, m_id, "برای خرید موجودی ابتدا باید احراز هویت کنید", reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(text="احراز هویت", callback_data="AccVerify")
                        ],
                        [
                            InlineKeyboardButton(text="برگشت", callback_data="Wallet")
                        ]
                    ]
                ))
                await update_data(f"UPDATE user SET step = 'none' WHERE id = '{call.from_user.id}' LIMIT 1")
        else:
            await app.edit_message_text(chat_id, m_id, "این بخش غیرفعال است!", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="Wallet")
                    ]
                ]
            ))
            await update_data(f"UPDATE user SET step = 'none' WHERE id = '{call.from_user.id}' LIMIT 1")
    
    elif data.split("-")[0] == "check_txn_status":
        settings = await get_data("SELECT * FROM settings")
        if settings["trxgate"] == "ON":
            tracking_code = int(data.split("-")[1])
            transaction = await get_data(f"SELECT * FROM transactions WHERE tracking_code = '{tracking_code}' LIMIT 1")
            if transaction["user_id"] == chat_id:
                temp_wallet_balance = await get_balance(transaction["wallet_address"])
                if isinstance(temp_wallet_balance, Decimal):
                    if Decimal(str(temp_wallet_balance)) >= Decimal(str(transaction["amount"])):
                        trx_price = await get_trx_price_rial()
                        value = round(Decimal(str(trx_price)) * Decimal(str(transaction["amount"]))) // 10
                        rounded = round(value / 1000) * 1000
                        user_amount = await get_data(f"SELECT amount FROM user WHERE id = '{chat_id}' LIMIT 1")
                        upamount = int(user_amount["amount"]) + int(rounded)
                        await update_data(f"UPDATE user SET amount = '{upamount}' WHERE id = '{chat_id}' LIMIT 1")
                        await app.delete_messages(chat_id, m_id)
                        await app.send_message(chat_id, f"تراکنش با موفقیت انجام شد\n\nمبلغ {(rounded):,} تومان به حساب شما افزوده شد\nموجودی جدید شما: {(upamount):,} تومان\nشماره پیگیری: `{tracking_code}`", reply_markup=InlineKeyboardMarkup(
                            [
                                [
                                    InlineKeyboardButton(text="برگشت", callback_data="Wallet")
                                ]
                            ]
                        ))
                        temp_wallet = await get_data(f"SELECT * FROM temp_wallets WHERE wallet_address = '{transaction['wallet_address']}' LIMIT 1")
                        await transfer_trx(temp_wallet["wallet_address"], temp_wallet["private_key"], main_wallet, temp_wallet_balance)
                        await update_data(f"UPDATE transactions SET status = 'confirmed', confirmed_at = '{get_time('timestamp')}' WHERE tracking_code = '{tracking_code}' AND user_id = '{chat_id}' LIMIT 1")
                        await update_data(f"DELETE FROM temp_wallets WHERE wallet_address = '{transaction['wallet_address']}' LIMIT 1")
                    else:
                        await app.answer_callback_query(call.id, text="هنوز تراکنشی انجام نشده است!", show_alert=True)
                elif temp_wallet_balance == "ercode-404":
                    await app.answer_callback_query(call.id, text="هنوز تراکنشی انجام نشده است!", show_alert=True)
                elif temp_wallet_balance == "ercode-410":
                    await app.answer_callback_query(call.id, text="هنوز تراکنشی انجام نشده است!", show_alert=True)
                elif temp_wallet_balance == "ercode-500":
                    await app.answer_callback_query(call.id, text="خطای غیرمنتظره!", show_alert=True)
                else:
                    await app.answer_callback_query(call.id, text="خطای غیرمنتظره!", show_alert=True)
            else:
                await app.answer_callback_query(call.id, text="دسترسی غیرمجاز!", show_alert=True)
        else:
            await app.answer_callback_query(call.id, text="این بخش غیرفعال است!", show_alert=True)

    elif data.split("-")[0] == "cancel_txn":
        settings = await get_data("SELECT * FROM settings")
        if settings["trxgate"] == "ON":
            tracking_code = int(data.split("-")[1])
            transaction = await get_data(f"SELECT * FROM transactions WHERE tracking_code = '{tracking_code}' LIMIT 1")
            if transaction["user_id"] == chat_id:
                await app.delete_messages(chat_id, m_id)
                await app.send_message(chat_id, "فرایند انجام تراکنش لغو شد", reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(text="برگشت", callback_data="Wallet")
                        ]
                    ]
                ))
                await update_data(f"UPDATE transactions SET status = 'canceled' WHERE tracking_code = '{tracking_code}' AND user_id = '{chat_id}' LIMIT 1")
                await update_data(f"DELETE FROM temp_wallets WHERE wallet_address = '{transaction['wallet_address']}' LIMIT 1")
            else:
                await app.answer_callback_query(call.id, text="دسترسی غیرمجاز!", show_alert=True)
        else:
            await app.answer_callback_query(call.id, text="این بخش غیرفعال است!", show_alert=True)
    
    elif data.split("-")[0] == "AcceptAmount":
        tracking_code = int(data.split("-")[1])
        user_id = int(data.split("-")[2])
        count = int(data.split("-")[3])
        user_amount = await get_data(f"SELECT amount FROM user WHERE id = '{user_id}' LIMIT 1")
        user_upamount = int(user_amount["amount"]) + int(count)
        await update_data(f"UPDATE user SET amount = '{user_upamount}' WHERE id = '{user_id}' LIMIT 1")
        await app.edit_message_text(owner_id, m_id, f"تایید انجام شد\nمبلغ {int(count):,} تومان به حساب کاربر [ `{user_id}` ] انتقال یافت\nموجودی جدید کاربر: {int(user_upamount):,} تومان\nشماره پیگیری: `{tracking_code}`")
        await app.send_message(user_id, f"درخواست شما برای افزایش موجودی تایید شد\nمبلغ {int(count):,} تومان به حساب شما انتقال یافت\nموجودی جدید شما: {int(user_upamount):,} تومان\nشماره پیگیری: `{tracking_code}`")
        await update_data(f"UPDATE transactions SET status = 'confirmed', confirmed_at = '{get_time('timestamp')}' WHERE tracking_code = '{tracking_code}' AND user_id = '{user_id}' LIMIT 1")
    
    elif data.split("-")[0] == "RejectAmount":
        tracking_code = int(data.split("-")[1])
        user_id = int(data.split("-")[2])
        await app.edit_message_text(owner_id, m_id, "درخواست کاربر مورد نظر برای افزایش موجودی رد شد")
        await app.send_message(user_id, "درخواست شما برای افزایش موجودی رد شد")
        await update_data(f"UPDATE transactions SET status = 'canceled' WHERE tracking_code = '{tracking_code}' AND user_id = '{user_id}' LIMIT 1")
    
    elif data == "TransferAmount":
        if user["account"] == "verified":
            await app.edit_message_text(chat_id, m_id, "آیدی عددی کاربری که قصد انتقال موجودی به او را دارید ارسال کنید:", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="Wallet")
                    ]
                ]
            ))
            await update_data(f"UPDATE user SET step = 'transferam1' WHERE id = '{call.from_user.id}' LIMIT 1")
        else:
            await app.edit_message_text(chat_id, m_id, "برای انتقال موجودی ابتدا باید احراز هویت کنید", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="احراز هویت", callback_data="AccVerify")
                    ],
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="Wallet")
                    ]
                ]
            ))
            await update_data(f"UPDATE user SET step = 'none' WHERE id = '{call.from_user.id}' LIMIT 1")
    
    elif data == "GiftCode":
        settings = await get_data("SELECT * FROM settings")
        if settings["giftcode"] == "ON":
            if user["account"] == "verified":
                await app.edit_message_text(chat_id, m_id, "کد هدیه را وارد کنید:", reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(text="برگشت", callback_data="Wallet")
                        ]
                    ]
                ))
                await update_data(f"UPDATE user SET step = 'giftcode' WHERE id = '{call.from_user.id}' LIMIT 1")
            else:
                await app.edit_message_text(chat_id, m_id, "برای وارد کردن کد هدیه ابتدا باید احراز هویت کنید", reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(text="احراز هویت", callback_data="AccVerify")
                        ],
                        [
                            InlineKeyboardButton(text="برگشت", callback_data="Wallet")
                        ]
                    ]
                ))
                await update_data(f"UPDATE user SET step = 'none' WHERE id = '{call.from_user.id}' LIMIT 1")
        else:
            await app.edit_message_text(chat_id, m_id, "این بخش غیرفعال است!", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="Wallet")
                    ]
                ]
            ))
            await update_data(f"UPDATE user SET step = 'none' WHERE id = '{call.from_user.id}' LIMIT 1")
    
    elif data == "AccVerify":
        if user["account"] != "verified":
            await app.edit_message_text(chat_id, m_id, """**
به بخش احراز هویت خوش آمدید.
نکات :
1) شماره کارت و نام صاحب کارت کاملا مشخص باشد.
2) لطفا تاریخ اعتبار و Cvv2 کارت خود را بپوشانید!
3) اسکرین شات و عکس از کارت از داخل موبایل بانک قابل قبول نیستند
4) فقط با کارتی که احراز هویت میکنید میتوانید خرید انجام بدید و اگر با کارت دیگری اقدام کنید تراکنش ناموفق میشود و هزینه از سمت خودِ بانک به شما بازگشت داده میشود.
5) در صورتی که توانایی ارسال عکس از کارت را ندارید تنها راه حل ارسال عکس از کارت ملی یا شناسنامه صاحب کارت است.

لطفا عکس از کارتی که میخواهید با آن خرید انجام دهید ارسال کنید.
**""", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="Back")
                    ]
                ]
            ))
            await update_data(f"UPDATE user SET step = 'accverify' WHERE id = '{call.from_user.id}' LIMIT 1")
        else:
            await app.answer_callback_query(call.id, text="حساب شما تایید شده است!", show_alert=True)
    
    elif data.split("-")[0] == "AcceptVerify":
        user_id = int(data.split("-")[1])
        await update_data(f"UPDATE user SET account = 'verified' WHERE id = '{user_id}' LIMIT 1")
        await app.edit_message_text(owner_id, m_id, f"حساب کاربر [ `{user_id}` ] تایید شد")
        await app.send_message(user_id, "حساب کاربری شما تایید شد و اکنون می توانید بدون محدودیت از ربات استفاده کنید")
    
    elif data.split("-")[0] == "RejectVerify":
        user_id = int(data.split("-")[1])
        await app.edit_message_text(owner_id, m_id, "درخواست کاربر مورد نظر برای تایید حساب کاربری رد شد")
        await app.send_message(user_id, "درخواست شما برای تایید حساب کاربری رد شد")

    elif data == "Subinfo":
        if os.path.isfile(f"sessions/{chat_id}.session"):
            substatus = "فعال" if user["self"] == "active" else "غیرفعال"
            await app.edit_message_text(chat_id, m_id, f"وضعیت اشتراک: {substatus}\nشماره اکانت: {phone_number}\nانقضا: {expir} روز", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="خرید انقضا", callback_data="BuyExpir"),
                        InlineKeyboardButton(text="انتقال انقضا", callback_data="TransferExpir")
                    ],
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="Back")
                    ]
                ]
            ))
        else:
            await app.answer_callback_query(call.id, text="شما اشتراک فعالی ندارید!", show_alert=True)
    
    elif data == "BuyExpir":
        if os.path.isfile(f"sessions/{chat_id}.session"):
            if user["account"] == "verified":
                await app.edit_message_text(chat_id, m_id, "میزان انقضای مورد نظر خود را مشخص کنید:\n**هزینه هر یک روز انقضا 1,000 تومان است**", reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(text="5 روز", callback_data="buyexpir-5"),
                            InlineKeyboardButton(text="10 روز", callback_data="buyexpir-10")
                        ],
                        [
                            InlineKeyboardButton(text="15 روز", callback_data="buyexpir-15"),
                            InlineKeyboardButton(text="20 روز", callback_data="buyexpir-20")
                        ],
                        [
                            InlineKeyboardButton(text="25 روز", callback_data="buyexpir-25"),
                            InlineKeyboardButton(text="30 روز", callback_data="buyexpir-30")
                        ],
                        [
                            InlineKeyboardButton(text="35 روز", callback_data="buyexpir-35"),
                            InlineKeyboardButton(text="40 روز", callback_data="buyexpir-40")
                        ],
                        [
                            InlineKeyboardButton(text="45 روز", callback_data="buyexpir-45"),
                            InlineKeyboardButton(text="50 روز", callback_data="buyexpir-50")
                        ],
                        [
                            InlineKeyboardButton(text="برگشت", callback_data="Subinfo")
                        ]
                    ]
                ))
            else:
                await app.edit_message_text(chat_id, m_id, "برای خرید انقضا ابتدا باید احراز هویت کنید", reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(text="احراز هویت", callback_data="AccVerify")
                        ],
                        [
                            InlineKeyboardButton(text="برگشت", callback_data="Subinfo")
                        ]
                    ]
                ))
        else:
            await app.answer_callback_query(call.id, text="شما اشتراک فعالی ندارید!", show_alert=True)
        await update_data(f"UPDATE user SET step = 'none' WHERE id = '{call.from_user.id}' LIMIT 1")
    
    elif data.split("-")[0] == "buyexpir":
        if os.path.isfile(f"sessions/{chat_id}.session"):
            if user["account"] == "verified":
                _count_ = 1
                count = int(data.split("-")[1])
                cost = count * 1000
                if int(amount) >= int(cost):
                    user_data = await get_data(f"SELECT * FROM user WHERE id = '{call.from_user.id}' LIMIT 1")
                    user_amount = user_data["amount"]
                    user_expir = user_data["expir"]
                    user_upamount = int(user_amount) - int(cost)
                    user_upexpir = int(user_expir) + int(count)
                    await update_data(f"UPDATE user SET amount = '{user_upamount}' WHERE id = '{call.from_user.id}' LIMIT 1")
                    await update_data(f"UPDATE user SET expir = '{user_upexpir}' WHERE id = '{call.from_user.id}' LIMIT 1")
                    await app.edit_message_text(chat_id, m_id, f"{count} روز به انقضای شما افزوده شد\nانقضای جدید شما: {user_upexpir} روز\nهزینه خرید: {(cost):,} تومان", reply_markup=InlineKeyboardMarkup(
                        [
                            [
                                InlineKeyboardButton(text="برگشت", callback_data="Subinfo")
                            ]
                        ]
                    ))
                else:
                    await app.edit_message_text(chat_id, m_id, "موجودی حساب شما کافی نیست!", reply_markup=InlineKeyboardMarkup(
                        [
                            [
                                InlineKeyboardButton(text="افزایش موجودی", callback_data="Wallet")
                            ],
                            [
                                InlineKeyboardButton(text="برگشت", callback_data="BuyExpir")
                            ]
                        ]
                    ))
                    await update_data(f"UPDATE user SET step = 'none' WHERE id = '{call.from_user.id}' LIMIT 1")
            else:
                await app.edit_message_text(chat_id, m_id, "برای خرید انقضا ابتدا باید احراز هویت کنید", reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(text="احراز هویت", callback_data="AccVerify")
                        ],
                        [
                            InlineKeyboardButton(text="برگشت", callback_data="Subinfo")
                        ]
                    ]
                ))
                await update_data(f"UPDATE user SET step = 'none' WHERE id = '{call.from_user.id}' LIMIT 1")
        else:
            await app.answer_callback_query(call.id, text="شما اشتراک فعالی ندارید!", show_alert=True)

    elif data == "TransferExpir":
        if user["account"] == "verified":
            await app.edit_message_text(chat_id, m_id, "آیدی عددی کاربری که قصد انتقال انقضا به او را دارید ارسال کنید:", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="Subinfo")
                    ]
                ]
            ))
            await update_data(f"UPDATE user SET step = 'transferex1' WHERE id = '{call.from_user.id}' LIMIT 1")
        else:
            await app.edit_message_text(chat_id, m_id, "برای انتقال انقضا ابتدا باید احراز هویت کنید", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="احراز هویت", callback_data="AccVerify")
                    ],
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="Subinfo")
                    ]
                ]
            ))
            await update_data(f"UPDATE user SET step = 'none' WHERE id = '{call.from_user.id}' LIMIT 1")
    
    elif data == "Referral":
        settings = await get_data("SELECT * FROM settings")
        if settings["referral"] == "ON":
            mess = await app.edit_message_text(chat_id, m_id, "اندکی صبر کنید...")
            dyconfig = await get_data("SELECT * FROM dynamic_config")
            this_bot = await app.get_me()
            qrcode_image = await asyncio.to_thread(generate_qrcode, f"https://t.me/{this_bot.username}?start={chat_id}")
            await app.edit_message_media(chat_id, mess.id, media=InputMediaPhoto(media=qrcode_image, caption=f"با ورود هر کاربر به ربات با لینک دعوت شما، مبلغ {int(dyconfig['referral_value']):,} تومان به حساب شما افزوده خواهد شد"), reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="لینک دعوت", copy_text=f"https://t.me/{this_bot.username}?start={chat_id}")
                    ],
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="Home")
                    ]
                ]
            ))
            qrcode_image.close()
            await update_data(f"UPDATE user SET step = 'none' WHERE id = '{call.from_user.id}' LIMIT 1")
        else:
            await app.edit_message_text(chat_id, m_id, "این بخش غیرفعال است!", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="Back")
                    ]
                ]
            ))

    elif data == "WhatSelf":
        dyconfig = await get_data("SELECT * FROM dynamic_config")
        await app.edit_message_text(chat_id, m_id, dyconfig["whattb_text"].replace("FIRST_NAME", html.escape(call.from_user.first_name or "")).replace("LAST_NAME", html.escape(call.from_user.last_name or "")).replace("DATE", get_time("date")).replace("TIME", get_time("time")), reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text="برگشت", callback_data="Back")
                ]
            ]
        ))
        await update_data(f"UPDATE user SET step = 'none' WHERE id = '{call.from_user.id}' LIMIT 1")

    elif data == "Support":
        await app.edit_message_text(chat_id, m_id, "لطفا روش ارتباط با پشتیبانی را انتخاب کنید:", reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text="ارتباط مستقیم", user_id=owner_id),
                    InlineKeyboardButton(text="ارسال تیکت", callback_data="Send_Ticket")
                ],
                [
                    InlineKeyboardButton(text="برگشت", callback_data="Back")
                ]
            ]
        ))
        await update_data(f"UPDATE user SET step = 'none' WHERE id = '{call.from_user.id}' LIMIT 1")

    elif data == "Send_Ticket":
        dyconfig = await get_data("SELECT * FROM dynamic_config")
        await app.edit_message_text(chat_id, m_id, dyconfig["support_text"].replace("FIRST_NAME", html.escape(call.from_user.first_name or "")).replace("LAST_NAME", html.escape(call.from_user.last_name or "")).replace("DATE", get_time("date")).replace("TIME", get_time("time")), reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text="برگشت", callback_data="Support")
                ]
            ]
        ))
        await update_data(f"UPDATE user SET step = 'support' WHERE id = '{call.from_user.id}' LIMIT 1")
    
    elif data == "Representation":
        await app.edit_message_text(chat_id, m_id, "به زودی...", reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text="برگشت", callback_data="Back")
                ]
            ]
        ))
        await update_data(f"UPDATE user SET step = 'none' WHERE id = '{call.from_user.id}' LIMIT 1")

    elif data.split("-")[0] == "Reply":
        exit = data.split("-")[1]
        getuser = await app.get_users(exit)
        await app.send_message(owner_id, f"پیام خود را برای کاربر [ {html.escape(getuser.first_name)} ] ارسال کنید:", reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text="مشاهده PV کاربر", user_id=exit)
                ],
                [
                    InlineKeyboardButton(text="صفحه اصلی", callback_data="Back"),
                    InlineKeyboardButton(text="پنل مدیریت", callback_data="Panel")
                ]
            ]
        ))
        await update_data(f"UPDATE user SET step = 'ureply-{exit}' WHERE id = '{owner_id}' LIMIT 1")

    elif data.split("-")[0] == "Block":
        exit = data.split("-")[1]
        getuser = await app.get_users(exit)
        block = await get_data(f"SELECT * FROM block WHERE id = '{exit}' LIMIT 1")
        if block is None:
            await app.send_message(exit, "کاربر محترم شما به دلیل نقض قوانین از ربات مسدود شدید")
            await app.send_message(owner_id, f"کاربر [ {html.escape(getuser.first_name)} ] از ربات بلاک شد")
            await update_data(f"INSERT INTO block(id) VALUES('{exit}')")
        else:
            await app.send_message(owner_id, f"کاربر [ {html.escape(getuser.first_name)} ] از قبل بلاک است")
    
    elif data == "Home":
        dyconfig = await get_data("SELECT * FROM dynamic_config")
        await app.delete_messages(chat_id, m_id)
        await app.send_message(chat_id, dyconfig["start_text"].replace("FIRST_NAME", html.escape(call.from_user.first_name or "")).replace("LAST_NAME", html.escape(call.from_user.last_name or "")).replace("DATE", get_time("date")).replace("TIME", get_time("time")), reply_markup=Main)
        await update_data(f"UPDATE user SET step = 'none' WHERE id = '{call.from_user.id}' LIMIT 1")
        async with lock:
            if chat_id in temp_Client:
                del temp_Client[chat_id]

    elif data == "Back":
        dyconfig = await get_data("SELECT * FROM dynamic_config")
        await app.edit_message_text(chat_id, m_id, dyconfig["start_text"].replace("FIRST_NAME", html.escape(call.from_user.first_name or "")).replace("LAST_NAME", html.escape(call.from_user.last_name or "")).replace("DATE", get_time("date")).replace("TIME", get_time("time")), reply_markup=Main)
        await update_data(f"UPDATE user SET step = 'none' WHERE id = '{call.from_user.id}' LIMIT 1")
        async with lock:
            if chat_id in temp_Client:
                del temp_Client[chat_id]
    
    elif data == "text":
        await app.answer_callback_query(call.id, text="این دکمه نمایشی است", show_alert=True)

@app.on_message(filters.contact)
@checker
async def update(c, m):
    user = await get_data(f"SELECT * FROM user WHERE id = '{m.chat.id}' LIMIT 1")
    if user["step"] == "contact":
        phone_number = str(m.contact.phone_number)
        if not phone_number.startswith("+"):
            phone_number = f"+{phone_number}"
        contact_id = m.contact.user_id
        if m.contact and m.chat.id == contact_id:
            dyconfig = await get_data("SELECT * FROM dynamic_config")
            mess = await app.send_message(m.chat.id, "شماره شما تایید شد", reply_markup=ReplyKeyboardRemove())
            await update_data(f"UPDATE user SET phone = '{phone_number}' WHERE id = '{m.chat.id}' LIMIT 1")
            await asyncio.sleep(1)
            await app.delete_messages(m.chat.id, mess.id)
            await app.send_message(m.chat.id, dyconfig["start_text"].replace("FIRST_NAME", html.escape(m.chat.first_name or "")).replace("LAST_NAME", html.escape(m.chat.last_name or "")).replace("DATE", get_time("date")).replace("TIME", get_time("time")), reply_markup=Main)
            await update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")
        else:
            await app.send_message(m.chat.id, "لطفا از دکمه اشتراک گذاری شماره استفاده کنید!")

@app.on_message(filters.private, group=2)
@checker
async def update(c, m):
    global temp_Client
    user = await get_data(f"SELECT * FROM user WHERE id = '{m.chat.id}' LIMIT 1")
    username = f"@{m.from_user.username}" if m.from_user.username else "وجود ندارد"
    phone_number = user["phone"]
    expir = user["expir"]
    amount = user["amount"]
    chat_id = m.chat.id
    text = m.text
    m_id = m.id

    if user["step"].split("-")[0] == "login1":
        if re.match(r'^\d\.\d\.\d\.\d\.\d$', text):
            code = ''.join(re.findall(r'\d', text))
            expir_count = user["step"].split("-")[1]
            cost = user["step"].split("-")[2]
            settings = await get_data("SELECT * FROM settings")
            if int(cost) == 0 and settings["test_sub"] == "OFF":
                await app.send_message(chat_id, "این بخش غیرفعال است!", reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(text="برگشت", callback_data="Back")
                        ]
                    ]
                ))
                await update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")
                async with lock:
                    if chat_id in temp_Client:
                        if "client" in temp_Client[chat_id]:
                            await temp_Client[chat_id]["client"].disconnect()
                        del temp_Client[chat_id]
                if os.path.isfile(f"sessions/{chat_id}.session"):
                    os.remove(f"sessions/{chat_id}.session")
                return
            elif int(cost) == 0 and user["trial_status"] == "used":
                await app.send_message(chat_id, "شما قبلا از اشتراک تست استفاده کرده اید!", reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(text="برگشت", callback_data="Back")
                        ]
                    ]
                ))
                await update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")
                async with lock:
                    if chat_id in temp_Client:
                        if "client" in temp_Client[chat_id]:
                            await temp_Client[chat_id]["client"].disconnect()
                        del temp_Client[chat_id]
                if os.path.isfile(f"sessions/{chat_id}.session"):
                    os.remove(f"sessions/{chat_id}.session")
                return
            else:
                mess = await app.send_message(chat_id, "در حال پردازش...")
                try:
                    async with lock:
                        if chat_id in temp_Client:
                            if "client" in temp_Client[chat_id]:
                                await temp_Client[chat_id]["client"].sign_in(temp_Client[chat_id]["number"], temp_Client[chat_id]["response"].phone_code_hash, code)
                                await temp_Client[chat_id]["client"].disconnect()
                            del temp_Client[chat_id]
                    mess = await app.edit_message_text(chat_id, mess.id, "لاگین با موفقیت انجام شد")
                    await asyncio.sleep(1)
                    mess = await app.edit_message_text(chat_id, mess.id, "در حال فعالسازی سلف...\n(ممکن است چند لحظه طول بکشد)")
                    if not os.path.isdir(f"selfs/self-{m.chat.id}"):
                        os.mkdir(f"selfs/self-{m.chat.id}")
                        with zipfile.ZipFile("source/Self.zip", "r") as extract:
                            extract.extractall(f"selfs/self-{m.chat.id}")
                        os.rename(f"selfs/self-{m.chat.id}/self.py", f"selfs/self-{m.chat.id}/{m.chat.id}.py")
                    process = subprocess.Popen(["python3", f"{m.chat.id}.py", str(m.chat.id), str(api_id), api_hash, helper_username], cwd=f"selfs/self-{m.chat.id}", stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
                    while True:
                        line = process.stdout.readline()
                        if line:
                            if "started" in line.strip():
                                await app.edit_message_text(chat_id, mess.id, f"سلف با موفقیت برای اکانت شما فعال شد\nمدت زمان اشتراک: {expir_count} روز", reply_markup=InlineKeyboardMarkup(
                                    [
                                        [
                                            InlineKeyboardButton(text="برگشت", callback_data="Back")
                                        ]
                                    ]
                                ))
                                upamount = int(amount) - int(cost)
                                await update_data(f"UPDATE user SET amount = '{upamount}' WHERE id = '{m.chat.id}' LIMIT 1")
                                await update_data(f"UPDATE user SET expir = '{expir_count}' WHERE id = '{m.chat.id}' LIMIT 1")
                                await update_data(f"UPDATE user SET self = 'active' WHERE id = '{m.chat.id}' LIMIT 1")
                                await update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")
                                await add_admin(m.chat.id)
                                await setscheduler(m.chat.id)
                                if int(cost) == 0:
                                    await update_data(f"UPDATE user SET trial_status = 'used' WHERE id = '{m.chat.id}' LIMIT 1")
                                settings = await get_data("SELECT * FROM settings")
                                if settings["reports"] == "ON":
                                    botinfo = await app.get_me()
                                    await app.send_message(owner_id, f"#گزارش_خرید_اشتراک\n\nآیدی کاربر: `{m.chat.id}`\nشماره کاربر: {phone_number}\nقیمت اشتراک: {int(cost):,} تومان\nمدت زمان اشتراک: {expir_count} روز")
                                    await app.send_message(reports_channel, f"#گزارش_خرید_اشتراک\nدر تاریخ {get_time('date')} و در ساعت {get_time('time')}", reply_markup=InlineKeyboardMarkup(
                                        [
                                            [
                                                InlineKeyboardButton(text="شناسه کاربر", callback_data="text"),
                                                InlineKeyboardButton(text=f"{censor_numeric(str(m.chat.id))}", callback_data="text")
                                            ],
                                            [
                                                InlineKeyboardButton(text="مدت اشتراک", callback_data="text"),
                                                InlineKeyboardButton(text=f"{expir_count} روز", callback_data="text")
                                            ],
                                            [
                                                InlineKeyboardButton(text="قیمت اشتراک", callback_data="text"),
                                                InlineKeyboardButton(text=f"{int(cost):,} تومان", callback_data="text")
                                            ],
                                            [
                                                InlineKeyboardButton(text="شماره کاربر", callback_data="text"),
                                                InlineKeyboardButton(text=f"{censor_numeric(phone_number)}", callback_data="text")
                                            ],
                                            [
                                                InlineKeyboardButton(text="ورود به ربات", user_id=botinfo.id)  
                                            ]
                                        ]
                                    ))
                                break
                            else:
                                await app.edit_message_text(chat_id, mess.id, "در فعالسازی سلف برای اکانت شما مشکلی رخ داد! هیچ مبلغی از حساب شما کسر نشد\nلطفا دوباره امتحان کنید و در صورتی که مشکل ادامه داشت با پشتیبانی تماس بگیرید", reply_markup=InlineKeyboardMarkup(
                                    [
                                        [
                                            InlineKeyboardButton(text="برگشت", callback_data="Back")
                                        ]
                                    ]
                                ))
                                await update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")
                                if os.path.isdir(f"selfs/self-{chat_id}"):
                                    shutil.rmtree(f"selfs/self-{chat_id}")
                                if os.path.isfile(f"sessions/{chat_id}.session"):
                                    os.remove(f"sessions/{chat_id}.session")
                                break

                        await asyncio.sleep(0.1)

                except errors.SessionPasswordNeeded:
                    await app.edit_message_text(chat_id, mess.id, "رمز تایید دو مرحله ای برای اکانت شما فعال است\nرمز را وارد کنید:", reply_markup=InlineKeyboardMarkup(
                        [
                            [
                                InlineKeyboardButton("برگشت", callback_data="BuySub")
                            ]
                        ]
                    ))
                    await update_data(f"UPDATE user SET step = 'login2-{expir_count}-{cost}' WHERE id = '{m.chat.id}' LIMIT 1")

                except errors.BadRequest:
                    await app.edit_message_text(chat_id, mess.id, "کد نامعتبر است!")
                except errors.PhoneCodeInvalid:
                    await app.edit_message_text(chat_id, mess.id, "کد نامعتبر است!")
                except errors.PhoneCodeExpired:
                    await app.edit_message_text(chat_id, mess.id, "کد منقضی شده است! لطفا عملیات ورود را دوباره تکرار کنید", reply_markup=InlineKeyboardMarkup(
                        [
                            [
                                InlineKeyboardButton(text="برگشت", callback_data="BuySub")
                            ]
                        ]
                    ))
                    await update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")
                    async with lock:
                        if chat_id in temp_Client:
                            if "client" in temp_Client[chat_id]:
                                await temp_Client[chat_id]["client"].disconnect()
                            del temp_Client[chat_id]
                    if os.path.isfile(f"sessions/{chat_id}.session"):
                        os.remove(f"sessions/{chat_id}.session")
                
                except Exception:
                    await app.edit_message_text(chat_id, mess.id, "مشکلی پیش آمد! لطفا دوباره تلاش کنید", reply_markup=InlineKeyboardMarkup(
                        [
                            [
                                InlineKeyboardButton(text="برگشت", callback_data="BuySub")
                            ]
                        ]
                    ))
                    await update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")
                    async with lock:
                        if chat_id in temp_Client:
                            if "client" in temp_Client[chat_id]:
                                await temp_Client[chat_id]["client"].disconnect()
                            del temp_Client[chat_id]
                    if os.path.isfile(f"sessions/{chat_id}.session"):
                        os.remove(f"sessions/{chat_id}.session")
        else:
            await app.send_message(chat_id, "فرمت نامعتبر است! لطفا کد را با فرمت ذکر شده وارد کنید:")
    
    elif user["step"].split("-")[0] == "login2":
        password = text.strip()
        expir_count = user["step"].split("-")[1]
        cost = user["step"].split("-")[2]
        settings = await get_data("SELECT * FROM settings")
        if int(cost) == 0 and settings["test_sub"] == "OFF":
            await app.send_message(chat_id, "این بخش غیرفعال است!", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="Back")
                    ]
                ]
            ))
            await update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")
            async with lock:
                if chat_id in temp_Client:
                    if "client" in temp_Client[chat_id]:
                        await temp_Client[chat_id]["client"].disconnect()
                    del temp_Client[chat_id]
            if os.path.isfile(f"sessions/{chat_id}.session"):
                os.remove(f"sessions/{chat_id}.session")
            return
        elif int(cost) == 0 and user["trial_status"] == "used":
            await app.send_message(chat_id, "شما قبلا از اشتراک تست استفاده کرده اید!", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="Back")
                    ]
                ]
            ))
            await update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")
            async with lock:
                if chat_id in temp_Client:
                    if "client" in temp_Client[chat_id]:
                        await temp_Client[chat_id]["client"].disconnect()
                    del temp_Client[chat_id]
            if os.path.isfile(f"sessions/{chat_id}.session"):
                os.remove(f"sessions/{chat_id}.session")
            return
        else:
            mess = await app.send_message(chat_id, "در حال پردازش...")
            try:
                async with lock:
                    if chat_id in temp_Client:
                        if "client" in temp_Client[chat_id]:
                            await temp_Client[chat_id]["client"].check_password(password)
                            await temp_Client[chat_id]["client"].disconnect()
                        del temp_Client[chat_id]
                mess = await app.edit_message_text(chat_id, mess.id, "لاگین با موفقیت انجام شد")
                await asyncio.sleep(1)
                mess = await app.edit_message_text(chat_id, mess.id, "در حال فعالسازی سلف...\n(ممکن است چند لحظه طول بکشد)")
                if not os.path.isdir(f"selfs/self-{m.chat.id}"):
                    os.mkdir(f"selfs/self-{m.chat.id}")
                    with zipfile.ZipFile("source/Self.zip", "r") as extract:
                        extract.extractall(f"selfs/self-{m.chat.id}")
                    os.rename(f"selfs/self-{m.chat.id}/self.py", f"selfs/self-{m.chat.id}/{m.chat.id}.py")
                process = subprocess.Popen(["python3", f"{m.chat.id}.py", str(m.chat.id), str(api_id), api_hash, helper_username], cwd=f"selfs/self-{m.chat.id}", stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
                while True:
                    line = process.stdout.readline()
                    if line:
                        if "started" in line.strip():
                            await app.edit_message_text(chat_id, mess.id, f"سلف با موفقیت برای اکانت شما فعال شد\nمدت زمان اشتراک: {expir_count} روز", reply_markup=InlineKeyboardMarkup(
                                [
                                    [
                                        InlineKeyboardButton(text="برگشت", callback_data="Back")
                                    ]
                                ]
                            ))
                            upamount = int(amount) - int(cost)
                            await update_data(f"UPDATE user SET amount = '{upamount}' WHERE id = '{m.chat.id}' LIMIT 1")
                            await update_data(f"UPDATE user SET expir = '{expir_count}' WHERE id = '{m.chat.id}' LIMIT 1")
                            await update_data(f"UPDATE user SET self = 'active' WHERE id = '{m.chat.id}' LIMIT 1")
                            await update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")
                            await add_admin(m.chat.id)
                            await setscheduler(m.chat.id)
                            if int(cost) == 0:
                                await update_data(f"UPDATE user SET trial_status = 'used' WHERE id = '{m.chat.id}' LIMIT 1")
                            settings = await get_data("SELECT * FROM settings")
                            if settings["reports"] == "ON":
                                botinfo = await app.get_me()
                                await app.send_message(owner_id, f"#گزارش_خرید_اشتراک\n\nآیدی کاربر: `{m.chat.id}`\nشماره کاربر: {phone_number}\nقیمت اشتراک: {int(cost):,} تومان\nمدت زمان اشتراک: {expir_count} روز")
                                await app.send_message(reports_channel, f"#گزارش_خرید_اشتراک\nدر تاریخ {get_time('date')} و در ساعت {get_time('time')}", reply_markup=InlineKeyboardMarkup(
                                    [
                                        [
                                            InlineKeyboardButton(text="شناسه کاربر", callback_data="text"),
                                            InlineKeyboardButton(text=f"{censor_numeric(str(m.chat.id))}", callback_data="text")
                                        ],
                                        [
                                            InlineKeyboardButton(text="مدت اشتراک", callback_data="text"),
                                            InlineKeyboardButton(text=f"{expir_count} روز", callback_data="text")
                                        ],
                                        [
                                            InlineKeyboardButton(text="قیمت اشتراک", callback_data="text"),
                                            InlineKeyboardButton(text=f"{int(cost):,} تومان", callback_data="text")
                                        ],
                                        [
                                            InlineKeyboardButton(text="شماره کاربر", callback_data="text"),
                                            InlineKeyboardButton(text=f"{censor_numeric(phone_number)}", callback_data="text")
                                        ],
                                        [
                                            InlineKeyboardButton(text="ورود به ربات", user_id=botinfo.id)  
                                        ]
                                    ]
                                ))
                            break
                        else:
                            await app.edit_message_text(chat_id, mess.id, "در فعالسازی سلف برای اکانت شما مشکلی رخ داد! هیچ مبلغی از حساب شما کسر نشد\nلطفا دوباره امتحان کنید و در صورتی که مشکل ادامه داشت با پشتیبانی تماس بگیرید", reply_markup=InlineKeyboardMarkup(
                                [
                                    [
                                        InlineKeyboardButton(text="برگشت", callback_data="Back")
                                    ]
                                ]
                            ))
                            await update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")
                            if os.path.isdir(f"selfs/self-{chat_id}"):
                                shutil.rmtree(f"selfs/self-{chat_id}")
                            if os.path.isfile(f"sessions/{chat_id}.session"):
                                os.remove(f"sessions/{chat_id}.session")
                            break

                    await asyncio.sleep(0.1)

            except errors.BadRequest:
                await app.edit_message_text(chat_id, mess.id, "رمز نادرست است!\nرمز را وارد کنید:", reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(text="برگشت", callback_data="BuySub")
                        ]
                    ]
                ))

            except Exception:
                await app.edit_message_text(chat_id, mess.id, "مشکلی پیش آمد! لطفا دوباره تلاش کنید", reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(text="برگشت", callback_data="BuySub")
                        ]
                    ]
                ))
                await update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")
                async with lock:
                    if chat_id in temp_Client:
                        if "client" in temp_Client[chat_id]:
                            await temp_Client[chat_id]["client"].disconnect()
                        del temp_Client[chat_id]
                if os.path.isfile(f"sessions/{chat_id}.session"):
                    os.remove(f"sessions/{chat_id}.session")

    elif user["step"] == "buyamount":
        if text.isdigit():
            count = text.strip()
            if int(count) >= 10000:
                await app.send_message(chat_id, f"فاکتور افزایش موجودی به مبلغ `{int(count):,}` تومان ایجاد شد\nروش پرداخت مورد نظر خود را انتخاب کنبد:", reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(text="کارت به کارت", callback_data=f"card_to_card-{count}"),
                            InlineKeyboardButton(text="پرداخت با ترون", callback_data=f"pay_with_trx-{count}")
                        ],
                        [
                            InlineKeyboardButton(text="برگشت", callback_data="Wallet")
                        ]
                    ]
                ))
            else:
                await app.send_message(chat_id, "حداقل موجودی قابل خرید 10,000 تومان است!")
        else:
            await app.send_message(chat_id, "ورودی نامعتبر! فقط ارسال عدد مجاز است")
        await update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")

    elif user["step"].split("-")[0] == "card_to_card":
        settings = await get_data("SELECT * FROM settings")
        if settings["ctcgate"] == "ON":
            if m.photo:
                tracking_code = int(user["step"].split("-")[1])
                count = int(user["step"].split("-")[2])
                mess = await app.forward_messages(from_chat_id=chat_id, chat_id=owner_id, message_ids=m_id)
                await app.send_message(owner_id, f"مدیر گرامی درخواست افزایش موجودی دارید\n\nنام کاربر: {html.escape(m.chat.first_name)}\nآیدی کاربر: `{m.chat.id}`\nیوزرنیم کاربر: {username}\nمبلغ درخواستی کاربر: {(count):,} تومان\nشماره پیگیری: `{tracking_code}`", reply_parameters=ReplyParameters(message_id=mess.id), reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(text="مشاهده PV کاربر", user_id=m.chat.id)
                        ],
                        [
                            InlineKeyboardButton("تایید", callback_data=f"AcceptAmount-{tracking_code}-{chat_id}-{count}"),
                            InlineKeyboardButton("رد کردن", callback_data=f"RejectAmount-{tracking_code}-{chat_id}")
                        ]
                    ]
                ))
                await app.send_message(chat_id, "رسید تراکنش شما ارسال شد. لطفا منتظر تایید توسط مدیر باشید", reply_parameters=ReplyParameters(message_id=m_id))
                await update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")
            else:
                await app.send_message(chat_id, "ورودی نامعتبر! فقط ارسال عکس مجاز است")
        else:
            await app.send_message(chat_id, "این بخش غیرفعال است!")
    
    elif user["step"] == "transferam1":
        if text.isdigit():
            user_id = int(text.strip())
            user_data = await get_data(f"SELECT * FROM user WHERE id = '{user_id}' LIMIT 1")
            if user_data is not None:
                if user_id != m.chat.id:
                    await app.send_message(chat_id, "میزان موجودی مورد نظر خود را برای انتقال وارد کنید:\nحداقل موجودی قابل ارسال 10,000 تومان است")
                    await update_data(f"UPDATE user SET step = 'transferam2-{user_id}' WHERE id = '{m.chat.id}' LIMIT 1")
                else:
                    await app.send_message(chat_id, "شما نمی توانید به خودتان موجودی انتقال دهید!")
            else:
                await app.send_message(chat_id, "چنین کاربری در ربات یافت نشد!")
        else:
            await app.send_message(chat_id, "ورودی نامعتبر! فقط ارسال عدد مجاز است")
    
    elif user["step"].split("-")[0] == "transferam2":
        if text.isdigit():
            user_id = int(user["step"].split("-")[1])
            count = text.strip()
            if int(amount) >= int(count):
                if int(count) >= 10000:
                    user_amount = await get_data(f"SELECT amount FROM user WHERE id = '{user_id}' LIMIT 1")
                    upamount = int(amount) - int(count)
                    user_upamount = int(user_amount["amount"]) + int(count)
                    await update_data(f"UPDATE user SET amount = '{upamount}' WHERE id = '{m.chat.id}' LIMIT 1")
                    await update_data(f"UPDATE user SET amount = '{user_upamount}' WHERE id = '{user_id}' LIMIT 1")
                    await app.send_message(chat_id, f"مبلغ {int(count):,} تومان از حساب شما کسر شد و به حساب کاربر [ `{user_id}` ] انتقال یافت\nموجودی جدید شما: {int(upamount):,} تومان", reply_markup=InlineKeyboardMarkup(
                        [
                            [
                                InlineKeyboardButton(text="برگشت", callback_data="Wallet")
                            ]
                        ]
                    ))
                    await app.send_message(user_id, f"مبلغ {int(count):,} تومان از حساب کاربر [ {m.chat.id} ] به حساب شما انتقال یافت\nموجودی جدید شما: {int(user_upamount):,} تومان")
                    await update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")
                else:
                    await app.send_message(chat_id, "حداقل موجودی قابل ارسال 10,000 تومان است!")
            else:
                await app.send_message(chat_id, "موجودی شما کافی نیست!")
        else:
            await app.send_message(chat_id, "ورودی نامعتبر! فقط ارسال عدد مجاز است")
    
    elif user["step"] == "giftcode":
        settings = await get_data("SELECT * FROM settings")
        if settings["giftcode"] == "ON":
            if m.text:
                code = text.strip()
                if len(code) == 10 and code.isupper():
                    gift_code = await get_data(f"SELECT * FROM codes WHERE code = '{code}' LIMIT 1")
                    if gift_code:
                        used_code = await get_data(f"SELECT * FROM used_codes WHERE id = '{m.chat.id}' AND code = '{code}' LIMIT 1")
                        if used_code is None:
                            capacity = gift_code["capacity"]
                            if capacity == "inf" or (capacity.isdigit() and int(capacity) > 0):
                                gift_value = gift_code["value"]
                                user_amount = await get_data(f"SELECT amount FROM user WHERE id = '{m.chat.id}' LIMIT 1")
                                upamount = int(user_amount["amount"]) + int(gift_value)
                                await update_data(f"UPDATE user SET amount = '{upamount}' WHERE id = '{m.chat.id}' LIMIT 1")
                                if capacity.isdigit() and int(capacity) > 0:
                                    capacity = int(capacity)
                                    capacity -= 1
                                    await update_data(f"UPDATE codes SET capacity = '{capacity}' WHERE code = '{code}' LIMIT 1")
                                await update_data(f"INSERT INTO used_codes(id, code) VALUES('{m.chat.id}', '{code}')")
                                await app.send_message(chat_id, f"کد هدیه تایید شد و مبلغ {int(gift_value):,} تومان به حساب شما افزوده شد\nموجودی جدید شما: {int(upamount):,} تومان")
                            else:
                                await app.send_message(chat_id, "ظرفیت استفاده از این کد هدیه به اتمام رسیده است!")
                        else:
                            await app.send_message(chat_id, "این کد هدیه قبلا استفاده شده است!")
                    else:
                        await app.send_message(chat_id, "کد هدیه نامعتبر است!")
                else:
                    await app.send_message(chat_id, "کد هدیه نامعتبر است!")
            else:
                await app.send_message(chat_id, "ورودی نامعتبر!")
        else:
            await app.send_message(chat_id, "این بخش غیرفعال است!")

    elif user["step"] == "accverify":
        if m.photo:
            mess = await app.forward_messages(from_chat_id=chat_id, chat_id=owner_id, message_ids=m_id)
            await app.send_message(owner_id, f"""
مدیر گرامی درخواست تایید حساب کاربری دارید

نام کاربر: {html.escape(m.chat.first_name)}
آیدی کاربر: `{m.chat.id}`
یوزرنیم کاربر: {username}
""", reply_parameters=ReplyParameters(message_id=mess.id), reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="مشاهده PV کاربر", user_id=m.chat.id)
                    ],
                    [
                        InlineKeyboardButton("تایید", callback_data=f"AcceptVerify-{chat_id}"),
                        InlineKeyboardButton("رد کردن", callback_data=f"RejectVerify-{chat_id}")
                    ]
                ]
            ))
            await app.send_message(chat_id, "درخواست شما برای تایید حساب کاربری ارسال شد. لطفا منتظر تایید توسط مدیر باشید", reply_parameters=ReplyParameters(message_id=m_id))
            await update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")
        else:
            await app.send_message(chat_id, "ورودی نامعتبر! فقط ارسال عکس مجاز است")

    elif user["step"] == "transferex1":
        if text.isdigit():
            user_id = int(text.strip())
            user_data = await get_data(f"SELECT * FROM user WHERE id = '{user_id}' LIMIT 1")
            if user_data is not None:
                if user_id != m.chat.id:
                    if os.path.isfile(f"sessions/{user_id}.session"):
                        await app.send_message(chat_id, "میزان انقضای مورد نظر خود را برای انتقال وارد کنید:\nحداقل باید 10 روز انقضا برای شما باقی بماند!")
                        await update_data(f"UPDATE user SET step = 'transferex2-{user_id}' WHERE id = '{m.chat.id}' LIMIT 1")
                    else:
                        await app.send_message(chat_id, "اشتراک سلف برای این کاربر فعال نیست!")
                else:
                    await app.send_message(chat_id, "شما نمی توانید به خودتان انقضا انتقال دهید!")
            else:
                await app.send_message(chat_id, "چنین کاربری در ربات یافت نشد!")
        else:
            await app.send_message(chat_id, "ورودی نامعتبر! فقط ارسال عدد مجاز است")
    
    elif user["step"].split("-")[0] == "transferex2":
        if text.isdigit():
            user_id = int(user["step"].split("-")[1])
            count = text.strip()
            if int(expir) >= int(count):
                if int(expir) - int(count) >= 10:
                    user_expir = await get_data(f"SELECT expir FROM user WHERE id = '{user_id}' LIMIT 1")
                    upexpir = int(expir) - int(count)
                    user_upexpir = int(user_expir["expir"]) + int(count)
                    await update_data(f"UPDATE user SET expir = '{upexpir}' WHERE id = '{m.chat.id}' LIMIT 1")
                    await update_data(f"UPDATE user SET expir = '{user_upexpir}' WHERE id = '{user_id}' LIMIT 1")
                    await app.send_message(chat_id, f"{count} روز از انقضای شما کسر شد و به کاربر [ `{user_id}` ] انتقال یافت\nانقضای جدید شما: {upexpir} روز", reply_markup=InlineKeyboardMarkup(
                        [
                            [
                                InlineKeyboardButton(text="برگشت", callback_data="Subinfo")
                            ]
                        ]
                    ))
                    await app.send_message(user_id, f"{count} روز از انقضای کاربر [ {m.chat.id} ] به شما انتقال یافت\nانقضای جدید شما: {user_upexpir} روز")
                    await update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")
                else:
                    await app.send_message(chat_id, "حداقل باید 10 روز انقضا برای شما باقی بماند!")
            else:
                await app.send_message(chat_id, "انقضای شما کافی نیست!")
        else:
            await app.send_message(chat_id, "ورودی نامعتبر! فقط ارسال عدد مجاز است")

    elif user["step"] == "support":
        mess = await app.forward_messages(from_chat_id=chat_id, chat_id=owner_id, message_ids=m_id)
        await app.send_message(owner_id, f"""
مدیر گرامی پیام ارسال شده جدید دارید

نام کاربر: {html.escape(m.chat.first_name)}
آیدی کاربر: `{m.chat.id}`
یوزرنیم کاربر: {username}
""", reply_parameters=ReplyParameters(message_id=mess.id), reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text="مشاهده PV کاربر", user_id=m.chat.id)
                ],
                [
                    InlineKeyboardButton("پاسخ", callback_data=f"Reply-{chat_id}"),
                    InlineKeyboardButton("بلاک", callback_data=f"Block-{chat_id}")
                ]
            ]
        ))
        await app.send_message(chat_id, "پیام شما ارسال شد و در اسرع وقت به آن پاسخ داده خواهد شد", reply_parameters=ReplyParameters(message_id=m_id))

    elif user["step"].split("-")[0] == "ureply":
        exit = user["step"].split("-")[1]
        mess = await app.copy_message(from_chat_id=owner_id, chat_id=exit, message_id=m_id)
        await app.send_message(exit, "کاربر گرامی پیام ارسال شده جدید از پشتیبانی دارید", reply_parameters=ReplyParameters(message_id=mess.id))
        await app.send_message(owner_id, "پیام شما ارسال شد پیام دیگری ارسال یا روی یکی از گزینه های زیر کلیک کنید:", reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text="مشاهده PV کاربر", user_id=exit)
                ],
                [
                    InlineKeyboardButton(text="صفحه اصلی", callback_data="Back"),
                    InlineKeyboardButton(text="پنل مدیریت", callback_data="Panel")
                ]
            ]
        ))

#============================================== Panel ===============================================#

Panel = ReplyKeyboardMarkup(
    [
        [
            ("آمار 📊")
        ],
        [
            ("تنظیمات ⚙️"),
            ("بخش عضویت اجباری ⭕️")
        ],
        [
            ("سفارشی سازی 🎨"),
            ("بخش کد هدیه 🎁")
        ],
        [
        
            ("ارسال همگانی ✉️"),
            ("فوروارد همگانی ✉️")
        ],
        [
            ("بلاک کاربر 🚫"),
            ("آنبلاک کاربر ✅️")
        ],
        [
            ("افزودن موجودی ➕"),
            ("کسر موجودی ➖")
        ],
        [
            ("افزودن زمان اشتراک ➕"),
            ("کسر زمان اشتراک ➖")
        ],
        [
            ("فعال کردن سلف 🔵"),
            ("غیرفعال کردن سلف 🔴")
        ],
        [
            ("فعال کردن همه سلف ها 🔵"),
            ("غیرفعال کردن همه سلف ها 🔴")
        ],
        [
            ("روشن کردن ربات 🔵"),
            ("خاموش کردن ربات 🔴")
        ],
        [
            ("صفحه اصلی 🏠")
        ]
    ],resize_keyboard=True
)

AdminBack = ReplyKeyboardMarkup(
    [
        [
            ("برگشت ↪️")
        ]
    ],resize_keyboard=True
)

@app.on_message(filters.private&filters.user(owner_id)&filters.command("panel"), group=1)
async def update(c, m):
    await app.send_message(owner_id, "مدیر گرامی به پنل مدیریت Ultra Self خوش آمدید!", reply_markup=Panel)
    await update_data(f"UPDATE user SET step = 'none' WHERE id = '{owner_id}' LIMIT 1")
    async with lock:
        if owner_id in temp_Client:
            del temp_Client[owner_id]

@app.on_callback_query(filters.user(owner_id), group=1)
async def call(c, call):
    data = call.data
    m_id = call.message.id
    if data == "Panel":
        await app.send_message(owner_id, "مدیر گرامی به پنل مدیریت Ultra Self خوش آمدید!", reply_markup=Panel)
        await update_data(f"UPDATE user SET step = 'none' WHERE id = '{owner_id}' LIMIT 1")
        async with lock:
            if owner_id in temp_Client:
                del temp_Client[owner_id]
    
    elif data.split("-")[0] == "DeleteSub":
        user_id = int(data.split("-")[1])
        await app.edit_message_text(owner_id, m_id, "**هشدار! با این کار اشتراک کاربر مورد نظر به طور کامل حذف می شود و امکان فعالسازی دوباره از پنل مدیریت وجود ندارد\n\nاگر از این کار اطمینان دارید روی گزینه تایید و در غیر این صورت روی گزینه برگشت کلیک کنید**", reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text="تایید", callback_data=f"AcceptDelSub-{user_id}")
                ],
                [
                    InlineKeyboardButton(text="برگشت", callback_data="AdminBack")
                ]
            ]
        ))
    
    elif data.split("-")[0] == "AcceptDelSub":
        await app.edit_message_text(owner_id, m_id, "اشتراک سلف کاربر مورد نظر به طور کامل حذف شد", reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text="برگشت", callback_data="AdminBack")
                ]
            ]
        ))
        user_id = int(data.split("-")[1])
        if os.path.isdir(f"selfs/self-{user_id}"):
            shutil.rmtree(f"selfs/self-{user_id}")
        if os.path.isfile(f"sessions/{user_id}.session"):
            async with Client(f"sessions/{user_id}") as user_client:
                await user_client.log_out()
            if os.path.isfile(f"sessions/{user_id}.session"):
                os.remove(f"sessions/{user_id}.session")
        if os.path.isfile(f"sessions/{user_id}.session-journal"):
            os.remove(f"sessions/{user_id}.session-journal")
        await update_data(f"UPDATE user SET expir = '0' WHERE id = '{user_id}' LIMIT 1")
        await update_data(f"UPDATE user SET self = 'inactive' WHERE id = '{user_id}' LIMIT 1")
        await app.send_message(user_id, "کاربر گرامی اشتراک سلف شما توسط مدیر حذف شد\nبرای کسب اطلاعات بیشتر و دلیل حذف اشتراک به پشتیبانی مراجعه کنید")
    
    elif data == "continue_activate_selfs":
        users = await get_datas("SELECT * FROM user WHERE self = 'active'")
        all_subs = await get_datas("SELECT COUNT(self) FROM user WHERE self = 'active'")
        _count_ = 1
        count = 0
        mess = await app.edit_message_text(owner_id, m_id, "این عملیات ممکن است چند لحظه طول بکشد...", reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text=f"{count}/{all_subs[0][0]}", callback_data="text")
                ]
            ]
        ))
        for user in users:
            if user[7] == "active":
                process = subprocess.Popen(["python3", f"{user[0]}.py", str(user[0]), str(api_id), api_hash, helper_username], cwd=f"selfs/self-{user[0]}", stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
                while True:
                    line = process.stdout.readline()
                    if line:
                        if "started" in line.strip():
                            count += 1
                            await setscheduler(user[0])
                            await app.edit_message_text(owner_id, mess.id, "این عملیات ممکن است چند لحظه طول بکشد...", reply_markup=InlineKeyboardMarkup(
                                [
                                    [
                                        InlineKeyboardButton(text=f"{count}/{all_subs[0][0]}", callback_data="text")
                                    ]
                                ]
                            ))
                            break
                        else:
                            break
                    await asyncio.sleep(0.1)
            await asyncio.sleep(0.5)
        else:
            await app.edit_message_text(owner_id, mess.id, f"{count} سلف از {all_subs[0][0]} سلف فعال شدند", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text=f"{count}/{all_subs[0][0]}", callback_data="text")
                    ]
                ]
            ))
    
    elif data == "continue_deactivate_selfs":
        users = await get_datas("SELECT * FROM user WHERE self = 'active'")
        all_subs = await get_datas("SELECT COUNT(self) FROM user WHERE self = 'active'")
        _count_ = 1
        count = 0
        mess = await app.edit_message_text(owner_id, m_id, "این عملیات ممکن است چند لحظه طول بکشد...", reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text=f"{count}/{all_subs[0][0]}", callback_data="text")
                ]
            ]
        ))
        for user in users:
            if user[7] == "active":
                subprocess.Popen(["pkill", "-f", f"{user[0]}.py"], cwd=f"selfs/self-{user[0]}")
                count += 1
                job = scheduler.get_job(str(user[0]))
                if job:
                    scheduler.remove_job(str(user[0]))
                await app.edit_message_text(owner_id, mess.id, "این عملیات ممکن است چند لحظه طول بکشد...", reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(text=f"{count}/{all_subs[0][0]}", callback_data="text")
                        ]
                    ]
                ))
            await asyncio.sleep(0.5)
        else:
            await app.edit_message_text(owner_id, mess.id, f"{count} سلف از {all_subs[0][0]} سلف غیرفعال شدند", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text=f"{count}/{all_subs[0][0]}", callback_data="text")
                    ]
                ]
            ))

    elif data == "users_list":
        mess = await app.send_message(owner_id, "لطفا صبر کنید...")
        time_stamp = get_time('timestamp')
        async with aiofiles.open(f"temp_files/U-{time_stamp}.txt", "w") as file:
            users = await get_datas("SELECT * FROM user")
            for user in users:
                await file.write(f"ID: {user[0]}\nPhone number: {user[2]}\nBalance amount: {user[3]}\nReferral: {user[4]}\nExpir: {user[5]}\nAccount status: {user[6]}\n_______________\n")
        try:
            await app.edit_message_media(owner_id, mess.id, media=InputMediaDocument(media=f"temp_files/U-{time_stamp}.txt"))
        except ValueError:
            await app.edit_message_text(owner_id, mess.id, "لیست کاربران خالی است!")
        if os.path.isfile(f"temp_files/U-{time_stamp}.txt"):
            os.remove(f"temp_files/U-{time_stamp}.txt")
        
    elif data == "block_list":
        mess = await app.send_message(owner_id, "لطفا صبر کنید...")
        time_stamp = get_time('timestamp')
        async with aiofiles.open(f"temp_files/B-{time_stamp}.txt", "w") as file:
            blocks = await get_datas("SELECT id FROM block")
            for user in blocks:
                await file.write(f"ID: {user[0]}\n_______________\n")
        try:
            await app.edit_message_media(owner_id, mess.id, media=InputMediaDocument(media=f"temp_files/B-{time_stamp}.txt"))
        except ValueError:
            await app.edit_message_text(owner_id, mess.id, "لیست بلاک خالی است!")
        if os.path.isfile(f"temp_files/B-{time_stamp}.txt"):
            os.remove(f"temp_files/B-{time_stamp}.txt")

    elif data == "transactions_list":
        mess = await app.send_message(owner_id, "لطفا صبر کنید...")
        time_stamp = get_time('timestamp')
        async with aiofiles.open(f"temp_files/T-{time_stamp}.txt", "w") as file:
            transactions = await get_datas("SELECT * FROM transactions")
            for transaction in transactions:
                await file.write(f"Tracking Code: {transaction[0]}\nUser ID: {transaction[1]}\nPayment Method: {transaction[2]}\nWallet Address: {transaction[3]}\nAmount: {transaction[4]}\nStatus: {transaction[5]}\nCreation Date: {time_convert(transaction[6], 'date')} - {time_convert(transaction[6], 'time')}\nConfirmation Date: {time_convert(transaction[7], 'date')} - {time_convert(transaction[7], 'time')}\n_______________\n")
        try:
            await app.edit_message_media(owner_id, mess.id, media=InputMediaDocument(media=f"temp_files/T-{time_stamp}.txt"))
        except ValueError:
            await app.edit_message_text(owner_id, mess.id, "لیست تراکنش ها خالی است!")
        if os.path.isfile(f"temp_files/T-{time_stamp}.txt"):
            os.remove(f"temp_files/T-{time_stamp}.txt")

    elif data == "add_channel":
        await app.edit_message_text(owner_id, m_id, "یوزرنیم یا آیدی کانال مورد نظر را ارسال کنید:", reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text="برگشت", callback_data="channel_panel")
                ]
            ]
        ))
        await update_data(f"UPDATE user SET step = 'add_channel' WHERE id = '{owner_id}' LIMIT 1")

    elif data == "del_channel":
        await app.edit_message_text(owner_id, m_id, "یوزرنیم یا آیدی کانال مورد نظر را ارسال کنید:", reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text="برگشت", callback_data="channel_panel")
                ]
            ]
        ))
        await update_data(f"UPDATE user SET step = 'del_channel' WHERE id = '{owner_id}' LIMIT 1")
    
    elif data == "channel_panel":
        channels = await get_datas("SELECT id FROM channels")
        s = str()
        if channels:
            for index, channel in enumerate(channels, start=1):
                s += f"{index}. `{channel[0]}`\n"
            channel_list = f"لیست کانال ها:\n{s}"
        else:
            channel_list = "لیست کانال ها خالی است!"
        await app.edit_message_text(owner_id, m_id, channel_list, reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text="افزودن کانال", callback_data="add_channel"),
                    InlineKeyboardButton(text="حذف کانال", callback_data="del_channel")
                ],
                [
                    InlineKeyboardButton(text="برگشت", callback_data="AdminBack")
                ]
            ]
        ))
        await update_data(f"UPDATE user SET step = 'none' WHERE id = '{owner_id}' LIMIT 1")

    elif data == "edit_start_text":
        dyconfig = await get_data("SELECT * FROM dynamic_config")
        await app.edit_message_text(owner_id, m_id, f"متن استارت فعلی:\n\n`{dyconfig['start_text']}`\n\nمتن استارت جدید را ارسال کنید:\n\nمتغیر ها:\n`FIRST_NAME` = نام کاربر\n`LAST_NAME` = نام خانوادگی کاربر\n`DATE` = تاریخ\n`TIME` = زمان", reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text="برگشت", callback_data="customize_panel")
                ]
            ]
        ))
        await update_data(f"UPDATE user SET step = 'edit_start_text' WHERE id = '{owner_id}' LIMIT 1")

    elif data == "edit_support_text":
        dyconfig = await get_data("SELECT * FROM dynamic_config")
        await app.edit_message_text(owner_id, m_id, f"متن پشتیبانی فعلی:\n\n`{dyconfig['support_text']}`\n\nمتن پشتیبانی جدید را ارسال کنید:\n\nمتغیر ها:\n`FIRST_NAME` = نام کاربر\n`LAST_NAME` = نام خانوادگی کاربر\n`DATE` = تاریخ\n`TIME` = زمان", reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text="برگشت", callback_data="customize_panel")
                ]
            ]
        ))
        await update_data(f"UPDATE user SET step = 'edit_support_text' WHERE id = '{owner_id}' LIMIT 1")

    elif data == "change_sub_prices":
        dyconfig = await get_data("SELECT * FROM dynamic_config")
        await app.edit_message_text(owner_id, m_id, f"""
لیست فعلی قیمت اشتراک:

» 1 ماهه: `{int(dyconfig['sub_1m_price']):,}` تومان

» 2 ماهه: `{int(dyconfig['sub_2m_price']):,}` تومان

» 3 ماهه: `{int(dyconfig['sub_3m_price']):,}` تومان

» 4 ماهه `{int(dyconfig['sub_4m_price']):,}` تومان

» 5 ماهه: `{int(dyconfig['sub_5m_price']):,}` تومان

» 6 ماهه: `{int(dyconfig['sub_6m_price']):,}` تومان

قیمت های جدید را به ترتیب ارسال کنید:

مثال:

`30000`
`60000`
`90000`
`120000`
`150000`
`180000`
""", reply_markup=InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton(text="برگشت", callback_data="customize_panel")
            ]
        ]
        ))
        await update_data(f"UPDATE user SET step = 'change_sub_prices' WHERE id = '{owner_id}' LIMIT 1")
        
    elif data == "change_referral_value":
        dyconfig = await get_data("SELECT * FROM dynamic_config")
        await app.edit_message_text(owner_id, m_id, f"مقدار پاداش رفرال گیری فعلی: `{int(dyconfig['referral_value']):,}`\nمقدار جدید را ارسال کنید:", reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text="برگشت", callback_data="customize_panel")
                ]
            ]
        ))
        await update_data(f"UPDATE user SET step = 'change_referral_value' WHERE id = '{owner_id}' LIMIT 1")
    
    elif data == "edit_whattb_section":
        dyconfig = await get_data("SELECT * FROM dynamic_config")
        await app.edit_message_text(owner_id, m_id, f"متن فعلی:\n\n`{dyconfig['whattb_text']}`\n\nمتن جدید را ارسال کنید:\n\nمتغیر ها:\n`FIRST_NAME` = نام کاربر\n`LAST_NAME` = نام خانوادگی کاربر\n`DATE` = تاریخ\n`TIME` = زمان", reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text="برگشت", callback_data="customize_panel")
                ]
            ]
        ))
        await update_data(f"UPDATE user SET step = 'edit_whattb_section' WHERE id = '{owner_id}' LIMIT 1")

    elif data == "edit_myaccount_section":
        dyconfig = await get_data("SELECT * FROM dynamic_config")
        await app.edit_message_text(owner_id, m_id, f"متن فعلی:\n\n`{dyconfig['myaccount_text']}`\n\nمتن جدید را ارسال کنید:\n\nمتغیر ها:\n`FIRST_NAME` = نام کاربر\n`LAST_NAME` = نام خانوادگی کاربر\n`DATE` = تاریخ\n`TIME` = زمان", reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text="برگشت", callback_data="customize_panel")
                ]
            ]
        ))
        await update_data(f"UPDATE user SET step = 'edit_myaccount_section' WHERE id = '{owner_id}' LIMIT 1")
    
    elif data == "customize_panel":
        await app.edit_message_text(owner_id, m_id, "لطفا یک گزینه را انتخاب کنید:", reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text="ویرایش متن استارت", callback_data="edit_start_text"),
                    InlineKeyboardButton(text="ویرایش متن پشتیبانی", callback_data="edit_support_text")
                ],
                [
                    InlineKeyboardButton(text="تغییر قیمت اشتراک", callback_data="change_sub_prices"),
                    InlineKeyboardButton(text="تغییر پاداش رفرال گیری", callback_data="change_referral_value")
                ],
                [
                    InlineKeyboardButton(text="ویرایش بخش 'سلف چیست؟'", callback_data="edit_whattb_section"),
                    InlineKeyboardButton(text="ویرایش بخش 'حساب من'", callback_data="edit_myaccount_section")
                ],
                [
                    InlineKeyboardButton(text="برگشت", callback_data="AdminBack")
                ]
            ]
        ))
        await update_data(f"UPDATE user SET step = 'none' WHERE id = '{owner_id}' LIMIT 1")
    
    elif data == "create_giftcode":
        settings = await get_data("SELECT * FROM settings")
        if settings["giftcode"] == "ON":
            await app.edit_message_text(owner_id, m_id, "لطفا ارزش کد هدیه را مشخص کنید:", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="10,000 تومان", callback_data="giftcode1-10000"),
                        InlineKeyboardButton(text="20,000 تومان", callback_data="giftcode1-20000"),
                        InlineKeyboardButton(text="30,000 تومان", callback_data="giftcode1-30000")
                    ],
                    [
                        InlineKeyboardButton(text="40,000 تومان", callback_data="giftcode1-40000"),
                        InlineKeyboardButton(text="50,000 تومان", callback_data="giftcode1-50000"),
                        InlineKeyboardButton(text="60,000 تومان", callback_data="giftcode1-60000")
                    ],
                    [
                        InlineKeyboardButton(text="70,000 تومان", callback_data="giftcode1-70000"),
                        InlineKeyboardButton(text="80,000 تومان", callback_data="giftcode1-80000"),
                        InlineKeyboardButton(text="90,000 تومان", callback_data="giftcode1-90000")
                    ],
                    [
                        InlineKeyboardButton(text="100,000 تومان", callback_data="giftcode1-100000"),
                        InlineKeyboardButton(text="200,000 تومان", callback_data="giftcode1-200000"),
                        InlineKeyboardButton(text="300,000 تومان", callback_data="giftcode1-300000")
                    ],
                    [
                        InlineKeyboardButton(text="400,000 تومان", callback_data="giftcode1-400000"),
                        InlineKeyboardButton(text="500,000 تومان", callback_data="giftcode1-500000"),
                        InlineKeyboardButton(text="600,000 تومان", callback_data="giftcode1-600000")
                    ],
                    [
                        InlineKeyboardButton(text="700,000 تومان", callback_data="giftcode1-700000"),
                        InlineKeyboardButton(text="800,000 تومان", callback_data="giftcode1-800000"),
                        InlineKeyboardButton(text="900,000 تومان", callback_data="giftcode1-900000")
                    ],
                    [
                        InlineKeyboardButton(text="1,000,000 تومان", callback_data="giftcode1-1000000")
                    ],
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="giftcode_panel")
                    ]
                ]
            ))
        else:
            await app.edit_message_text(owner_id, m_id, "این بخش غیرفعال است!", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="AdminPanel")
                    ]
                ]
            ))
    
    elif data.split("-")[0] == "giftcode1":
        settings = await get_data("SELECT * FROM settings")
        if settings["giftcode"] == "ON":
            giftcode_value = data.split("-")[1]
            await app.edit_message_text(owner_id, m_id, "ظرفیت کد هدیه را مشخص کنید:", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="1 نفر", callback_data=f"giftcode2-{giftcode_value}-1"),
                        InlineKeyboardButton(text="2 نفر", callback_data=f"giftcode2-{giftcode_value}-2"),
                        InlineKeyboardButton(text="3 نفر", callback_data=f"giftcode2-{giftcode_value}-3")
                    ],
                    [
                        InlineKeyboardButton(text="4 نفر", callback_data=f"giftcode2-{giftcode_value}-4"),
                        InlineKeyboardButton(text="5 نفر", callback_data=f"giftcode2-{giftcode_value}-5"),
                        InlineKeyboardButton(text="6 نفر", callback_data=f"giftcode2-{giftcode_value}-6")
                    ],
                    [
                        InlineKeyboardButton(text="7 نفر", callback_data=f"giftcode2-{giftcode_value}-7"),
                        InlineKeyboardButton(text="8 نفر", callback_data=f"giftcode2-{giftcode_value}-8"),
                        InlineKeyboardButton(text="9 نفر", callback_data=f"giftcode2-{giftcode_value}-9")
                    ],
                    [
                        InlineKeyboardButton(text="10 نفر", callback_data=f"giftcode2-{giftcode_value}-10"),
                        InlineKeyboardButton(text="20 نفر", callback_data=f"giftcode2-{giftcode_value}-20"),
                        InlineKeyboardButton(text="30 نفر", callback_data=f"giftcode2-{giftcode_value}-30")
                    ],
                    [
                        InlineKeyboardButton(text="40 نفر", callback_data=f"giftcode2-{giftcode_value}-40"),
                        InlineKeyboardButton(text="50 نفر", callback_data=f"giftcode2-{giftcode_value}-50"),
                        InlineKeyboardButton(text="60 نفر", callback_data=f"giftcode2-{giftcode_value}-60")
                    ],
                    [
                        InlineKeyboardButton(text="70 نفر", callback_data=f"giftcode2-{giftcode_value}-70"),
                        InlineKeyboardButton(text="80 نفر", callback_data=f"giftcode2-{giftcode_value}-80"),
                        InlineKeyboardButton(text="90 نفر", callback_data=f"giftcode2-{giftcode_value}-90")
                    ],
                    [
                        InlineKeyboardButton(text="100 نفر", callback_data=f"giftcode2-{giftcode_value}-100"),
                        InlineKeyboardButton(text="بدون محدودیت", callback_data=f"giftcode2-{giftcode_value}-inf")
                    ],
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="create_giftcode")
                    ]
                ]
            ))
        else:
            await app.edit_message_text(owner_id, m_id, "این بخش غیرفعال است!", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="AdminPanel")
                    ]
                ]
            ))
    
    elif data.split("-")[0] == "giftcode2":
        settings = await get_data("SELECT * FROM settings")
        if settings["giftcode"] == "ON":
            giftcode_value = data.split("-")[1]
            giftcode_capacity = data.split("-")[2]
            await app.edit_message_text(owner_id, m_id, "انقضای کد هدیه را مشخص کنید:", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="1 روز پس از تولید", callback_data=f"giftcode3-{giftcode_value}-{giftcode_capacity}-1"),
                        InlineKeyboardButton(text="2 روز پس از تولید", callback_data=f"giftcode3-{giftcode_value}-{giftcode_capacity}-2")
                    ],
                    [
                        InlineKeyboardButton(text="3 روز پس از تولید", callback_data=f"giftcode3-{giftcode_value}-{giftcode_capacity}-3"),
                        InlineKeyboardButton(text="4 روز پس از تولید", callback_data=f"giftcode3-{giftcode_value}-{giftcode_capacity}-4")
                    ],
                    [
                        InlineKeyboardButton(text="5 روز پس از تولید", callback_data=f"giftcode3-{giftcode_value}-{giftcode_capacity}-5"),
                        InlineKeyboardButton(text="6 روز پس از تولید", callback_data=f"giftcode3-{giftcode_value}-{giftcode_capacity}-6")
                    ],
                    [
                        InlineKeyboardButton(text="7 روز پس از تولید", callback_data=f"giftcode3-{giftcode_value}-{giftcode_capacity}-7"),
                        InlineKeyboardButton(text="8 روز پس از تولید", callback_data=f"giftcode3-{giftcode_value}-{giftcode_capacity}-8")
                    ],
                    [
                        InlineKeyboardButton(text="9 روز پس از تولید", callback_data=f"giftcode3-{giftcode_value}-{giftcode_capacity}-9"),
                        InlineKeyboardButton(text="10 روز پس از تولید", callback_data=f"giftcode3-{giftcode_value}-{giftcode_capacity}-10")
                    ],
                    [
                        InlineKeyboardButton(text="بدون محدودیت", callback_data=f"giftcode3-{giftcode_value}-{giftcode_capacity}-inf")
                    ],
                    [
                        InlineKeyboardButton(text="برگشت", callback_data=f"giftcode1-{giftcode_value}")
                    ]
                ]
            ))
        else:
            await app.edit_message_text(owner_id, m_id, "این بخش غیرفعال است!", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="AdminPanel")
                    ]
                ]
            ))
    
    elif data.split("-")[0] == "giftcode3":
        settings = await get_data("SELECT * FROM settings")
        if settings["giftcode"] == "ON":
            giftcode_value = int(data.split("-")[1])
            giftcode_capacity = int(data.split("-")[2]) if data.split("-")[2] != "inf" else "inf"
            giftcode_expir = int(data.split("-")[3]) if data.split("-")[3] != "inf" else "inf"
            giftcode = await generate_giftcode()
            await app.edit_message_text(owner_id, m_id, f"کد هدیه ایجاد شد. اطلاعات کد به شرح زیر است:", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="کد هدیه", callback_data="text"),
                        InlineKeyboardButton(text=f"{giftcode}", copy_text=f"{giftcode}")
                    ],
                    [
                        InlineKeyboardButton(text="ارزش کد هدیه", callback_data="text"),
                        InlineKeyboardButton(text=f"{(giftcode_value):,} تومان", callback_data="text")
                    ],
                    [
                        InlineKeyboardButton(text="ظرفیت کد هدیه", callback_data="text"),
                        InlineKeyboardButton(text=f"{f'{giftcode_capacity} نفر' if giftcode_capacity != 'inf' else 'بدون محدودیت'}", callback_data="text")
                    ],
                    [
                        InlineKeyboardButton(text="انقضای کد هدیه", callback_data="text"),
                        InlineKeyboardButton(text=f"{f'{giftcode_expir} روز پس از تولید' if giftcode_expir != 'inf' else 'بدون محدودیت'}", callback_data="text")
                    ],
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="giftcode_panel")
                    ]
                ]
            ))
            await update_data(f"INSERT INTO codes(code, capacity, expir, value) VALUES('{giftcode}', '{giftcode_capacity}', '{giftcode_expir}', '{giftcode_value}')")
            if giftcode_expir != "inf":
                scheduler.add_job(giftcode_timer, "interval", hours=24, args=[giftcode], id=f"giftcode-{giftcode}")
        else:
            await app.edit_message_text(owner_id, m_id, "این بخش غیرفعال است!", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="AdminPanel")
                    ]
                ]
            ))

    elif data == "del_giftcode":
        settings = await get_data("SELECT * FROM settings")
        if settings["giftcode"] == "ON":
            await app.edit_message_text(owner_id, m_id, "کد هدیه را ارسال کنید:", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="giftcode_panel")
                    ]
                ]
            ))
            await update_data(f"UPDATE user SET step = 'del_giftcode' WHERE id = '{owner_id}' LIMIT 1")
        else:
            await app.edit_message_text(owner_id, m_id, "این بخش غیرفعال است!", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="AdminPanel")
                    ]
                ]
            ))

    elif data == "giftcode_info":
        settings = await get_data("SELECT * FROM settings")
        if settings["giftcode"] == "ON":
            await app.edit_message_text(owner_id, m_id, "کد هدیه را ارسال کنید:", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="giftcode_panel")
                    ]
                ]
            ))
            await update_data(f"UPDATE user SET step = 'giftcode_info' WHERE id = '{owner_id}' LIMIT 1")
        else:
            await app.edit_message_text(owner_id, m_id, "این بخش غیرفعال است!", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="AdminPanel")
                    ]
                ]
            ))
    
    elif data == "giftcode_panel":
        settings = await get_data("SELECT * FROM settings")
        if settings["giftcode"] == "ON":
            codes = await get_datas("SELECT * FROM codes")
            s = str()
            if codes:
                for index, code in enumerate(codes, start=1):
                    s += f"{index}. `{code[0]}`\n"
                channel_list = f"لیست کد های هدیه:\n{s}"
            else:
                channel_list = "کد هدیه ای وجود ندارد!"
            await app.edit_message_text(owner_id, m_id, channel_list, reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="ایجاد کد هدیه", callback_data="create_giftcode"),
                        InlineKeyboardButton(text="حذف کد هدیه", callback_data="del_giftcode")
                    ],
                    [
                        InlineKeyboardButton(text="اطلاعات کد هدیه", callback_data="giftcode_info")
                    ],
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="AdminBack")
                    ]
                ]
            ))
        else:
            await app.edit_message_text(owner_id, m_id, "این بخش غیرفعال است!", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="AdminPanel")
                    ]
                ]
            ))
        await update_data(f"UPDATE user SET step = 'none' WHERE id = '{owner_id}' LIMIT 1")

    elif data == "anti_spam_button":
        bot = await get_data("SELECT * FROM bot")
        settings = await get_data("SELECT * FROM settings")
        status = "OFF" if settings["anti_spam"] == "ON" else "ON"
        await update_data(f"UPDATE settings SET anti_spam = '{status}' LIMIT 1")
        settings = await get_data("SELECT * FROM settings")
        anti_spam_status = "فعال" if settings["anti_spam"] == "ON" else "غیرفعال"
        anti_spam_symbol = "🟢" if settings["anti_spam"] == "ON" else "🔴"
        test_sub_status = "فعال" if settings["test_sub"] == "ON" else "غیرفعال"
        test_sub_symbol = "🟢" if settings["test_sub"] == "ON" else "🔴"
        referral_status = "فعال" if settings["referral"] == "ON" else "غیرفعال"
        referral_symbol = "🟢" if settings["referral"] == "ON" else "🔴"
        reports_status = "فعال" if settings["reports"] == "ON" else "غیرفعال"
        reports_symbol = "🟢" if settings["reports"] == "ON" else "🔴"
        giftcode_status = "فعال" if settings["giftcode"] == "ON" else "غیرفعال"
        giftcode_symbol = "🟢" if settings["giftcode"] == "ON" else "🔴"
        ctcgate_status = "فعال" if settings["ctcgate"] == "ON" else "غیرفعال"
        ctcgate_symbol = "🟢" if settings["ctcgate"] == "ON" else "🔴"
        trxgate_status = "فعال" if settings["trxgate"] == "ON" else "غیرفعال"
        trxgate_symbol = "🟢" if settings["trxgate"] == "ON" else "🔴"
        bot_status = "روشن" if bot["status"] == "ON" else "خاموش"
        bot_symbol = "🟢" if bot["status"] == "ON" else "🔴"
        try:
            await app.edit_message_text(owner_id, m_id, f"سیستم ضد اسپم {anti_spam_status} شد\nتست رایگان {test_sub_status} است\nرفرال گیری {referral_status} است\nارسال گزارشات {reports_status} است\nکد هدیه {giftcode_status} است\nدرگاه کارت به کارت {ctcgate_status} است\nدرگاه ترونی {trxgate_status} است\nربات {bot_status} است\nبرای تغییر وضعیت هرکدام کلیک کنید:", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="سیستم ضد اسپم", callback_data="text"),
                        InlineKeyboardButton(text=anti_spam_symbol, callback_data="anti_spam_button")
                    ],
                    [
                        InlineKeyboardButton(text="تست رایگان", callback_data="text"),
                        InlineKeyboardButton(text=test_sub_symbol, callback_data="test_sub_button")
                    ],
                    [
                        InlineKeyboardButton(text="رفرال گیری", callback_data="text"),
                        InlineKeyboardButton(text=referral_symbol, callback_data="referral_button")
                    ],
                    [
                        InlineKeyboardButton(text="ارسال گزارشات", callback_data="text"),
                        InlineKeyboardButton(text=reports_symbol, callback_data="reports_button")
                    ],
                    [
                        InlineKeyboardButton(text="کد هدیه", callback_data="text"),
                        InlineKeyboardButton(text=giftcode_symbol, callback_data="giftcode_button")
                    ],
                    [
                        InlineKeyboardButton(text="درگاه کارت به کارت", callback_data="text"),
                        InlineKeyboardButton(text=ctcgate_symbol, callback_data="ctcgate_button")
                    ],
                    [
                        InlineKeyboardButton(text="درگاه ترونی", callback_data="text"),
                        InlineKeyboardButton(text=trxgate_symbol, callback_data="trxgate_button")
                    ],
                    [
                        InlineKeyboardButton(text="وضعیت ربات", callback_data="text"),
                        InlineKeyboardButton(text=bot_symbol, callback_data="bot_button")
                    ],
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="AdminBack")
                    ]
                ]
            ))
        except errors.MessageNotModified:
            pass
        except Exception:
            pass
    
    elif data == "test_sub_button":
        bot = await get_data("SELECT * FROM bot")
        settings = await get_data("SELECT * FROM settings")
        status = "OFF" if settings["test_sub"] == "ON" else "ON"
        await update_data(f"UPDATE settings SET test_sub = '{status}' LIMIT 1")
        settings = await get_data("SELECT * FROM settings")
        anti_spam_status = "فعال" if settings["anti_spam"] == "ON" else "غیرفعال"
        anti_spam_symbol = "🟢" if settings["anti_spam"] == "ON" else "🔴"
        test_sub_status = "فعال" if settings["test_sub"] == "ON" else "غیرفعال"
        test_sub_symbol = "🟢" if settings["test_sub"] == "ON" else "🔴"
        referral_status = "فعال" if settings["referral"] == "ON" else "غیرفعال"
        referral_symbol = "🟢" if settings["referral"] == "ON" else "🔴"
        reports_status = "فعال" if settings["reports"] == "ON" else "غیرفعال"
        reports_symbol = "🟢" if settings["reports"] == "ON" else "🔴"
        giftcode_status = "فعال" if settings["giftcode"] == "ON" else "غیرفعال"
        giftcode_symbol = "🟢" if settings["giftcode"] == "ON" else "🔴"
        ctcgate_status = "فعال" if settings["ctcgate"] == "ON" else "غیرفعال"
        ctcgate_symbol = "🟢" if settings["ctcgate"] == "ON" else "🔴"
        trxgate_status = "فعال" if settings["trxgate"] == "ON" else "غیرفعال"
        trxgate_symbol = "🟢" if settings["trxgate"] == "ON" else "🔴"
        bot_status = "روشن" if bot["status"] == "ON" else "خاموش"
        bot_symbol = "🟢" if bot["status"] == "ON" else "🔴"
        try:
            await app.edit_message_text(owner_id, m_id, f"سیستم ضد اسپم {anti_spam_status} است\nتست رایگان {test_sub_status} شد\nرفرال گیری {referral_status} است\nارسال گزارشات {reports_status} است\nکد هدیه {giftcode_status} است\nدرگاه کارت به کارت {ctcgate_status} است\nدرگاه ترونی {trxgate_status} است\nربات {bot_status} است\nبرای تغییر وضعیت هرکدام کلیک کنید:", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="سیستم ضد اسپم", callback_data="text"),
                        InlineKeyboardButton(text=anti_spam_symbol, callback_data="anti_spam_button")
                    ],
                    [
                        InlineKeyboardButton(text="تست رایگان", callback_data="text"),
                        InlineKeyboardButton(text=test_sub_symbol, callback_data="test_sub_button")
                    ],
                    [
                        InlineKeyboardButton(text="رفرال گیری", callback_data="text"),
                        InlineKeyboardButton(text=referral_symbol, callback_data="referral_button")
                    ],
                    [
                        InlineKeyboardButton(text="ارسال گزارشات", callback_data="text"),
                        InlineKeyboardButton(text=reports_symbol, callback_data="reports_button")
                    ],
                    [
                        InlineKeyboardButton(text="کد هدیه", callback_data="text"),
                        InlineKeyboardButton(text=giftcode_symbol, callback_data="giftcode_button")
                    ],
                    [
                        InlineKeyboardButton(text="درگاه کارت به کارت", callback_data="text"),
                        InlineKeyboardButton(text=ctcgate_symbol, callback_data="ctcgate_button")
                    ],
                    [
                        InlineKeyboardButton(text="درگاه ترونی", callback_data="text"),
                        InlineKeyboardButton(text=trxgate_symbol, callback_data="trxgate_button")
                    ],
                    [
                        InlineKeyboardButton(text="وضعیت ربات", callback_data="text"),
                        InlineKeyboardButton(text=bot_symbol, callback_data="bot_button")
                    ],
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="AdminBack")
                    ]
                ]
            ))
        except errors.MessageNotModified:
            pass
        except Exception:
            pass

    elif data == "referral_button":
        bot = await get_data("SELECT * FROM bot")
        settings = await get_data("SELECT * FROM settings")
        status = "OFF" if settings["referral"] == "ON" else "ON"
        await update_data(f"UPDATE settings SET referral = '{status}' LIMIT 1")
        settings = await get_data("SELECT * FROM settings")
        anti_spam_status = "فعال" if settings["anti_spam"] == "ON" else "غیرفعال"
        anti_spam_symbol = "🟢" if settings["anti_spam"] == "ON" else "🔴"
        test_sub_status = "فعال" if settings["test_sub"] == "ON" else "غیرفعال"
        test_sub_symbol = "🟢" if settings["test_sub"] == "ON" else "🔴"
        referral_status = "فعال" if settings["referral"] == "ON" else "غیرفعال"
        referral_symbol = "🟢" if settings["referral"] == "ON" else "🔴"
        reports_status = "فعال" if settings["reports"] == "ON" else "غیرفعال"
        reports_symbol = "🟢" if settings["reports"] == "ON" else "🔴"
        giftcode_status = "فعال" if settings["giftcode"] == "ON" else "غیرفعال"
        giftcode_symbol = "🟢" if settings["giftcode"] == "ON" else "🔴"
        ctcgate_status = "فعال" if settings["ctcgate"] == "ON" else "غیرفعال"
        ctcgate_symbol = "🟢" if settings["ctcgate"] == "ON" else "🔴"
        trxgate_status = "فعال" if settings["trxgate"] == "ON" else "غیرفعال"
        trxgate_symbol = "🟢" if settings["trxgate"] == "ON" else "🔴"
        bot_status = "روشن" if bot["status"] == "ON" else "خاموش"
        bot_symbol = "🟢" if bot["status"] == "ON" else "🔴"
        try:
            await app.edit_message_text(owner_id, m_id, f"سیستم ضد اسپم {anti_spam_status} است\nتست رایگان {test_sub_status} است\nرفرال گیری {referral_status} شد\nارسال گزارشات {reports_status} است\nکد هدیه {giftcode_status} است\nدرگاه کارت به کارت {ctcgate_status} است\nدرگاه ترونی {trxgate_status} است\nربات {bot_status} است\nبرای تغییر وضعیت هرکدام کلیک کنید:", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="سیستم ضد اسپم", callback_data="text"),
                        InlineKeyboardButton(text=anti_spam_symbol, callback_data="anti_spam_button")
                    ],
                    [
                        InlineKeyboardButton(text="تست رایگان", callback_data="text"),
                        InlineKeyboardButton(text=test_sub_symbol, callback_data="test_sub_button")
                    ],
                    [
                        InlineKeyboardButton(text="رفرال گیری", callback_data="text"),
                        InlineKeyboardButton(text=referral_symbol, callback_data="referral_button")
                    ],
                    [
                        InlineKeyboardButton(text="ارسال گزارشات", callback_data="text"),
                        InlineKeyboardButton(text=reports_symbol, callback_data="reports_button")
                    ],
                    [
                        InlineKeyboardButton(text="کد هدیه", callback_data="text"),
                        InlineKeyboardButton(text=giftcode_symbol, callback_data="giftcode_button")
                    ],
                    [
                        InlineKeyboardButton(text="درگاه کارت به کارت", callback_data="text"),
                        InlineKeyboardButton(text=ctcgate_symbol, callback_data="ctcgate_button")
                    ],
                    [
                        InlineKeyboardButton(text="درگاه ترونی", callback_data="text"),
                        InlineKeyboardButton(text=trxgate_symbol, callback_data="trxgate_button")
                    ],
                    [
                        InlineKeyboardButton(text="وضعیت ربات", callback_data="text"),
                        InlineKeyboardButton(text=bot_symbol, callback_data="bot_button")
                    ],
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="AdminBack")
                    ]
                ]
            ))
        except errors.MessageNotModified:
            pass
        except Exception:
            pass

    elif data == "reports_button":
        bot = await get_data("SELECT * FROM bot")
        settings = await get_data("SELECT * FROM settings")
        status = "OFF" if settings["reports"] == "ON" else "ON"
        await update_data(f"UPDATE settings SET reports = '{status}' LIMIT 1")
        settings = await get_data("SELECT * FROM settings")
        anti_spam_status = "فعال" if settings["anti_spam"] == "ON" else "غیرفعال"
        anti_spam_symbol = "🟢" if settings["anti_spam"] == "ON" else "🔴"
        test_sub_status = "فعال" if settings["test_sub"] == "ON" else "غیرفعال"
        test_sub_symbol = "🟢" if settings["test_sub"] == "ON" else "🔴"
        referral_status = "فعال" if settings["referral"] == "ON" else "غیرفعال"
        referral_symbol = "🟢" if settings["referral"] == "ON" else "🔴"
        reports_status = "فعال" if settings["reports"] == "ON" else "غیرفعال"
        reports_symbol = "🟢" if settings["reports"] == "ON" else "🔴"
        giftcode_status = "فعال" if settings["giftcode"] == "ON" else "غیرفعال"
        giftcode_symbol = "🟢" if settings["giftcode"] == "ON" else "🔴"
        ctcgate_status = "فعال" if settings["ctcgate"] == "ON" else "غیرفعال"
        ctcgate_symbol = "🟢" if settings["ctcgate"] == "ON" else "🔴"
        trxgate_status = "فعال" if settings["trxgate"] == "ON" else "غیرفعال"
        trxgate_symbol = "🟢" if settings["trxgate"] == "ON" else "🔴"
        bot_status = "روشن" if bot["status"] == "ON" else "خاموش"
        bot_symbol = "🟢" if bot["status"] == "ON" else "🔴"
        try:
            await app.edit_message_text(owner_id, m_id, f"سیستم ضد اسپم {anti_spam_status} است\nتست رایگان {test_sub_status} است\nرفرال گیری {referral_status} است\nارسال گزارشات {reports_status} شد\nکد هدیه {giftcode_status} است\nدرگاه کارت به کارت {ctcgate_status} است\nدرگاه ترونی {trxgate_status} است\nربات {bot_status} است\nبرای تغییر وضعیت هرکدام کلیک کنید:", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="سیستم ضد اسپم", callback_data="text"),
                        InlineKeyboardButton(text=anti_spam_symbol, callback_data="anti_spam_button")
                    ],
                    [
                        InlineKeyboardButton(text="تست رایگان", callback_data="text"),
                        InlineKeyboardButton(text=test_sub_symbol, callback_data="test_sub_button")
                    ],
                    [
                        InlineKeyboardButton(text="رفرال گیری", callback_data="text"),
                        InlineKeyboardButton(text=referral_symbol, callback_data="referral_button")
                    ],
                    [
                        InlineKeyboardButton(text="ارسال گزارشات", callback_data="text"),
                        InlineKeyboardButton(text=reports_symbol, callback_data="reports_button")
                    ],
                    [
                        InlineKeyboardButton(text="کد هدیه", callback_data="text"),
                        InlineKeyboardButton(text=giftcode_symbol, callback_data="giftcode_button")
                    ],
                    [
                        InlineKeyboardButton(text="درگاه کارت به کارت", callback_data="text"),
                        InlineKeyboardButton(text=ctcgate_symbol, callback_data="ctcgate_button")
                    ],
                    [
                        InlineKeyboardButton(text="درگاه ترونی", callback_data="text"),
                        InlineKeyboardButton(text=trxgate_symbol, callback_data="trxgate_button")
                    ],
                    [
                        InlineKeyboardButton(text="وضعیت ربات", callback_data="text"),
                        InlineKeyboardButton(text=bot_symbol, callback_data="bot_button")
                    ],
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="AdminBack")
                    ]
                ]
            ))
        except errors.MessageNotModified:
            pass
        except Exception:
            pass
    
    elif data == "giftcode_button":
        bot = await get_data("SELECT * FROM bot")
        settings = await get_data("SELECT * FROM settings")
        status = "OFF" if settings["giftcode"] == "ON" else "ON"
        await update_data(f"UPDATE settings SET giftcode = '{status}' LIMIT 1")
        settings = await get_data("SELECT * FROM settings")
        anti_spam_status = "فعال" if settings["anti_spam"] == "ON" else "غیرفعال"
        anti_spam_symbol = "🟢" if settings["anti_spam"] == "ON" else "🔴"
        test_sub_status = "فعال" if settings["test_sub"] == "ON" else "غیرفعال"
        test_sub_symbol = "🟢" if settings["test_sub"] == "ON" else "🔴"
        referral_status = "فعال" if settings["referral"] == "ON" else "غیرفعال"
        referral_symbol = "🟢" if settings["referral"] == "ON" else "🔴"
        reports_status = "فعال" if settings["reports"] == "ON" else "غیرفعال"
        reports_symbol = "🟢" if settings["reports"] == "ON" else "🔴"
        giftcode_status = "فعال" if settings["giftcode"] == "ON" else "غیرفعال"
        giftcode_symbol = "🟢" if settings["giftcode"] == "ON" else "🔴"
        ctcgate_status = "فعال" if settings["ctcgate"] == "ON" else "غیرفعال"
        ctcgate_symbol = "🟢" if settings["ctcgate"] == "ON" else "🔴"
        trxgate_status = "فعال" if settings["trxgate"] == "ON" else "غیرفعال"
        trxgate_symbol = "🟢" if settings["trxgate"] == "ON" else "🔴"
        bot_status = "روشن" if bot["status"] == "ON" else "خاموش"
        bot_symbol = "🟢" if bot["status"] == "ON" else "🔴"
        try:
            await app.edit_message_text(owner_id, m_id, f"سیستم ضد اسپم {anti_spam_status} است\nتست رایگان {test_sub_status} است\nرفرال گیری {referral_status} است\nارسال گزارشات {reports_status} است\nکد هدیه {giftcode_status} شد\nدرگاه کارت به کارت {ctcgate_status} است\nدرگاه ترونی {trxgate_status} است\nربات {bot_status} است\nبرای تغییر وضعیت هرکدام کلیک کنید:", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="سیستم ضد اسپم", callback_data="text"),
                        InlineKeyboardButton(text=anti_spam_symbol, callback_data="anti_spam_button")
                    ],
                    [
                        InlineKeyboardButton(text="تست رایگان", callback_data="text"),
                        InlineKeyboardButton(text=test_sub_symbol, callback_data="test_sub_button")
                    ],
                    [
                        InlineKeyboardButton(text="رفرال گیری", callback_data="text"),
                        InlineKeyboardButton(text=referral_symbol, callback_data="referral_button")
                    ],
                    [
                        InlineKeyboardButton(text="ارسال گزارشات", callback_data="text"),
                        InlineKeyboardButton(text=reports_symbol, callback_data="reports_button")
                    ],
                    [
                        InlineKeyboardButton(text="کد هدیه", callback_data="text"),
                        InlineKeyboardButton(text=giftcode_symbol, callback_data="giftcode_button")
                    ],
                    [
                        InlineKeyboardButton(text="درگاه کارت به کارت", callback_data="text"),
                        InlineKeyboardButton(text=ctcgate_symbol, callback_data="ctcgate_button")
                    ],
                    [
                        InlineKeyboardButton(text="درگاه ترونی", callback_data="text"),
                        InlineKeyboardButton(text=trxgate_symbol, callback_data="trxgate_button")
                    ],
                    [
                        InlineKeyboardButton(text="وضعیت ربات", callback_data="text"),
                        InlineKeyboardButton(text=bot_symbol, callback_data="bot_button")
                    ],
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="AdminBack")
                    ]
                ]
            ))
        except errors.MessageNotModified:
            pass
        except Exception:
            pass
    
    elif data == "ctcgate_button":
        bot = await get_data("SELECT * FROM bot")
        settings = await get_data("SELECT * FROM settings")
        status = "OFF" if settings["ctcgate"] == "ON" else "ON"
        await update_data(f"UPDATE settings SET ctcgate = '{status}' LIMIT 1")
        settings = await get_data("SELECT * FROM settings")
        anti_spam_status = "فعال" if settings["anti_spam"] == "ON" else "غیرفعال"
        anti_spam_symbol = "🟢" if settings["anti_spam"] == "ON" else "🔴"
        test_sub_status = "فعال" if settings["test_sub"] == "ON" else "غیرفعال"
        test_sub_symbol = "🟢" if settings["test_sub"] == "ON" else "🔴"
        referral_status = "فعال" if settings["referral"] == "ON" else "غیرفعال"
        referral_symbol = "🟢" if settings["referral"] == "ON" else "🔴"
        reports_status = "فعال" if settings["reports"] == "ON" else "غیرفعال"
        reports_symbol = "🟢" if settings["reports"] == "ON" else "🔴"
        giftcode_status = "فعال" if settings["giftcode"] == "ON" else "غیرفعال"
        giftcode_symbol = "🟢" if settings["giftcode"] == "ON" else "🔴"
        ctcgate_status = "فعال" if settings["ctcgate"] == "ON" else "غیرفعال"
        ctcgate_symbol = "🟢" if settings["ctcgate"] == "ON" else "🔴"
        trxgate_status = "فعال" if settings["trxgate"] == "ON" else "غیرفعال"
        trxgate_symbol = "🟢" if settings["trxgate"] == "ON" else "🔴"
        bot_status = "روشن" if bot["status"] == "ON" else "خاموش"
        bot_symbol = "🟢" if bot["status"] == "ON" else "🔴"
        try:
            await app.edit_message_text(owner_id, m_id, f"سیستم ضد اسپم {anti_spam_status} است\nتست رایگان {test_sub_status} است\nرفرال گیری {referral_status} است\nارسال گزارشات {reports_status} است\nکد هدیه {giftcode_status} است\nدرگاه کارت به کارت {ctcgate_status} شد\nدرگاه ترونی {trxgate_status} است\nربات {bot_status} است\nبرای تغییر وضعیت هرکدام کلیک کنید:", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="سیستم ضد اسپم", callback_data="text"),
                        InlineKeyboardButton(text=anti_spam_symbol, callback_data="anti_spam_button")
                    ],
                    [
                        InlineKeyboardButton(text="تست رایگان", callback_data="text"),
                        InlineKeyboardButton(text=test_sub_symbol, callback_data="test_sub_button")
                    ],
                    [
                        InlineKeyboardButton(text="رفرال گیری", callback_data="text"),
                        InlineKeyboardButton(text=referral_symbol, callback_data="referral_button")
                    ],
                    [
                        InlineKeyboardButton(text="ارسال گزارشات", callback_data="text"),
                        InlineKeyboardButton(text=reports_symbol, callback_data="reports_button")
                    ],
                    [
                        InlineKeyboardButton(text="کد هدیه", callback_data="text"),
                        InlineKeyboardButton(text=giftcode_symbol, callback_data="giftcode_button")
                    ],
                    [
                        InlineKeyboardButton(text="درگاه کارت به کارت", callback_data="text"),
                        InlineKeyboardButton(text=ctcgate_symbol, callback_data="ctcgate_button")
                    ],
                    [
                        InlineKeyboardButton(text="درگاه ترونی", callback_data="text"),
                        InlineKeyboardButton(text=trxgate_symbol, callback_data="trxgate_button")
                    ],
                    [
                        InlineKeyboardButton(text="وضعیت ربات", callback_data="text"),
                        InlineKeyboardButton(text=bot_symbol, callback_data="bot_button")
                    ],
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="AdminBack")
                    ]
                ]
            ))
        except errors.MessageNotModified:
            pass
        except Exception:
            pass
    
    elif data == "trxgate_button":
        bot = await get_data("SELECT * FROM bot")
        settings = await get_data("SELECT * FROM settings")
        status = "OFF" if settings["trxgate"] == "ON" else "ON"
        await update_data(f"UPDATE settings SET trxgate = '{status}' LIMIT 1")
        settings = await get_data("SELECT * FROM settings")
        anti_spam_status = "فعال" if settings["anti_spam"] == "ON" else "غیرفعال"
        anti_spam_symbol = "🟢" if settings["anti_spam"] == "ON" else "🔴"
        test_sub_status = "فعال" if settings["test_sub"] == "ON" else "غیرفعال"
        test_sub_symbol = "🟢" if settings["test_sub"] == "ON" else "🔴"
        referral_status = "فعال" if settings["referral"] == "ON" else "غیرفعال"
        referral_symbol = "🟢" if settings["referral"] == "ON" else "🔴"
        reports_status = "فعال" if settings["reports"] == "ON" else "غیرفعال"
        reports_symbol = "🟢" if settings["reports"] == "ON" else "🔴"
        giftcode_status = "فعال" if settings["giftcode"] == "ON" else "غیرفعال"
        giftcode_symbol = "🟢" if settings["giftcode"] == "ON" else "🔴"
        ctcgate_status = "فعال" if settings["ctcgate"] == "ON" else "غیرفعال"
        ctcgate_symbol = "🟢" if settings["ctcgate"] == "ON" else "🔴"
        trxgate_status = "فعال" if settings["trxgate"] == "ON" else "غیرفعال"
        trxgate_symbol = "🟢" if settings["trxgate"] == "ON" else "🔴"
        bot_status = "روشن" if bot["status"] == "ON" else "خاموش"
        bot_symbol = "🟢" if bot["status"] == "ON" else "🔴"
        try:
            await app.edit_message_text(owner_id, m_id, f"سیستم ضد اسپم {anti_spam_status} است\nتست رایگان {test_sub_status} است\nرفرال گیری {referral_status} است\nارسال گزارشات {reports_status} است\nکد هدیه {giftcode_status} است\nدرگاه کارت به کارت {ctcgate_status} است\nدرگاه ترونی {trxgate_status} شد\nربات {bot_status} است\nبرای تغییر وضعیت هرکدام کلیک کنید:", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="سیستم ضد اسپم", callback_data="text"),
                        InlineKeyboardButton(text=anti_spam_symbol, callback_data="anti_spam_button")
                    ],
                    [
                        InlineKeyboardButton(text="تست رایگان", callback_data="text"),
                        InlineKeyboardButton(text=test_sub_symbol, callback_data="test_sub_button")
                    ],
                    [
                        InlineKeyboardButton(text="رفرال گیری", callback_data="text"),
                        InlineKeyboardButton(text=referral_symbol, callback_data="referral_button")
                    ],
                    [
                        InlineKeyboardButton(text="ارسال گزارشات", callback_data="text"),
                        InlineKeyboardButton(text=reports_symbol, callback_data="reports_button")
                    ],
                    [
                        InlineKeyboardButton(text="کد هدیه", callback_data="text"),
                        InlineKeyboardButton(text=giftcode_symbol, callback_data="giftcode_button")
                    ],
                    [
                        InlineKeyboardButton(text="درگاه کارت به کارت", callback_data="text"),
                        InlineKeyboardButton(text=ctcgate_symbol, callback_data="ctcgate_button")
                    ],
                    [
                        InlineKeyboardButton(text="درگاه ترونی", callback_data="text"),
                        InlineKeyboardButton(text=trxgate_symbol, callback_data="trxgate_button")
                    ],
                    [
                        InlineKeyboardButton(text="وضعیت ربات", callback_data="text"),
                        InlineKeyboardButton(text=bot_symbol, callback_data="bot_button")
                    ],
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="AdminBack")
                    ]
                ]
            ))
        except errors.MessageNotModified:
            pass
        except Exception:
            pass
    
    elif data == "bot_button":
        bot = await get_data("SELECT * FROM bot")
        settings = await get_data("SELECT * FROM settings")
        status = "OFF" if bot["status"] == "ON" else "ON"
        await update_data(f"UPDATE bot SET status = '{status}' LIMIT 1")
        bot = await get_data("SELECT * FROM bot")
        anti_spam_status = "فعال" if settings["anti_spam"] == "ON" else "غیرفعال"
        anti_spam_symbol = "🟢" if settings["anti_spam"] == "ON" else "🔴"
        test_sub_status = "فعال" if settings["test_sub"] == "ON" else "غیرفعال"
        test_sub_symbol = "🟢" if settings["test_sub"] == "ON" else "🔴"
        referral_status = "فعال" if settings["referral"] == "ON" else "غیرفعال"
        referral_symbol = "🟢" if settings["referral"] == "ON" else "🔴"
        reports_status = "فعال" if settings["reports"] == "ON" else "غیرفعال"
        reports_symbol = "🟢" if settings["reports"] == "ON" else "🔴"
        giftcode_status = "فعال" if settings["giftcode"] == "ON" else "غیرفعال"
        giftcode_symbol = "🟢" if settings["giftcode"] == "ON" else "🔴"
        ctcgate_status = "فعال" if settings["ctcgate"] == "ON" else "غیرفعال"
        ctcgate_symbol = "🟢" if settings["ctcgate"] == "ON" else "🔴"
        trxgate_status = "فعال" if settings["trxgate"] == "ON" else "غیرفعال"
        trxgate_symbol = "🟢" if settings["trxgate"] == "ON" else "🔴"
        bot_status = "روشن" if bot["status"] == "ON" else "خاموش"
        bot_symbol = "🟢" if bot["status"] == "ON" else "🔴"
        try:
            await app.edit_message_text(owner_id, m_id, f"سیستم ضد اسپم {anti_spam_status} است\nتست رایگان {test_sub_status} است\nرفرال گیری {referral_status} است\nارسال گزارشات {reports_status} است\nکد هدیه {giftcode_status} است\nدرگاه کارت به کارت {ctcgate_status} است\nدرگاه ترونی {trxgate_status} است\nربات {bot_status} شد\nبرای تغییر وضعیت هرکدام کلیک کنید:", reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="سیستم ضد اسپم", callback_data="text"),
                        InlineKeyboardButton(text=anti_spam_symbol, callback_data="anti_spam_button")
                    ],
                    [
                        InlineKeyboardButton(text="تست رایگان", callback_data="text"),
                        InlineKeyboardButton(text=test_sub_symbol, callback_data="test_sub_button")
                    ],
                    [
                        InlineKeyboardButton(text="رفرال گیری", callback_data="text"),
                        InlineKeyboardButton(text=referral_symbol, callback_data="referral_button")
                    ],
                    [
                        InlineKeyboardButton(text="ارسال گزارشات", callback_data="text"),
                        InlineKeyboardButton(text=reports_symbol, callback_data="reports_button")
                    ],
                    [
                        InlineKeyboardButton(text="کد هدیه", callback_data="text"),
                        InlineKeyboardButton(text=giftcode_symbol, callback_data="giftcode_button")
                    ],
                    [
                        InlineKeyboardButton(text="درگاه کارت به کارت", callback_data="text"),
                        InlineKeyboardButton(text=ctcgate_symbol, callback_data="ctcgate_button")
                    ],
                    [
                        InlineKeyboardButton(text="درگاه ترونی", callback_data="text"),
                        InlineKeyboardButton(text=trxgate_symbol, callback_data="trxgate_button")
                    ],
                    [
                        InlineKeyboardButton(text="وضعیت ربات", callback_data="text"),
                        InlineKeyboardButton(text=bot_symbol, callback_data="bot_button")
                    ],
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="AdminBack")
                    ]
                ]
            ))
        except errors.MessageNotModified:
            pass
        except Exception:
            pass
    
    elif data == "AdminBack":
        await app.delete_messages(owner_id, m_id)
        await app.send_message(owner_id, "مدیر گرامی به پنل مدیریت Ultra Self خوش آمدید!", reply_markup=Panel)
        await update_data(f"UPDATE user SET step = 'none' WHERE id = '{owner_id}' LIMIT 1")
        async with lock:
            if owner_id in temp_Client:
                del temp_Client[owner_id]

@app.on_message(filters.private&filters.user(owner_id), group=1)
async def update(c, m):
    bot = await get_data("SELECT * FROM bot")
    user = await get_data(f"SELECT * FROM user WHERE id = '{owner_id}' LIMIT 1")
    text = m.text
    m_id = m.id

    if text == "برگشت ↪️":
        await app.send_message(owner_id, "مدیر گرامی به پنل مدیریت Ultra Self خوش آمدید!", reply_markup=Panel)
        await update_data(f"UPDATE user SET step = 'none' WHERE id = '{owner_id}' LIMIT 1")
        async with lock:
            if owner_id in temp_Client:
                del temp_Client[owner_id]

    elif text == "آمار 📊":
        mess = await app.send_message(owner_id, "در حال دریافت اطلاعات...")
        botinfo = await app.get_me()
        allusers = await get_datas("SELECT COUNT(id) FROM user")
        users_now = await get_datas(f"SELECT COUNT(id) FROM user WHERE last_update > {get_time('timestamp')} - 60")
        users_clock = await get_datas(f"SELECT COUNT(id) FROM user WHERE last_update > {get_time('timestamp')} - 3600")
        users_6clock = await get_datas(f"SELECT COUNT(id) FROM user WHERE last_update > {get_time('timestamp')} - 21600")
        users_12clock = await get_datas(f"SELECT COUNT(id) FROM user WHERE last_update > {get_time('timestamp')} - 43200")
        users_day = await get_datas(f"SELECT COUNT(id) FROM user WHERE last_update > {get_time('timestamp')} - 86400")
        users_week = await get_datas(f"SELECT COUNT(id) FROM user WHERE last_update > {get_time('timestamp')} - 604800")
        users_month = await get_datas(f"SELECT COUNT(id) FROM user WHERE last_update > {get_time('timestamp')} - 2592000")
        users_6month = await get_datas(f"SELECT COUNT(id) FROM user WHERE last_update > {get_time('timestamp')} - 15552000")
        allblocks = await get_datas("SELECT COUNT(id) FROM block")
        statistics_image = await asyncio.to_thread(generate_stats_chart, [users_now[0][0], users_clock[0][0], users_6clock[0][0], users_12clock[0][0], users_day[0][0], users_week[0][0], users_month[0][0], users_6month[0][0]], botinfo, get_time("date"), get_time("time"))
        await app.edit_message_media(owner_id, mess.id, media=InputMediaPhoto(media=statistics_image, caption=f"آمار ربات در تاریخ {get_time('date')} و در ساعت {get_time('time')} به شرح زیر می باشد:"), reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text="کاربران آنلاین", callback_data="text"),
                    InlineKeyboardButton(text=f"{users_now[0][0]} نفر", callback_data="text")
                ],
                [
                    InlineKeyboardButton(text="کاربران ساعت گذشته", callback_data="text"),
                    InlineKeyboardButton(text=f"{users_clock[0][0]} نفر", callback_data="text")
                ],
                [
                    InlineKeyboardButton(text="کاربران 6 ساعت گذشته", callback_data="text"),
                    InlineKeyboardButton(text=f"{users_6clock[0][0]} نفر", callback_data="text")
                ],
                [
                    InlineKeyboardButton(text="کاربران 12 ساعت گذشته", callback_data="text"),
                    InlineKeyboardButton(text=f"{users_12clock[0][0]} نفر", callback_data="text")
                ],
                [
                    InlineKeyboardButton(text="کاربران 24 ساعت گذشته", callback_data="text"),
                    InlineKeyboardButton(text=f"{users_day[0][0]} نفر", callback_data="text")
                ],
                [
                    InlineKeyboardButton(text="کاربران هفته گذشته", callback_data="text"),
                    InlineKeyboardButton(text=f"{users_week[0][0]} نفر", callback_data="text")
                ],
                [
                    InlineKeyboardButton(text="کاربران ماه گذشته", callback_data="text"),
                    InlineKeyboardButton(text=f"{users_month[0][0]} نفر", callback_data="text")
                ],
                [
                    InlineKeyboardButton(text="کاربران 6 ماه گذشته", callback_data="text"),
                    InlineKeyboardButton(text=f"{users_6month[0][0]} نفر", callback_data="text")
                ],
                [
                    InlineKeyboardButton(text="همه کاربران", callback_data="text"),
                    InlineKeyboardButton(text=f"{allusers[0][0]} نفر", callback_data="text")
                ],
                [
                    InlineKeyboardButton(text="کاربران بلاک شده", callback_data="text"),
                    InlineKeyboardButton(text=f"{allblocks[0][0]} نفر", callback_data="text")
                ],
                [
                    InlineKeyboardButton(text="----------------", callback_data="text")
                ],
                [
                    InlineKeyboardButton(text="نام ربات", callback_data="text"),
                    InlineKeyboardButton(text=f"{botinfo.first_name}", callback_data="text")
                ],
                [
                    InlineKeyboardButton(text="آیدی ربات", callback_data="text"),
                    InlineKeyboardButton(text=f"{botinfo.id}", copy_text=f"{botinfo.id}")
                ],
                [
                    InlineKeyboardButton(text="یوزرنیم ربات", callback_data="text"),
                    InlineKeyboardButton(text=f"@{botinfo.username}", callback_data="text")
                ],
                [
                    InlineKeyboardButton(text="----------------", callback_data="text")
                ],
                [
                    InlineKeyboardButton(text="لیست کاربران", callback_data="users_list"),
                    InlineKeyboardButton(text="لیست کاربران بلاک شده", callback_data="block_list")
                ],
                [
                    InlineKeyboardButton(text="لیست تراکنش ها", callback_data="transactions_list")
                ],
                [
                    InlineKeyboardButton(text="برگشت", callback_data="AdminBack")
                ]
            ]
        ))
        statistics_image.close()
        await update_data(f"UPDATE user SET step = 'none' WHERE id = '{owner_id}' LIMIT 1")
    
    elif text == "تنظیمات ⚙️":
        bot = await get_data("SELECT * FROM bot")
        settings = await get_data("SELECT * FROM settings")
        anti_spam_status = "فعال" if settings["anti_spam"] == "ON" else "غیرفعال"
        anti_spam_symbol = "🟢" if settings["anti_spam"] == "ON" else "🔴"
        test_sub_status = "فعال" if settings["test_sub"] == "ON" else "غیرفعال"
        test_sub_symbol = "🟢" if settings["test_sub"] == "ON" else "🔴"
        referral_status = "فعال" if settings["referral"] == "ON" else "غیرفعال"
        referral_symbol = "🟢" if settings["referral"] == "ON" else "🔴"
        reports_status = "فعال" if settings["reports"] == "ON" else "غیرفعال"
        reports_symbol = "🟢" if settings["reports"] == "ON" else "🔴"
        giftcode_status = "فعال" if settings["giftcode"] == "ON" else "غیرفعال"
        giftcode_symbol = "🟢" if settings["giftcode"] == "ON" else "🔴"
        ctcgate_status = "فعال" if settings["ctcgate"] == "ON" else "غیرفعال"
        ctcgate_symbol = "🟢" if settings["ctcgate"] == "ON" else "🔴"
        trxgate_status = "فعال" if settings["trxgate"] == "ON" else "غیرفعال"
        trxgate_symbol = "🟢" if settings["trxgate"] == "ON" else "🔴"
        bot_status = "روشن" if bot["status"] == "ON" else "خاموش"
        bot_symbol = "🟢" if bot["status"] == "ON" else "🔴"
        await app.send_message(owner_id, f"سیستم ضد اسپم {anti_spam_status} است\nتست رایگان {test_sub_status} است\nرفرال گیری {referral_status} است\nارسال گزارشات {reports_status} است\nکد هدیه {giftcode_status} است\nدرگاه کارت به کارت {ctcgate_status} است\nدرگاه ترونی {trxgate_status} است\nربات {bot_status} است\nبرای تغییر وضعیت هرکدام کلیک کنید:", reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text="سیستم ضد اسپم", callback_data="text"),
                    InlineKeyboardButton(text=anti_spam_symbol, callback_data="anti_spam_button")
                ],
                [
                    InlineKeyboardButton(text="تست رایگان", callback_data="text"),
                    InlineKeyboardButton(text=test_sub_symbol, callback_data="test_sub_button")
                ],
                [
                    InlineKeyboardButton(text="رفرال گیری", callback_data="text"),
                    InlineKeyboardButton(text=referral_symbol, callback_data="referral_button")
                ],
                [
                    InlineKeyboardButton(text="ارسال گزارشات", callback_data="text"),
                    InlineKeyboardButton(text=reports_symbol, callback_data="reports_button")
                ],
                [
                    InlineKeyboardButton(text="کد هدیه", callback_data="text"),
                    InlineKeyboardButton(text=giftcode_symbol, callback_data="giftcode_button")
                ],
                [
                    InlineKeyboardButton(text="درگاه کارت به کارت", callback_data="text"),
                    InlineKeyboardButton(text=ctcgate_symbol, callback_data="ctcgate_button")
                ],
                [
                    InlineKeyboardButton(text="درگاه ترونی", callback_data="text"),
                    InlineKeyboardButton(text=trxgate_symbol, callback_data="trxgate_button")
                ],
                [
                    InlineKeyboardButton(text="وضعیت ربات", callback_data="text"),
                    InlineKeyboardButton(text=bot_symbol, callback_data="bot_button")
                ],
                [
                    InlineKeyboardButton(text="برگشت", callback_data="AdminBack")
                ]
            ]
        ))
        await update_data(f"UPDATE user SET step = 'none' WHERE id = '{owner_id}' LIMIT 1")
    
    elif text == "بخش عضویت اجباری ⭕️":
        channels = await get_datas("SELECT id FROM channels")
        s = str()
        if channels:
            for index, channel in enumerate(channels, start=1):
                s += f"{index}. `{channel[0]}`\n"
            channel_list = f"لیست کانال ها:\n{s}"
        else:
            channel_list = "لیست کانال ها خالی است!"
        await app.send_message(owner_id, channel_list, reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text="افزودن کانال", callback_data="add_channel"),
                    InlineKeyboardButton(text="حذف کانال", callback_data="del_channel")
                ],
                [
                    InlineKeyboardButton(text="برگشت", callback_data="AdminBack")
                ]
            ]
        ))
        await update_data(f"UPDATE user SET step = 'none' WHERE id = '{owner_id}' LIMIT 1")

    elif text == "سفارشی سازی 🎨":
        await app.send_message(owner_id, "لطفا یک گزینه را انتخاب کنید:", reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text="ویرایش متن استارت", callback_data="edit_start_text"),
                    InlineKeyboardButton(text="ویرایش متن پشتیبانی", callback_data="edit_support_text")
                ],
                [
                    InlineKeyboardButton(text="تغییر قیمت اشتراک", callback_data="change_sub_prices"),
                    InlineKeyboardButton(text="تغییر پاداش رفرال گیری", callback_data="change_referral_value")
                ],
                [
                    InlineKeyboardButton(text="ویرایش بخش 'سلف چیست؟'", callback_data="edit_whattb_section"),
                    InlineKeyboardButton(text="ویرایش بخش 'حساب من'", callback_data="edit_myaccount_section")
                ],
                [
                    InlineKeyboardButton(text="برگشت", callback_data="AdminBack")
                ]
            ]
        ))
        await update_data(f"UPDATE user SET step = 'none' WHERE id = '{owner_id}' LIMIT 1")

    elif text == "بخش کد هدیه 🎁":
        settings = await get_data("SELECT * FROM settings")
        if settings["giftcode"] == "ON":
            codes = await get_datas("SELECT * FROM codes")
            s = str()
            if codes:
                for index, code in enumerate(codes, start=1):
                    s += f"{index}. `{code[0]}`\n"
                channel_list = f"لیست کد های هدیه:\n{s}"
            else:
                channel_list = "کد هدیه ای وجود ندارد!"
            await app.send_message(owner_id, channel_list, reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(text="ایجاد کد هدیه", callback_data="create_giftcode"),
                        InlineKeyboardButton(text="حذف کد هدیه", callback_data="del_giftcode")
                    ],
                    [
                        InlineKeyboardButton(text="اطلاعات کد هدیه", callback_data="giftcode_info")
                    ],
                    [
                        InlineKeyboardButton(text="برگشت", callback_data="AdminBack")
                    ]
                ]
            ))
        else:
            await app.send_message(owner_id, "این بخش غیرفعال است!")
        await update_data(f"UPDATE user SET step = 'none' WHERE id = '{owner_id}' LIMIT 1")

    elif text == "ارسال همگانی ✉️":
        await app.send_message(owner_id, "پیام خود را ارسال کنید:", reply_markup=AdminBack)
        await update_data(f"UPDATE user SET step = 'sendall' WHERE id = '{owner_id}' LIMIT 1")
    
    elif user["step"] == "sendall":
        mess = await app.send_message(owner_id, "در حال ارسال به همه کاربران...")
        users = await get_datas("SELECT id FROM user")
        try:
            for user in users:
                await app.copy_message(from_chat_id=owner_id, chat_id=user[0], message_id=m_id)
                await asyncio.sleep(0.1)
        except Exception:
            pass
        await app.edit_message_text(owner_id, mess.id, "پیام شما برای همه کاربران ارسال شد")
    
    elif text == "فوروارد همگانی ✉️":
        await app.send_message(owner_id, "پیام خود را ارسال کنید:", reply_markup=AdminBack)
        await update_data(f"UPDATE user SET step = 'forall' WHERE id = '{owner_id}' LIMIT 1")
    
    elif user["step"] == "forall":
        mess = await app.send_message(owner_id, "در حال فوروارد به همه کاربران...")
        users = await get_datas("SELECT id FROM user")
        try:
            for user in users:
                await app.forward_messages(from_chat_id=owner_id, chat_id=user[0], message_ids=m_id)
                await asyncio.sleep(0.1)
        except Exception:
            pass
        await app.edit_message_text(owner_id, mess.id, "پیام شما برای همه کاربران فوروارد شد")
    
    elif text == "بلاک کاربر 🚫":
        await app.send_message(owner_id, "آیدی عددی کاربری را که می خواهید بلاک کنید ارسال کنید:", reply_markup=AdminBack)
        await update_data(f"UPDATE user SET step = 'userblock' WHERE id = '{owner_id}' LIMIT 1")

    elif user["step"] == "userblock":
        if text.isdigit():
            user_id = int(text.strip())
            user_data = await get_data(f"SELECT * FROM user WHERE id = '{user_id}' LIMIT 1")
            if user_data is not None:
                block = await get_data(f"SELECT * FROM block WHERE id = '{user_id}' LIMIT 1")
                if block is None:
                    await app.send_message(user_id, "کاربر محترم شما به دلیل نقض قوانین از ربات مسدود شدید")
                    await app.send_message(owner_id, f"کاربر [ `{user_id}` ] از ربات بلاک شد")
                    await update_data(f"INSERT INTO block(id) VALUES('{user_id}')")
                else:
                    await app.send_message(owner_id, "این کاربر از قبل بلاک است")
            else:
                await app.send_message(owner_id, "چنین کاربری در ربات یافت نشد!")
        else:
            await app.send_message(owner_id, "ورودی نامعتبر! فقط ارسال عدد مجاز است")

    elif text == "آنبلاک کاربر ✅️":
        await app.send_message(owner_id, "آیدی عددی کاربری را که می خواهید آنبلاک کنید ارسال کنید:", reply_markup=AdminBack)
        await update_data(f"UPDATE user SET step = 'userunblock' WHERE id = '{owner_id}' LIMIT 1")
    
    elif user["step"] == "userunblock":
        if text.isdigit():
            user_id = int(text.strip())
            user_data = await get_data(f"SELECT * FROM user WHERE id = '{user_id}' LIMIT 1")
            if user_data is not None:
                block = await get_data(f"SELECT * FROM block WHERE id = '{user_id}' LIMIT 1")
                if block is not None:
                    await app.send_message(user_id, "کاربر عزیز شما آنبلاک شدید و اکنون می توانید از ربات استفاده کنید")
                    await app.send_message(owner_id, f"کاربر [ `{user_id}` ] از ربات آنبلاک شد")
                    await update_data(f"DELETE FROM block WHERE id = '{user_id}' LIMIT 1")
                else:
                    await app.send_message(owner_id, "این کاربر از ربات بلاک نیست!")
            else:
                await app.send_message(owner_id, "چنین کاربری در ربات یافت نشد!")
        else:
            await app.send_message(owner_id, "ورودی نامعتبر! فقط ارسال عدد مجاز است")
    
    elif text == "افزودن موجودی ➕":
        await app.send_message(owner_id, "آیدی عددی کاربری که می خواهید موجودی او را افزایش دهید وارد کنید:", reply_markup=AdminBack)
        await update_data(f"UPDATE user SET step = 'amountinc' WHERE id = '{owner_id}' LIMIT 1")
    
    elif user["step"] == "amountinc":
        if text.isdigit():
            user_id = int(text.strip())
            user_data = await get_data(f"SELECT * FROM user WHERE id = '{user_id}' LIMIT 1")
            if user_data is not None:
                await app.send_message(owner_id, "میزان موجودی مورد نظر خود را برای افزایش وارد کنید:")
                await update_data(f"UPDATE user SET step = 'amountinc2-{user_id}' WHERE id = '{owner_id}' LIMIT 1")
            else:
                await app.send_message(owner_id, "چنین کاربری در ربات یافت نشد!")
        else:
            await app.send_message(owner_id, "ورودی نامعتبر! فقط ارسال عدد مجاز است")

    elif user["step"].split("-")[0] == "amountinc2":
        if text.isdigit():
            user_id = int(user["step"].split("-")[1])
            count = int(text.strip())
            user_amount = await get_data(f"SELECT amount FROM user WHERE id = '{user_id}' LIMIT 1")
            user_upamount = int(user_amount["amount"]) + int(count)
            await update_data(f"UPDATE user SET amount = '{user_upamount}' WHERE id = '{user_id}' LIMIT 1")
            await app.send_message(user_id, f"مبلغ {int(count):,} تومان به حساب شما انتقال یافت\nموجودی جدید شما: {int(user_upamount):,} تومان")
            await app.send_message(owner_id, f"مبلغ {int(count):,} تومان به حساب کاربر [ `{user_id}` ] افزوده شد\nموجودی جدید کاربر: {int(user_upamount):,} تومان")
        else:
            await app.send_message(owner_id, "ورودی نامعتبر! فقط ارسال عدد مجاز است")
    
    elif text == "کسر موجودی ➖":
        await app.send_message(owner_id, "آیدی عددی کاربری که می خواهید موجودی او را کاهش دهید ارسال کنید:", reply_markup=AdminBack)
        await update_data(f"UPDATE user SET step = 'amountdec' WHERE id = '{owner_id}' LIMIT 1")
    
    elif user["step"] == "amountdec":
        if text.isdigit():
            user_id = int(text.strip())
            user_data = await get_data(f"SELECT * FROM user WHERE id = '{user_id}' LIMIT 1")
            if user_data is not None:
                await app.send_message(owner_id, "میزان موجودی مورد نظر خود را برای کاهش وارد کنید:")
                await update_data(f"UPDATE user SET step = 'amountdec2-{user_id}' WHERE id = '{owner_id}' LIMIT 1")
            else:
                await app.send_message(owner_id, "چنین کاربری در ربات یافت نشد!")
        else:
            await app.send_message(owner_id, "ورودی نامعتبر! فقط ارسال عدد مجاز است")

    elif user["step"].split("-")[0] == "amountdec2":
        if text.isdigit():
            user_id = int(user["step"].split("-")[1])
            count = int(text.strip())
            user_amount = await get_data(f"SELECT amount FROM user WHERE id = '{user_id}' LIMIT 1")
            user_upamount = int(user_amount["amount"]) - int(count)
            await update_data(f"UPDATE user SET amount = '{user_upamount}' WHERE id = '{user_id}' LIMIT 1")
            await app.send_message(user_id, f"مبلغ {int(count):,} تومان از حساب شما کسر شد\nموجودی جدید شما: {int(user_upamount):,} تومان")
            await app.send_message(owner_id, f"مبلغ {int(count):,} تومان از حساب کاربر [ `{user_id}` ] کسر شد\nموجودی جدید کاربر: {int(user_upamount):,} تومان")
        else:
            await app.send_message(owner_id, "ورودی نامعتبر! فقط ارسال عدد مجاز است")
    
    elif text == "افزودن زمان اشتراک ➕":
        await app.send_message(owner_id, "آیدی عددی کاربری که می خواهید زمان اشتراک او را افزایش دهید ارسال کنید:", reply_markup=AdminBack)
        await update_data(f"UPDATE user SET step = 'expirinc' WHERE id = '{owner_id}' LIMIT 1")

    elif user["step"] == "expirinc":
        if text.isdigit():
            user_id = int(text.strip())
            user_data = await get_data(f"SELECT * FROM user WHERE id = '{user_id}' LIMIT 1")
            if user_data is not None:
                if os.path.isfile(f"sessions/{user_id}.session"):
                    await app.send_message(owner_id, "میزان انقضای مورد نظر خود را برای افزایش وارد کنید:")
                    await update_data(f"UPDATE user SET step = 'expirinc2-{user_id}' WHERE id = '{owner_id}' LIMIT 1")
                else:
                    await app.send_message(owner_id, "اشتراک سلف برای این کاربر فعال نیست!")
            else:
                await app.send_message(owner_id, "چنین کاربری در ربات یافت نشد!")
        else:
            await app.send_message(owner_id, "ورودی نامعتبر! فقط ارسال عدد مجاز است")

    elif user["step"].split("-")[0] == "expirinc2":
        if text.isdigit():
            user_id = int(user["step"].split("-")[1])
            count = int(text.strip())
            user_expir = await get_data(f"SELECT expir FROM user WHERE id = '{user_id}' LIMIT 1")
            user_upexpir = int(user_expir["expir"]) + int(count)
            await update_data(f"UPDATE user SET expir = '{user_upexpir}' WHERE id = '{user_id}' LIMIT 1")
            await app.send_message(user_id, f"{count} روز به انقضای شما افزوده شد\nانقضای جدید شما: {user_upexpir} روز")
            await app.send_message(owner_id, f"{count} روز به انقضای کاربر [ `{user_id}` ] افزوده شد\nانقضای جدید کاربر: {user_upexpir} روز")
        else:
            await app.send_message(owner_id, "ورودی نامعتبر! فقط ارسال عدد مجاز است")
    
    elif text == "کسر زمان اشتراک ➖":
        await app.send_message(owner_id, "آیدی عددی کاربری که می خواهید موجودی او را کاهش دهید ارسال کنید:", reply_markup=AdminBack)
        await update_data(f"UPDATE user SET step = 'expirdec' WHERE id = '{owner_id}' LIMIT 1")
    
    elif user["step"] == "expirdec":
        if text.isdigit():
            user_id = int(text.strip())
            user_data = await get_data(f"SELECT * FROM user WHERE id = '{user_id}' LIMIT 1")
            if user_data is not None:
                if os.path.isfile(f"sessions/{user_id}.session"):
                    await app.send_message(owner_id, "میزان انقضای مورد نظر خود را برای کاهش وارد کنید:")
                    await update_data(f"UPDATE user SET step = 'expirdec2-{user_id}' WHERE id = '{owner_id}' LIMIT 1")
                else:
                    await app.send_message(owner_id, "اشتراک سلف برای این کاربر فعال نیست!")
            else:
                await app.send_message(owner_id, "چنین کاربری در ربات یافت نشد!")
        else:
            await app.send_message(owner_id, "ورودی نامعتبر! فقط ارسال عدد مجاز است")

    elif user["step"].split("-")[0] == "expirdec2":
        if text.isdigit():
            user_id = int(user["step"].split("-")[1])
            count = int(text.strip())
            user_expir = await get_data(f"SELECT expir FROM user WHERE id = '{user_id}' LIMIT 1")
            user_upexpir = int(user_expir["expir"]) - int(count)
            await update_data(f"UPDATE user SET expir = '{user_upexpir}' WHERE id = '{user_id}' LIMIT 1")
            await app.send_message(user_id, f"{count} روز از انقضای شما کسر شد\nانقضای جدید شما: {user_upexpir} روز")
            await app.send_message(owner_id, f"{count} روز از انقضای کاربر [ `{user_id}` ] کسر شد\nانقضای جدید کاربر: {user_upexpir} روز")
        else:
            await app.send_message(owner_id, "ورودی نامعتبر! فقط ارسال عدد مجاز است")
    
    elif text == "فعال کردن سلف 🔵":
        await app.send_message(owner_id, "آیدی عددی کاربری که می خواهید سلف او را فعال کنید ارسال کنید:", reply_markup=AdminBack)
        await update_data(f"UPDATE user SET step = 'selfactive' WHERE id = '{owner_id}' LIMIT 1")
    
    elif user["step"] == "selfactive":
        if text.isdigit():
            user_id = int(text.strip())
            user_data = await get_data(f"SELECT * FROM user WHERE id = '{user_id}' LIMIT 1")
            if user_data is not None:
                if os.path.isfile(f"sessions/{user_id}.session"):
                    if user_data["self"] != "active":
                        mess = await app.send_message(owner_id, "در حال فعالسازی سلف...\n(ممکن است چند لحظه طول بکشد)")
                        process = subprocess.Popen(["python3", f"{user_id}.py", str(user_id), str(api_id), api_hash, helper_username], cwd=f"selfs/self-{user_id}", stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
                        while True:
                            line = process.stdout.readline()
                            if line:
                                if "started" in line.strip():
                                    await app.edit_message_text(owner_id, mess.id, "سلف با موفقیت برای این کاربر فعال شد")
                                    await update_data(f"UPDATE user SET self = 'active' WHERE id = '{user_id}' LIMIT 1")
                                    await add_admin(user_id)
                                    await setscheduler(user_id)
                                    await app.send_message(user_id, "سلف شما توسط مدیر فعال شد")
                                    break
                                else:
                                    await app.edit_message_text(owner_id, mess.id, "در فعالسازی سلف برای این کاربر مشکلی پیش آمد! لطفا دوباره تلاش کنید")
                                    break
                            await asyncio.sleep(0.1)
                    else:
                        await app.send_message(owner_id, "سلف از قبل برای این کاربر فعال است!")
                else:
                    await app.send_message(owner_id, "اشتراک سلف برای این کاربر فعال نیست!")
            else:
                await app.send_message(owner_id, "چنین کاربری در ربات یافت نشد!")
        else:
            await app.send_message(owner_id, "ورودی نامعتبر! فقط ارسال عدد مجاز است")
    
    elif text == "غیرفعال کردن سلف 🔴":
        await app.send_message(owner_id, "آیدی عددی کاربری که می خواهید سلف او را غیرفعال کنید ارسال کنید:", reply_markup=AdminBack)
        await update_data(f"UPDATE user SET step = 'selfinactive' WHERE id = '{owner_id}' LIMIT 1")
    
    elif user["step"] == "selfinactive":
        if text.isdigit():
            user_id = int(text.strip())
            user_data = await get_data(f"SELECT * FROM user WHERE id = '{user_id}' LIMIT 1")
            if user_data is not None:
                if os.path.isfile(f"sessions/{user_id}.session"):
                    if user_data["self"] != "inactive":
                        mess = await app.send_message(owner_id, "در حال پردازش...")
                        subprocess.Popen(["pkill", "-f", f"{user_id}.py"], cwd=f"selfs/self-{user_id}")
                        await app.edit_message_text(owner_id, mess.id, "سلف با موفقیت برای این کاربر غیرفعال شد", reply_markup=InlineKeyboardMarkup(
                            [
                                [
                                    InlineKeyboardButton(text="حذف اشتراک کاربر", callback_data=f"DeleteSub-{user_id}")
                                ]
                            ]
                        ))
                        await update_data(f"UPDATE user SET self = 'inactive' WHERE id = '{user_id}' LIMIT 1")
                        if user_id != owner_id:
                            await delete_admin(user_id)
                        job = scheduler.get_job(str(user_id))
                        if job:
                            scheduler.remove_job(str(user_id))
                        await app.send_message(user_id, "سلف شما توسط مدیر غیرفعال شد")
                    else:
                        await app.send_message(owner_id, "سلف از قبل برای این کاربر غیرفعال است!")
                else:
                    await app.send_message(owner_id, "اشتراک سلف برای این کاربر فعال نیست!")
            else:
                await app.send_message(owner_id, "چنین کاربری در ربات یافت نشد!")
        else:
            await app.send_message(owner_id, "ورودی نامعتبر! فقط ارسال عدد مجاز است")

    elif text == "فعال کردن همه سلف ها 🔵":
        await app.send_message(owner_id, "**توجه! این قابلیت زمانی کاربرد دارد که میزبانی به هر دلیلی از دسترس خارج شده باشد و سلف های کاربران غیرفعال شده باشند**", reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text="ادامه", callback_data="continue_activate_selfs")
                ],
                [
                    InlineKeyboardButton(text="برگشت", callback_data="AdminBack")
                ]
            ]
        ))

    elif text == "غیرفعال کردن همه سلف ها 🔴":
        await app.send_message(owner_id, "**توجه! با این کار سلف های همه کاربران غیرفعال می شوند\nاگر از این کار اطمینان دارید روی \"ادامه\" و در غیر این صورت روی \"برگشت\" روی کلیک کنید**", reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(text="ادامه", callback_data="continue_deactivate_selfs")
                ],
                [
                    InlineKeyboardButton(text="برگشت", callback_data="AdminBack")
                ]
            ]
        ))
    
    elif text == "روشن کردن ربات 🔵":
        if bot["status"] != "ON":
            await app.send_message(owner_id, "ربات روشن شد")
            await update_data(f"UPDATE bot SET status = 'ON' LIMIT 1")
        else:
            await app.send_message(owner_id, "ربات از قبل روشن است!")
    
    elif text == "خاموش کردن ربات 🔴":
        if bot["status"] != "OFF":
            await app.send_message(owner_id, "ربات خاموش شد")
            await update_data(f"UPDATE bot SET status = 'OFF' LIMIT 1")
        else:
            await app.send_message(owner_id, "ربات از قبل خاموش است!")

    elif text == "صفحه اصلی 🏠":
        dyconfig = await get_data("SELECT * FROM dynamic_config")
        mess = await app.send_message(owner_id, "به صفحه اصلی برگشتید", reply_markup=ReplyKeyboardRemove())
        await app.send_message(owner_id, dyconfig["start_text"].replace("FIRST_NAME", html.escape(m.chat.first_name or "")).replace("LAST_NAME", html.escape(m.chat.last_name or "")).replace("DATE", get_time("date")).replace("TIME", get_time("time")), reply_markup=Main)
        await update_data(f"UPDATE user SET step = 'none' WHERE id = '{owner_id}' LIMIT 1")
        async with lock:
            if owner_id in temp_Client:
                del temp_Client[owner_id]
        await asyncio.sleep(1)
        await app.delete_messages(owner_id, mess.id)

    elif user["step"] == "add_channel":
        if text:
            channel = text.strip()
            try:
                await app.get_chat_member(channel, "me")
                chat = await app.get_chat(channel)
                this_channel = await get_data(f"SELECT * FROM channels WHERE id = '{chat.id}' LIMIT 1")
                if this_channel is None:
                    if chat.username:
                        channel_link = f"https://t.me/{chat.username}"
                    else:
                        try:
                            invite_link = await app.create_chat_invite_link(chat.id)
                            channel_link = invite_link.invite_link
                        except errors.ChatAdminRequired:
                            channel_link = None
                            await app.send_message(owner_id, "ربات دسترسی به ایجاد لینک دعوت ندارد!", reply_parameters=ReplyParameters(message_id=m_id))
                    if channel_link:
                        await app.send_message(owner_id, f"قفل عضویت اجباری برای [{html.escape(chat.title)}]({channel_link}) فعال شد\nاز این پس کاربران برای استفاده از ربات باید عضو کانال ثبت شده شوند", reply_markup=InlineKeyboardMarkup(
                            [
                                [
                                    InlineKeyboardButton(text="برگشت", callback_data="channel_panel")
                                ]
                            ]
                        ))
                        await update_data(f"INSERT INTO channels(id, channel_link) VALUES('{chat.id}', '{channel_link}')")
                else:
                    await app.send_message(owner_id, "این کانال از قبل در ربات ثبت شده است!", reply_parameters=ReplyParameters(message_id=m_id))
            except errors.ChatAdminRequired:
                await app.send_message(owner_id, "ربات در کانال مورد نظر ادمین نمی باشد!\nلطفا ابتدا ربات را ادمین کنید", reply_parameters=ReplyParameters(message_id=m_id))
            except errors.UserNotParticipant:
                await app.send_message(owner_id, "ربات در کانال مورد نظر ادمین نمی باشد!\nلطفا ابتدا ربات را ادمین کنید", reply_parameters=ReplyParameters(message_id=m_id))
            except errors.UserIsBlocked:
                await app.send_message(owner_id, "ربات در این کانال بلاک می باشد!\nلطفا ابتدا ربات را آنبلاک کنید", reply_parameters=ReplyParameters(message_id=m_id))
            except errors.PeerIdInvalid:
                await app.send_message(owner_id, "آیدی نامعتبر است!", reply_parameters=ReplyParameters(message_id=m_id))
            except errors.UsernameInvalid:
                await app.send_message(owner_id, "یوزرنیم نامعتبر است!", reply_parameters=ReplyParameters(message_id=m_id))
            except errors.UsernameNotOccupied:
                await app.send_message(owner_id, "یوزرنیم نامعتبر است!", reply_parameters=ReplyParameters(message_id=m_id))
            except errors.ChannelPrivate:
                await app.send_message(owner_id, "این کانال خصوصی است و دسترسی به اطلاعات آن ممکن نیست!\nبرای رفع مشکل، ربات را در کانال مورد نظر ادمین کنید", reply_parameters=ReplyParameters(message_id=m_id))
            except ValueError:
                await app.send_message(owner_id, "نامعتبر!", reply_parameters=ReplyParameters(message_id=m_id))
        else:
            await app.send_message(owner_id, "ورودی نامعتبر!", reply_parameters=ReplyParameters(message_id=m_id))

    elif user["step"] == "del_channel":
        if text:
            channel = text.strip()
            try:
                await app.get_chat_member(channel, "me")
                chat = await app.get_chat(channel)
                this_channel = await get_data(f"SELECT * FROM channels WHERE id = '{chat.id}' LIMIT 1")
                if this_channel:
                    channel_link = this_channel["channel_link"]
                    await app.send_message(owner_id, f"قفل عضویت اجباری برای [{html.escape(chat.title)}]({channel_link}) غیرفعال شد", reply_markup=InlineKeyboardMarkup(
                        [
                            [
                                InlineKeyboardButton(text="برگشت", callback_data="channel_panel")
                            ]
                        ]
                    ))
                    await update_data(f"DELETE FROM channels WHERE id = '{chat.id}' LIMIT 1")
                else:
                    await app.send_message(owner_id, "چنین کانالی در ربات ثبت نشده است!", reply_parameters=ReplyParameters(message_id=m_id))
            except errors.PeerIdInvalid:
                await app.send_message(owner_id, "آیدی نامعتبر است!", reply_parameters=ReplyParameters(message_id=m_id))
            except errors.UsernameInvalid:
                await app.send_message(owner_id, "یوزرنیم نامعتبر است!", reply_parameters=ReplyParameters(message_id=m_id))
            except errors.UsernameNotOccupied:
                await app.send_message(owner_id, "یوزرنیم نامعتبر است!", reply_parameters=ReplyParameters(message_id=m_id))
            except errors.ChannelPrivate:
                await app.send_message(owner_id, "این کانال خصوصی است و دسترسی به اطلاعات آن ممکن نیست!\nبرای رفع مشکل، ربات را در کانال مورد نظر ادمین کنید", reply_parameters=ReplyParameters(message_id=m_id))
            except ValueError:
                await app.send_message(owner_id, "نامعتبر!", reply_parameters=ReplyParameters(message_id=m_id))
        else:
            await app.send_message(owner_id, "ورودی نامعتبر!", reply_parameters=ReplyParameters(message_id=m_id))
    
    elif user["step"] == "edit_start_text":
        if text:
            await app.send_message(owner_id, "متن جدید تنظیم شد", reply_parameters=ReplyParameters(message_id=m_id))
            await update_data(f"UPDATE dynamic_config SET start_text = '{text.strip()}'")
        else:
            await app.send_message(owner_id, "ورودی نامعتبر!", reply_parameters=ReplyParameters(message_id=m_id))

    elif user["step"] == "edit_support_text":
        if text:
            await app.send_message(owner_id, "متن جدید تنظیم شد", reply_parameters=ReplyParameters(message_id=m_id))
            await update_data(f"UPDATE dynamic_config SET support_text = '{text.strip()}'")
        else:
            await app.send_message(owner_id, "ورودی نامعتبر!", reply_parameters=ReplyParameters(message_id=m_id))

    elif user["step"] == "change_sub_prices":
        if text:
            prices = [p.strip() for p in text.strip().split("\n") if p.strip()]
            if len(prices) == 6 and all(p.isdigit() for p in prices):
                await app.send_message(owner_id, "قیمت های جدید تنظیم شدند", reply_parameters=ReplyParameters(message_id=m_id))
                await update_data(f"UPDATE dynamic_config SET sub_1m_price = '{prices[0]}', sub_2m_price = '{prices[1]}', sub_3m_price = '{prices[2]}', sub_4m_price = '{prices[3]}', sub_5m_price = '{prices[4]}', sub_6m_price = '{prices[5]}'")
            else:
                await app.send_message(owner_id, "ورودی نامعتبر!\nلطفا دقیقا 6 عدد صحیح وارد کنید، هر عدد در یک خط جداگانه", reply_parameters=ReplyParameters(message_id=m_id))
        else:
            await app.send_message(owner_id, "ورودی نامعتبر!", reply_parameters=ReplyParameters(message_id=m_id))

    elif user["step"] == "change_referral_value":
        if text:
            if text.isdigit():
                await app.send_message(owner_id, "مقدار جدید تنظیم شد", reply_parameters=ReplyParameters(message_id=m_id))
                await update_data(f"UPDATE dynamic_config SET referral_value = '{text.strip()}'")
            else:
                await app.send_message(owner_id, "ورودی نامعتبر!", reply_parameters=ReplyParameters(message_id=m_id))
        else:
            await app.send_message(owner_id, "ورودی نامعتبر!", reply_parameters=ReplyParameters(message_id=m_id))

    elif user["step"] == "edit_whattb_section":
        if text:
            await app.send_message(owner_id, "متن جدید تنظیم شد", reply_parameters=ReplyParameters(message_id=m_id))
            await update_data(f"UPDATE dynamic_config SET whattb_text = '{text.strip()}'")
        else:
            await app.send_message(owner_id, "ورودی نامعتبر!", reply_parameters=ReplyParameters(message_id=m_id))

    elif user["step"] == "edit_myaccount_section":
        if text:
            await app.send_message(owner_id, "متن جدید تنظیم شد", reply_parameters=ReplyParameters(message_id=m_id))
            await update_data(f"UPDATE dynamic_config SET myaccount_text = '{text.strip()}'")
        else:
            await app.send_message(owner_id, "ورودی نامعتبر!", reply_parameters=ReplyParameters(message_id=m_id))

    elif user["step"] == "del_giftcode":
        settings = await get_data("SELECT * FROM settings")
        if settings["giftcode"] == "ON":
            if m.text:
                code = text.strip()
                if len(code) == 10 and code.isupper():
                    gift_code = await get_data(f"SELECT * FROM codes WHERE code = '{code}' LIMIT 1")
                    if gift_code:
                        await update_data(f"DELETE FROM codes WHERE code = '{code}' LIMIT 1")
                        await app.send_message(owner_id, f"کد هدیه [ `{code}` ] حذف شد")
                    else:
                        await app.send_message(owner_id, "کد هدیه نامعتبر است!")
                else:
                    await app.send_message(owner_id, "کد هدیه نامعتبر است!")
            else:
                await app.send_message(owner_id, "ورودی نامعتبر! فقط ارسال متن مجاز است")
        else:
            await app.send_message(owner_id, "این بخش غیرفعال است!")
    
    elif user["step"] == "giftcode_info":
        settings = await get_data("SELECT * FROM settings")
        if settings["giftcode"] == "ON":
            if m.text:
                code = text.strip()
                if len(code) == 10 and code.isupper():
                    gift_code = await get_data(f"SELECT * FROM codes WHERE code = '{code}' LIMIT 1")
                    if gift_code:
                        giftcode_value = gift_code["value"]
                        giftcode_capacity = gift_code["capacity"]
                        giftcode_expir = gift_code["expir"]
                        giftcode = gift_code["code"]
                        await app.send_message(owner_id, f"اطلاعات دریافت شد. اطلاعات کد به شرح زیر است:", reply_markup=InlineKeyboardMarkup(
                            [
                                [
                                    InlineKeyboardButton(text="کد هدیه", callback_data="text"),
                                    InlineKeyboardButton(text=f"{giftcode}", copy_text=f"{giftcode}")
                                ],
                                [
                                    InlineKeyboardButton(text="ارزش کد هدیه", callback_data="text"),
                                    InlineKeyboardButton(text=f"{int(giftcode_value):,} تومان", callback_data="text")
                                ],
                                [
                                    InlineKeyboardButton(text="ظرفیت کد هدیه", callback_data="text"),
                                    InlineKeyboardButton(text=f"{f'{giftcode_capacity} نفر مانده' if giftcode_capacity != 'inf' else 'بدون محدودیت'}", callback_data="text")
                                ],
                                [
                                    InlineKeyboardButton(text="انقضای کد هدیه", callback_data="text"),
                                    InlineKeyboardButton(text=f"{f'{giftcode_expir} روز مانده' if giftcode_expir != 'inf' else 'بدون محدودیت'}", callback_data="text")
                                ],
                                [
                                    InlineKeyboardButton(text="برگشت", callback_data="giftcode_panel")
                                ]
                            ]
                        ))
                    else:
                        await app.send_message(owner_id, "کد هدیه نامعتبر است!")
                else:
                    await app.send_message(owner_id, "کد هدیه نامعتبر است!")
            else:
                await app.send_message(owner_id, "ورودی نامعتبر! فقط ارسال متن مجاز است")
        else:
            await app.send_message(owner_id, "این بخش غیرفعال است!")

#====================================================================================================#

app.loop.create_task(start_scheduler())
print(Fore.YELLOW+"Started...\nDeveloper: @IVGalaxy\n© 2025 Ultra Self LLC. All rights reserved."), app.run()

#====================================================================================================#